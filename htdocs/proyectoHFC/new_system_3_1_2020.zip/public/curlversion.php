
<?php
// Obtener array de la versión de curl
$version = curl_version();

print_r($version);

?>



