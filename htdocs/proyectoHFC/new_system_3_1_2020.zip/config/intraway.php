<?php 

return [

   // 'one_conexion' => env('USER_ONE_CONEXION','ehuertasf')

     'one_intraway' => [
        'wsdl' => env('ONE_WSDL_INTRAWAY','http://10.118.128.26/IntrawayWS/server.php?wsdl'),
        'key' => env('ONE_KEY_INTRAWAY','F12062017R')//F12062017R
    ], 

];