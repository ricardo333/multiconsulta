<?php

namespace App\Http\Controllers\ApiServices\ServiceMulticonsulta;

use Illuminate\Http\Request;
use App\Functions\Services\ServiceMulticonsultaFunctions;
use App\Http\Controllers\GeneralController;

class ServiceMulticonsultaController extends GeneralController
{
    public function getInfoBasicaServicioHFCxCliente(Request $request)
    {
        $idCliente = $request->idCliente;

        $funcionesMulticonsulta = new ServiceMulticonsultaFunctions;

        $verificaCliente = $funcionesMulticonsulta->getClienteHFC($idCliente);

        $cantidad = count($verificaCliente);

        $respuesta = array();

        if($cantidad == ""){
            $respuesta["mensaje"] = "ERROR 201906. CODIGO DE CLIENTE NO EXISTE.";
        }else {
            //$mensaje = $verificaCliente;
            for ($i=0; $i < $cantidad; $i++) { 

                $servicio = $i+1;

                $ipcpe = $funcionesMulticonsulta->obtenerSnmp($verificaCliente[$i]->Fabricante,$verificaCliente[$i]->IPAddress);
                
                $mensaje = $funcionesMulticonsulta->validaNiveles($verificaCliente[$i]->DSPwr,$verificaCliente[$i]->USMER_SNR,$verificaCliente[$i]->DSMER_SNR,$verificaCliente[$i]->USPwr,$verificaCliente[$i]->cliente_alerta,
                            $verificaCliente[$i]->nodo,$verificaCliente[$i]->troba,$verificaCliente[$i]->MACState,
                            $verificaCliente[$i]->num_masiva,$verificaCliente[$i]->NumCPE,$ipcpe["Publica"],$ipcpe["MacCpe"]);
                
                $respuesta["servicio"][$servicio]["Cmts"] = $verificaCliente[$i]->cmts;
                $respuesta["servicio"][$servicio]["Nodo"] = $verificaCliente[$i]->nodo;
                $respuesta["servicio"][$servicio]["Troba"] = $verificaCliente[$i]->troba;
                $respuesta["servicio"][$servicio]["ServicePackage"] = $verificaCliente[$i]->SERVICEPACKAGE;
                $respuesta["servicio"][$servicio]["Ussnr"] = $verificaCliente[$i]->USMER_SNR;
                $respuesta["servicio"][$servicio]["Dssnr"] = $verificaCliente[$i]->DSMER_SNR;
                $respuesta["servicio"][$servicio]["IpCm"] = $verificaCliente[$i]->IPAddress;
                $respuesta["servicio"][$servicio]["MacAddress"] = $verificaCliente[$i]->MACADDRESS;
                $respuesta["servicio"][$servicio]["Fabricante"] = $verificaCliente[$i]->Fabricante;
                $respuesta["servicio"][$servicio]["Modelo"] = $verificaCliente[$i]->Modelo;
                $respuesta["servicio"][$servicio]["Firmware"] = $verificaCliente[$i]->Version_firmware;
                $respuesta["servicio"][$servicio]["IspCpe"] = $verificaCliente[$i]->scopesgroup;
                $respuesta["servicio"][$servicio]["EstadoModem"] = $verificaCliente[$i]->estado;
                $respuesta["servicio"][$servicio]["PowerUp"] = $verificaCliente[$i]->USPwr;
                $respuesta["servicio"][$servicio]["PowerDown"] = $verificaCliente[$i]->DSPwr;
                $respuesta["servicio"][$servicio]["MACState"] = $verificaCliente[$i]->MACState;
                $respuesta["servicio"][$servicio]["Mensaje"] = $mensaje;

            }

        }


        return response()->json([
            "message" => $respuesta
        ], 201);


    }


}