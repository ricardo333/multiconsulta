<?php

namespace App\Http\Controllers\Modulos\AveriasCoe;

use Illuminate\Http\Request;
use App\Functions\AveriasCoeFunctions;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\GeneralController;
use App\Functions\peticionesGeneralesFunctions;

class AveriasCoeController extends GeneralController
{

    public function view()
    {
        $functionPeticionesGenerales = new peticionesGeneralesFunctions;
        

        $jefaturas =  $functionPeticionesGenerales->getJefaturas();
        $trobas =  $functionPeticionesGenerales->getTrobas();

        return view('administrador.modulos.averiasCoe.index',[
            "jefaturas"=>$jefaturas,
            "trobas"=>$trobas
        ]);
    }

    public function lista(Request $request){
        
         if($request->ajax()){

            #INICIO
 
                $filtroJefatura = "";
                $filtroEstado = "";
                $filtroTroba = "";

                
                $validarJefatura = Validator::make($request->all(), [
                    "jefatura" => "nullable|not_in:seleccionar,Seleccionar|regex:/^[a-zA-Z\-_]+$/"
                ]); 
                $validarEstado = Validator::make($request->all(), [ //Validando texto con caracteres y espacios.
                    "estado" => "nullable|not_in:seleccionar,Seleccionar|regex:/^[a-zA-Z-_:.]+(\s*[a-zA-Z-_:.]*)*[a-zA-Z-_:.]+$/"
                ]);  
                $validarTroba = Validator::make($request->all(), [
                    "troba" => "nullable|not_in:seleccionar,Seleccionar|regex:/^[a-zA-Z0-9_-]+$/"
                ]);  


                if (!$validarJefatura->fails()) {
                    if (isset($request->jefatura)) {   
                        $filtroJefatura = trim($request->jefatura) != "" ? " and ar.zonal='".$request->jefatura."' " : "";
                    }  
                }
                if (!$validarEstado->fails()) {
                    if (isset($request->estado)) {   
                        $filtroEstado = trim($request->estado) != "" ? "  and tg.EstadoDelCaso='".$request->estado."' " : "";
                        if ( trim($request->estado) ==  "SIN_ESTADO") {
                            $filtroEstado =  "and tg.EstadoDelCaso is null";
                        }
                    }  
                    
                }
                
                if (!$validarTroba->fails()) {
                    //dd($request->troba);
                    if (isset($request->troba)) {   
                        $nodoTroba = explode("_",$request->troba);
                        $filtroTroba = " and ar.nodohfc= '".$nodoTroba[0]."' and ar.trobahfc='".$nodoTroba[1]."' ";
                    }  
                }

                $functionAveriaCoe = new AveriasCoeFunctions;

                $listaAveriaCoe =  $functionAveriaCoe->getListaCoe($filtroJefatura,$filtroTroba,$filtroEstado);
                //dd($listaAveriaCoe);
            
                if ($listaAveriaCoe == "error") {
                    return $this->errorDataTable("Se generó un conflicto con los datos, intente dentro de un minuto por favor.",500);
                } 

                return datatables($listaAveriaCoe)->toJson();

            #END
        }
        return abort(404); 
    }

}
