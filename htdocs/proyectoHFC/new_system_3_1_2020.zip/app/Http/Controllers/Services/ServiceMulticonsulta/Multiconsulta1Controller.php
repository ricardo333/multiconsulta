<?php

namespace App\Http\Controllers\Services\ServiceMulticonsulta;

use App\Library\nusoap;
use App\Functions\Services\ServicioMulticonsultaFunctions;
use App\Http\Controllers\Services\ServiceMulticonsulta\FuncionMulti;

class Multiconsulta1Controller
{
    public function server()
    {
        //require_once('C:\xampp\htdocs\proyectoHFC\app\Library\nusoap.php');
        // Crear instancia del servidor
        //$server = new soap_server();
        //$server = new FuncionMulti();
        $server = new nusoap();
        //$server = new \nusoap_server();
        //INicializar el soporte de WSDL
        $server->configureWSDL('servidorHFC2', 'urn:servidorHFC2');

        //$server->wsdl->schemaTargetNamespace = 'urn:servidorHFC2';
        //$server->soap_defencoding = 'UTF-8';
        //$server->decode_utf8 = false;
        //$server->encode_utf8 = true;

        //registro de function Funciones
        $ns = "";
        //$ns = "http://localhost/WebServiceHFC/";


        //Parametros de Entrada

        //$server->wsdl->addComplexType('');

        $server->register('verifyHFCByIdClient',
            array( ),
            array('return'=>'xsd:string')   //captura y envia el valor del campo
        );


        function verifyHFCByIdClient($idCliente){
            
            return "<CLIENTE>
                        <RETURN>
                            <ERROR>Ningun Error</ERROR>
                            <ERMSG>".$idCliente."</ERMSG>
                        </RETURN>
                    </CLIENTE>";
                        
            //return $XML_RETURN;
        }

        // Use the request to invoke the service
        $HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA)
        ? $HTTP_RAW_POST_DATA : file_get_contents("php://input");
        //$server->service($HTTP_RAW_POST_DATA);
        $server->service($HTTP_RAW_POST_DATA);

    }
        



    






}