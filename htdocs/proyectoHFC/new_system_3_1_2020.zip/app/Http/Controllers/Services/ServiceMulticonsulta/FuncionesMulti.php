<?php 

namespace App\Http\Controllers\Services\ServiceMulticonsulta;

class FuncionesMulti {

    public function verifyHFCByIdClient()
    {
        return "<CLIENTE>
                        <RETURN>
                            <ERROR>Ningun Error</ERROR>
                            <ERMSG></ERMSG>
                        </RETURN>
                    </CLIENTE>";
    }

}