<?php

namespace App\Http\Controllers\Services\ServiceMulticonsulta;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Services\ServiceMulticonsulta\FuncionesMulti;
use nusoap_server;

class ServidorController extends Controller
{
    public function server(){

    //$funcion = new FuncionesMulti();
    //$funcionMulti = $function->verifyHFCByIdClient();
    $server = new nusoap_server(); // Create a instance for nusoap server
    $server->configureWSDL("servidorHFC2", "urn:servidorHFC2"); // Configure WSDL file

    //$server->wsdl->schemaTargetNamespace = 'urn:servidorHFC2';
    //$server->soap_defencoding = 'UTF-8';
    //$server->decode_utf8 = false;
    //$server->encode_utf8 = true;
    //$server->wsdl->schemaTargetNamespace = 'urn:servidorHFC2';
    //$server->wsdl->addComplexType('');

    $server->register(
        'verifyHFCByIdClient', // name of function
        //$this->verifyHFCByIdClient2(),
        array('idCliente' => 'xsd:string'),  // inputs
        //array( ),  // inputs
        array('return' => 'xsd:string')   // outputs
    );

    
    function verifyHFCByIdClient($idCliente)
    {
        return "<CLIENTE>
                        <RETURN>
                            <ERROR>Ningun Error</ERROR>
                            <ERMSG>".$idcliente."</ERMSG>
                        </RETURN>
                    </CLIENTE>";
    }
    
    

    //return Response::make($server->service(file_get_contents("php://input")),
      //  200, array('Content-Type' => 'text/xml; charset=ISO-8859-1'));

    // Use the request to invoke the service
    $HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA)
    ? $HTTP_RAW_POST_DATA : file_get_contents("php://input");
    $server->service($HTTP_RAW_POST_DATA);
    
    }


    public function verifyHFCByIdClient2()
    {
        return "<CLIENTE>
                        <RETURN>
                            <ERROR>Ningun Error</ERROR>
                            <ERMSG></ERMSG>
                        </RETURN>
                    </CLIENTE>";
    }

    /*
    function verifyHFCByIdClient($idCliente)
    {
        return "<CLIENTE>
                        <RETURN>
                            <ERROR>Ningun Error</ERROR>
                            <ERMSG>".$idCliente."</ERMSG>
                        </RETURN>
                    </CLIENTE>";
    }
    */

}