<?php

namespace App\Functions\Services;

use DB; 
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\QueryException;
use Symfony\Component\HttpKernel\Exception\HttpException;

class ServiceMulticonsultaFunctions
{ 

    function getClienteHFC($idcliente)
    { 

        $consultaCliente = DB::select("SELECT st.cmts,a.nodo AS nodo,a.troba AS troba,n.velocidad_final AS SERVICEPACKAGE,
        nv.USMER_SNR,nv.DSMER_SNR,st.IPAddress,a.MACADDRESS,f.Fabricante, f.Modelo,f.Versioon AS Version_firmware,
        IF(a.scopesgroup='CPE-CGNAT','CGNAT','CPE') AS scopesgroup,a.estado,nv.USPwr,nv.DSPwr,
        IF(g.codreqmnt >0,g.codreqmnt,0) AS num_masiva, IF(ll.tipo='CAIDA MASIVA','Caida',IF(ll.tipo='CAIDA AMPLIF','Caida Amplif',
        IF(ll.tipo='CAIDA SENAL','Señal_RF',IF(ll.tipo='CAIDA SENAL AMPLIF','Señal RF Amplif','')))) AS cliente_alerta,
        IF(st.MACState LIKE '%nline%','online',IF(st.macstate IS NULL,IF(nv.`MACAddress` IS NULL,'','online'),st.macstate)) AS MACState,st.`NumCPE`
        FROM multiconsulta.nclientes a
        LEFT JOIN ccm1_data.marca_modelo_docsis_total f  ON a.MACADDRESS=f.MACAddress
        LEFT JOIN catalogos.velocidades_cambios n ON a.SERVICEPACKAGE=n.SERVICEPACKAGE
        LEFT JOIN dbpext.masivas_temp g ON a.nodo=g.codnod AND a.troba=g.nroplano
        LEFT JOIN alertasx.clientes_alertados ll ON a.MACADDRESS = ll.macaddress
        LEFT JOIN reportes.criticos cc ON a.idclientecrm=cc.idclientecrm
        LEFT JOIN ccm1.scm_phy_t nv ON a.mac2=nv.macaddress
        LEFT JOIN ccm1.scm_total st ON a.mac2=st.macaddress
        WHERE a.idclientecrm <> 969625 AND a.`IDCLIENTECRM`='$idcliente'");

        return $consultaCliente;

    }


    function obtenerSnmp($fabricante,$ipaddress)
    {

        $fabricante_substr = substr($fabricante,0,5);
        $oidx='iso.3.6.1.2.1.4.34.1.10.1.4';

        if($fabricante_substr=="Arris"){
            $oidx='iso.3.6.1.2.1.4.20.1.1';
        }

        if($fabricante_substr=="Hitro"){
            $oidx='iso.3.6.1.2.1.4.22.1.1.1'; 
        }

        $cpe=array();
         
        if ($ipaddress<>'0.0.0.0'){
            $ippu="snmpwalk  -c MODEM8K_PILOTO -v2c ".$ipaddress." ".$oidx;
            
            exec($ippu,$cpe);
            $regy=array();
            $reg ='';
            $cantidad_cpe = count($cpe);

            for ($i=0;$i<$cantidad_cpe;$i++){
                $regy = $cpe[$i];
                $cad='';

                if($fabricante_substr=="Arris"){ 
                    $cad=substr($regy,20,3);
                }else {
                    if($fabricante_substr=="Hitro"){
                        $cad=substr($regy,30,3); 
                    }else{ 
                        $cad=substr($regy,33,3);
                    }
                }
                
                if ($cad<>"10." && $cad<>'127' && $cad<>'192' && trim($cad)<>''){
                    $reg=trim(str_replace("= INTEGER: 1","",$cpe[$i]));
                }
            } 
            
            $oid ='';
            $publica='';
            if($fabricante_substr=="Arris"){
                $oid="iso.3.6.1.2.1.2.2.1.6.10";
                $publica=substr($reg,20,15); 
            } else {
                if($fabricante_substr=="Hitro"){
                    $oid="iso.3.6.1.2.1.4.22.1.2.1.".substr($reg,30,14);
                    $publica=substr($reg,30,15);  
                } elseif(strlen($reg)>10){ 
                    $oid="iso.3.6.1.2.1.4.22.1.2.1.".substr($reg,33,15); 
                    $oid = str_replace("\"","",$oid); 
                    $publica=substr($reg,33,15); 
                    $publica=str_replace("\"","",$publica);
                }        
            }
             
            // Aqui obtenemos la MAC CPE
            $maccpe=array();
            $snmp='snmpget -c MODEM8K_PILOTO -v2c '.$ipaddress.' '.$oid;
            exec($snmp,$maccpe);
        
            $macaddress='';
            $cpex=array();
            $regx=array();
            $reg1x=array();
            $reg2x=array();
            $regx = empty($maccpe[0])? '' : $maccpe[0];
            $macx='';
            
            if($regx != ''){
                $regxx = explode(": ", $regx);
                
                foreach ($regxx as $fil2x) {
                    if ($fil2x!=''){
                        $reg2x[] = $fil2x;
                    }  
                }
                
                if (isset($reg2x[1])) {
                    $arregloMacStr = explode(":", $reg2x[1]);
                    for ($i=0; $i < count($arregloMacStr); $i++) {  
                        $macx .= (strlen($arregloMacStr[$i]) < 2 ) ? "0".$arregloMacStr[$i] : $arregloMacStr[$i]; 
                        if ($i+1 < count($arregloMacStr)) $macx .= ":"; 
                    }
                } 

            }else{
                $reg2x[] = "";
            }
            
            if(trim(substr($publica,1,2))==''){
                $macx='';
                $publica='';
            }
            

            return array(
                "Publica" => $publica,
                "MacCpe" => $macx
            );

        }

    }



    function validaNiveles($downPx,$upSnr,$downSnr,$upPx,$cliente_alerta,$nodo,$troba,$macstate,$num_masiva,$numcpe,$publica,$macx)
    {

        $tipoprob='';
        $niveles='ok';
        
        if (($cliente_alerta == 'Caida' or $cliente_alerta == 'Señal RF' or $cliente_alerta == 'Caida Amplif' or 
            $cliente_alerta == 'Señal RF Amplif') and $niveles==''){

            if ($downPx < -5 or $downPx > 10) {
                //$tipoprob = 'Generar averia R417 </br> Probable problema de Pext';
                $tipoprob = 'Probable problema de Pext';
                $niveles = 'Malos';
            }
            if ($upSnr * 1 < 27) {
                //$tipoprob = 'Generar averia R417 </br>Probable problema de Pext';
                $tipoprob = 'Probable problema de Pext';
                $niveles = 'Malos';
            }
            if ($upSnr * 1 < 27 and $upPx * 1 < 36) {
                //$tipoprob = 'Generar averia R417 </br> Probable problema de Pext';
                $tipoprob = 'Probable problema de Pext';
                $niveles = 'Malos';
            }
            if ($downSnr * 1 < 29) {
                //$tipoprob = 'Generar averia R417 </br> Probable problema de Pext';
                $tipoprob = 'Probable problema de Pext';
                $niveles = 'Malos';
            }
            if ($downPx * 1 <= -5 or $downPx * 1 > 12)  {
                //$tipoprob = 'Generar averia R417 </br> Probable problema de Pext';
                $tipoprob = 'Probable problema de Pext';
                $niveles = 'Malos';
            }
            if ($upPx * 1 <= 35 or $upPx * 1 > 55)  {
                //$tipoprob = 'Generar averia R417 </br> Probable problema de Pext';
                $tipoprob = 'Probable problema de Pext';
                $niveles = 'Malos';
            }
            if ($downPx * 1 > 10 and $upPx * 1 <= 36) {
                //$tipoprob = 'Generar averia R417 </br> Probable problema de Pext';
                $tipoprob = 'Probable problema de Pext';
                $niveles = 'Malos';
            }
            if ($downPx * 1 > 8 and $downSnr * 1 < 30) {
                //$tipoprob = 'Generar averia R417 </br> Probable problema de Pext';
                $tipoprob = 'Probable problema de Pext';
                $niveles = 'Malos';
            }
            if ($upPx * 1 < 35 and $upPx * 1 > 0) {
                //$tipoprob = 'Generar averia R417 </br> Probable problema de Pext';
                $tipoprob = 'Probable problema de Pext';
                $niveles = 'Malos';
            }
            if ($downPx * 1 > 15) {
                //$tipoprob = 'Generar averia R417 </br> Probable problema de Pext';
                $tipoprob = 'Probable problema de Pext';
                $niveles = 'Malos';
            }
            if ($upSnr * 1 < 27 and $downSnr * 1 > 30 and $downPx * 1 >= -10 and $downPx * 1 <= 12 and $upPx * 1 >= 37 and $upPx * 1 <= 55) {
                //$tipoprob = 'Generar averia R417 </br> Probable problema de Pext';
                $tipoprob = 'Probable problema de Pext';
                $niveles = 'Malos';
            }
            if ($upSnr * 1 > 27 and $downSnr * 1 < 30 and $downPx * 1 >= -10 and $downPx * 1 <= 12 and $upPx * 1 >= 37 and $upPx * 1 <= 55 ) {
                //$tipoprob = 'Generar averia R417 </br> Probable problema de Pext';
                $tipoprob = 'Probable problema de Pext';
                $niveles = 'Malos';
            }
            if ($downPx * 1 < -15 or $downPx * 1 > 15) {
                $niveles = 'Malos';
                //$tipoprob = 'Generar averia R417 </br> Probable problema de Pext';
                $tipoprob = 'Probable problema de Pext';
            }
        }
	
        if (($cliente_alerta <> 'Caida' and $cliente_alerta <> 'Señal RF' and $cliente_alerta <> 'Caida Amplif' and 
            $cliente_alerta <> 'Señal RF Amplif' ) and $niveles<>'Malos'){

            if (($downPx < -5 and $upPx > 55)) {
                $tipoprob = 'Probable averia en:Red Cliente';
                $niveles = 'Malos';
            }
            if (($downPx < -5 or $downPx > 10)) {
                $tipoprob = 'Probable averia en:Red Cliente';
                $niveles = 'Malos';
            }
            if ($downPx < -5 and $downSnr < 30) {
                $tipoprob = 'Probable averia en:Red Cliente';
                $niveles = 'Malos';
            }
            if ($upSnr  < 27) {
                $tipoprob = 'Probable averia en:Red Cliente';
                $niveles = 'Malos';
            }
            if ($downSnr  < 29) {
                $tipoprob = 'Probable averia en:Red Cliente';
                $niveles = 'Malos';
            }
            if (($downPx  <= -5 or $downPx  > 12)) {
                $tipoprob = 'Probable averia en:Red Cliente';
                $niveles = 'Malos';
            }
            if (($upPx  <= 35 or $upPx  > 55)) {
                $tipoprob = 'Probable averia en:Red Cliente';
                $niveles = 'Malos';
            }
            if ($downPx  < -10 and $upPx  > 55) {
                $tipoprob = 'Probable averia en:Red Cliente';
                $niveles = 'malos';
            }
            if ($downPx  > 8 and $downSnr  < 30) {
                $tipoprob = 'Probable averia en:Red Cliente';
                $niveles = 'Malos';
            }
            if ($downPx  > 15) {
                $tipoprob = 'Probable averia en:Red Cliente';
                $niveles = 'Malos';
            }
            if ($upSnr < 27 and $downSnr > 30 and $downPx >= -10 and $downPx <= 12 and $upPx >= 37 and $upPx <= 55) {
                $tipoprob = 'Probable averia en:Red Cliente';
                $niveles = 'Malos';
            }
            if ($upSnr > 27 and $downSnr < 30 and $downPx >= -10 and $downPx <= 12 and $upPx >= 37 and $upPx <= 55) {
                $tipoprob = 'Probable averia en:Red Cliente';
                $niveles = 'Malos';
            }
            if ($downPx < -15 or $downPx > 15) {
                $niveles = 'Malos';
                $tipoprob = 'Probable averia en:Red Cliente';
            }
        }

        if($downPx=='' and $downSnr=='' and $macstate == 'online'){$tipoprob = '';}

        //Validacion de estado Init para mensaje de generacion de averias y derivacion a badeja 415
        if (($macstate == "init(d)" or $macstate == "init(i)" or $macstate == "init(io)" or $macstate == "init(o)" or $macstate == "init(r)" or 
            $macstate == "init(r1)"  or $macstate == "init(t)" or $macstate == "bpi(wait)") and $num_masiva * 1==0){
            $tipoprob = 'Probable averia en:Red Cliente';
        }

        //Mensaje de IP Publica
        if ($publica <>'no' and (strlen(trim($publica))<10 and $numcpe==0) and ($macstate == "online") and trim($macx)=='' and $num_masiva==0)
		{
			if($mensaje==''){
				$mensaje='Cable Modem sin IP Publica';
            }
            
			$tipoprob = $mensaje;
        
        }
        
        return $tipoprob;

    }





}