-- MySQL dump 10.15  Distrib 10.0.34-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: cms
-- ------------------------------------------------------
-- Server version	10.0.34-MariaDB-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `aver_liq_catv_pais`
--

DROP TABLE IF EXISTS `aver_liq_catv_pais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aver_liq_catv_pais` (
  `codigoreq` int(11) DEFAULT NULL COMMENT 'Cod. Requerimiento',
  `codigodelgruporeq` varchar(2) DEFAULT NULL COMMENT 'Grupo Requerimiento',
  `codigotiporeq` varchar(2) DEFAULT NULL COMMENT 'Tipo Requerimiento',
  `codigomotivoreq` varchar(4) DEFAULT NULL COMMENT 'Motivo Requerimiento',
  `codigodelcliente` int(11) DEFAULT NULL COMMENT 'Cod. Cliente',
  `apellidopaterno` varchar(35) DEFAULT NULL COMMENT 'Ap. Paterno',
  `apellidomaterno` varchar(35) DEFAULT NULL COMMENT 'Ap. Materno',
  `nombres` varchar(30) DEFAULT NULL COMMENT 'Nombres',
  `indicador_vip` varchar(10) DEFAULT NULL COMMENT 'Indicador VIP',
  `categoria_cliente` varchar(50) DEFAULT NULL COMMENT 'Cat. Cliente',
  `codigodelservicio` int(11) DEFAULT NULL COMMENT 'Cod. Servicio',
  `clasedeservicio` varchar(4) DEFAULT NULL COMMENT 'Clase Servicio',
  `categoriadeservicio` varchar(2) DEFAULT NULL COMMENT 'Categoria Servicio',
  `oficinaadministrativa` varchar(3) DEFAULT NULL COMMENT 'Oficina Administrativa',
  `departamento` varchar(3) DEFAULT NULL COMMENT 'Departamento',
  `provincia` varchar(3) DEFAULT NULL COMMENT 'Provincia',
  `distrito` varchar(3) DEFAULT NULL COMMENT 'Distrito',
  `tipodevia` varchar(2) DEFAULT NULL COMMENT 'Tipo Via',
  `nombredelavia` varchar(30) DEFAULT NULL COMMENT 'Nombre vía',
  `numero` int(11) DEFAULT NULL COMMENT 'Numero',
  `piso` varchar(2) DEFAULT NULL COMMENT 'Piso',
  `interior` varchar(5) DEFAULT NULL COMMENT 'Interior',
  `manzana` varchar(5) DEFAULT NULL COMMENT 'Manzana',
  `lote` varchar(5) DEFAULT NULL COMMENT 'Lote',
  `nodo` varchar(2) DEFAULT NULL COMMENT 'Nodo',
  `plano` varchar(4) DEFAULT NULL COMMENT 'Plano',
  `sector` varchar(5) DEFAULT NULL COMMENT 'Sector',
  `troba` varchar(4) DEFAULT NULL COMMENT 'Troba',
  `lex` varchar(4) DEFAULT NULL COMMENT 'Amplificador',
  `tap` varchar(4) DEFAULT NULL COMMENT 'Tap',
  `borne` varchar(4) DEFAULT NULL COMMENT 'Borne',
  `estacion` varchar(8) DEFAULT NULL COMMENT 'Estacion',
  `situacion` varchar(4) DEFAULT NULL COMMENT 'Situacion',
  `estado` varchar(1) DEFAULT NULL COMMENT 'Estado Req',
  `fecharegistro` varchar(20) DEFAULT NULL COMMENT 'Fecha Registro',
  `usuariogeneracion` varchar(12) DEFAULT NULL COMMENT 'Usuario Genera',
  `ot` int(11) DEFAULT NULL COMMENT 'Orde de Trabajo',
  `fechaasignacion` varchar(20) DEFAULT NULL COMMENT 'Fecha Asignación',
  `estadoot` varchar(1) DEFAULT NULL COMMENT 'Estado OT',
  `contrata` int(11) DEFAULT NULL COMMENT 'Contrata',
  `tecnico` varchar(12) DEFAULT NULL COMMENT 'Tecnico',
  `fecha_liquidacion` datetime DEFAULT NULL COMMENT 'Fecha Liquidacion',
  `codigodeliquidacion` varchar(12) DEFAULT NULL COMMENT 'Cod. Liquidacion',
  `detalle_liquidacion` varchar(20) DEFAULT NULL COMMENT 'Det. Liquidacion',
  UNIQUE KEY `idx_codigoreq` (`codigoreq`),
  KEY `NewIndex1` (`codigodelcliente`),
  KEY `NewIndex2` (`fecharegistro`),
  KEY `NewIndex3` (`clasedeservicio`),
  KEY `nodo` (`nodo`),
  KEY `plano` (`plano`),
  KEY `fecha_liquidacion` (`fecha_liquidacion`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `aver_liq_catv_pais_acumulado`
--

DROP TABLE IF EXISTS `aver_liq_catv_pais_acumulado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aver_liq_catv_pais_acumulado` (
  `codofcadm` varchar(3) DEFAULT NULL,
  `codreq` int(11) NOT NULL,
  `indcfmcli` varchar(1) DEFAULT NULL,
  `codedo` varchar(1) DEFAULT NULL,
  `indvip` varchar(1) DEFAULT NULL,
  `indcorp` varchar(1) DEFAULT NULL,
  `codcli` int(11) DEFAULT NULL,
  `nomcli` varchar(200) DEFAULT NULL,
  `tipcli` varchar(80) DEFAULT NULL,
  `codsrv` int(11) DEFAULT NULL,
  `codclasrv` int(11) DEFAULT NULL,
  `desclasrv` varchar(80) DEFAULT NULL,
  `codcnd` int(11) DEFAULT NULL,
  `descnd` varchar(40) DEFAULT NULL,
  `nombre_de_la_playa` varchar(100) DEFAULT NULL,
  `alt_km` int(11) DEFAULT NULL,
  `codctgsrv` varchar(4) DEFAULT NULL,
  `desctgsrv` varchar(20) DEFAULT NULL,
  `codjef` varchar(4) DEFAULT NULL,
  `codctr` int(11) DEFAULT NULL,
  `desnomctr` varchar(100) DEFAULT NULL,
  `codcmts` varchar(4) DEFAULT NULL,
  `descmts` varchar(100) DEFAULT NULL,
  `codnod` varchar(2) DEFAULT NULL,
  `nroplano` varchar(4) DEFAULT NULL,
  `codtrtrn` varchar(4) DEFAULT NULL,
  `codlex` varchar(2) DEFAULT NULL,
  `codtap` int(11) DEFAULT NULL,
  `codbor` int(11) DEFAULT NULL,
  `signalxtroba` varchar(100) DEFAULT NULL,
  `desdtt` varchar(100) DEFAULT NULL,
  `destipvia` varchar(10) DEFAULT NULL,
  `desnomvia` varchar(150) DEFAULT NULL,
  `numvia` int(11) DEFAULT NULL,
  `despis` varchar(4) DEFAULT NULL,
  `desint` varchar(4) DEFAULT NULL,
  `desmzn` varchar(4) DEFAULT NULL,
  `deslot` varchar(4) DEFAULT NULL,
  `destipurb` varchar(4) DEFAULT NULL,
  `desurb` varchar(100) DEFAULT NULL,
  `telefono_1` int(11) DEFAULT NULL,
  `telefono_2` int(11) DEFAULT NULL,
  `fecregsrv` varchar(20) DEFAULT NULL,
  `fec_regist` varchar(20) DEFAULT NULL,
  `fec_est_sop` varchar(20) DEFAULT NULL,
  `fec_prog` varchar(20) DEFAULT NULL,
  `fec_desp` varchar(20) DEFAULT NULL,
  `fec_liquid` varchar(20) DEFAULT NULL,
  `nrotranf` int(11) DEFAULT NULL,
  `codmotv` varchar(4) DEFAULT NULL,
  `desmotv` varchar(80) DEFAULT NULL,
  `tipreqini` varchar(4) DEFAULT NULL,
  `destipreqini` varchar(80) DEFAULT NULL,
  `tipreqfin` varchar(4) DEFAULT NULL,
  `destipreqfin` varchar(80) DEFAULT NULL,
  `tipave` varchar(4) DEFAULT NULL,
  `des_cod_liq` varchar(80) DEFAULT NULL,
  `codprbave` int(11) DEFAULT NULL,
  `desc_cod_det` varchar(80) DEFAULT NULL,
  `rubro` varchar(4) DEFAULT NULL,
  `codmotvot` varchar(4) DEFAULT NULL,
  `desmotvot` varchar(80) DEFAULT NULL,
  `codliq` varchar(20) DEFAULT NULL,
  `escliq` int(11) DEFAULT NULL,
  `codtecliq` varchar(10) DEFAULT NULL,
  `nomtec` varchar(80) DEFAULT NULL,
  `desobsordtrab` varchar(300) DEFAULT NULL,
  `parcon` int(11) DEFAULT NULL,
  `codusr` varchar(10) DEFAULT NULL,
  `demora_atcl` varchar(5) DEFAULT NULL,
  `demora_ctrbru` varchar(5) DEFAULT NULL,
  `demora_tot` varchar(5) DEFAULT NULL,
  `demora_est` varchar(5) DEFAULT NULL,
  `demora_ctrnet` varchar(5) DEFAULT NULL,
  `fechorpro` varchar(20) DEFAULT NULL,
  `numser_ant` varchar(20) DEFAULT NULL,
  `procedencia_ant` varchar(20) DEFAULT NULL,
  `numser_nue` varchar(20) DEFAULT NULL,
  `procedencia_nue` varchar(20) DEFAULT NULL,
  `indfactav` varchar(20) DEFAULT NULL,
  `codbolave` varchar(20) DEFAULT NULL,
  `codedo_b` varchar(20) DEFAULT NULL,
  `fecinigarcli` varchar(20) DEFAULT NULL,
  `fecfingarcli` varchar(20) DEFAULT NULL,
  `tipcnx` varchar(20) DEFAULT NULL,
  `filtro` varchar(20) DEFAULT NULL,
  `descripcion_filtro` varchar(20) DEFAULT NULL,
  `area` varchar(20) DEFAULT NULL,
  `indactuacion` varchar(1) DEFAULT NULL,
  `indagenda` varchar(1) DEFAULT NULL,
  `idcita` varchar(1) DEFAULT NULL,
  `fecinicita` varchar(20) DEFAULT NULL,
  `fecfincita` varchar(20) DEFAULT NULL,
  `feccumplimiento` varchar(20) DEFAULT NULL,
  `codedocita` varchar(20) DEFAULT NULL,
  `codedogaudi` varchar(20) DEFAULT NULL,
  `codedoact` varchar(20) DEFAULT NULL,
  `fecenviogaudi` varchar(20) DEFAULT NULL,
  `fecrecepgaudi` varchar(20) DEFAULT NULL,
  `coderror1` varchar(20) DEFAULT NULL,
  `deserrorenvio` varchar(20) DEFAULT NULL,
  `fecactedogaudi` varchar(20) DEFAULT NULL,
  `fechorliq` varchar(20) DEFAULT NULL,
  `fechorinf` varchar(20) DEFAULT NULL,
  `fecinfcierre` varchar(20) DEFAULT NULL,
  `fecfincierre` varchar(20) DEFAULT NULL,
  `coderror` varchar(20) DEFAULT NULL,
  `deserrorcierre` varchar(200) DEFAULT NULL,
  `fecliberror` varchar(20) DEFAULT NULL,
  `codusrliberror` varchar(20) DEFAULT NULL,
  `codtipoact` varchar(20) DEFAULT NULL,
  `ind_autorizacion` varchar(2) DEFAULT NULL,
  `usu_int_autoriza` varchar(20) DEFAULT NULL,
  `nombre_usuario` varchar(80) DEFAULT NULL,
  `fec_int_autoriza` varchar(20) DEFAULT NULL,
  `observacion` varchar(300) DEFAULT NULL,
  `tec_int_autoriz` varchar(10) DEFAULT NULL,
  `nombre_tecnico` varchar(80) DEFAULT NULL,
  `cod_autorizacion` varchar(10) DEFAULT NULL,
  `ind_conformidad` varchar(80) DEFAULT NULL,
  `motivo` varchar(10) DEFAULT NULL,
  `descrip_motivo` varchar(80) DEFAULT NULL,
  `contacto_cliente` varchar(1) DEFAULT NULL,
  `nombre_contacto` varchar(80) DEFAULT NULL,
  `parentesco` varchar(10) DEFAULT NULL,
  `doc_entidad` varchar(10) DEFAULT NULL,
  `tel_cont_cct` varchar(10) DEFAULT NULL,
  `tel_cont_ref_cct` varchar(10) DEFAULT NULL,
  `tel_cont_cc` varchar(10) DEFAULT NULL,
  `tel_cont_ref_cc` varchar(10) DEFAULT NULL,
  `ind_encuesta` varchar(2) DEFAULT NULL,
  `contacto_enc` varchar(80) DEFAULT NULL,
  `parentesco_enc` varchar(20) DEFAULT NULL,
  `telf_enc` varchar(10) DEFAULT NULL,
  `incidencia` varchar(1) DEFAULT NULL,
  `ticket_incidencia` varchar(20) DEFAULT NULL,
  `segincidencia` varchar(1) DEFAULT NULL,
  `tipo_servicio` varchar(10) DEFAULT NULL,
  `tipo_deco_ins` varchar(10) DEFAULT NULL,
  `paquete` varchar(50) DEFAULT NULL,
  `numaverei` int(11) DEFAULT NULL,
  `numdialim` int(11) DEFAULT NULL,
  `numavedif` int(11) DEFAULT NULL,
  `indmaxad` varchar(1) DEFAULT NULL,
  `desprbtec` varchar(100) DEFAULT NULL,
  `desobsprb` varchar(300) DEFAULT NULL,
  `ind_duo` varchar(10) DEFAULT NULL,
  `tiplinea` varchar(10) DEFAULT NULL,
  `numtelefvoip` varchar(10) DEFAULT NULL,
  `codpromo` varchar(3) DEFAULT NULL,
  `despromo` varchar(100) DEFAULT NULL,
  `nodoid` int(11) DEFAULT NULL,
  `tiptecnologia` varchar(10) DEFAULT NULL,
  `indblqgeo` varchar(1) DEFAULT NULL,
  `codedosoltec` varchar(3) DEFAULT NULL,
  `idsoltec` int(11) DEFAULT NULL,
  `fecenvgo` varchar(20) DEFAULT NULL,
  `fecregistro` varchar(20) DEFAULT NULL,
  `fecliquidacion` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`codreq`),
  KEY `codcli` (`codcli`),
  KEY `codofcadm` (`codofcadm`),
  KEY `codnod` (`codnod`),
  KEY `nroplano` (`nroplano`),
  KEY `codctr` (`codctr`),
  KEY `area` (`area`),
  KEY `codliq` (`codliq`),
  KEY `codsrv` (`codsrv`),
  KEY `fecregistro` (`fecregistro`),
  KEY `fecliquidacion` (`fecliquidacion`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `aver_pen_catv_pais`
--

DROP TABLE IF EXISTS `aver_pen_catv_pais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aver_pen_catv_pais` (
  `codigo_req` int(11) DEFAULT NULL COMMENT 'Cod. Requerimiento',
  `codigodelgruporeq` varchar(2) DEFAULT NULL COMMENT 'Grupo Requerimiento',
  `codigotiporeq` varchar(2) DEFAULT NULL COMMENT 'Tipo Requerimiento',
  `codigomotivoreq` varchar(4) DEFAULT NULL COMMENT 'Motivo Requerimiento',
  `codigodelcliente` int(11) DEFAULT NULL COMMENT 'Cod. Cliente',
  `apellidopaterno` varchar(35) DEFAULT NULL COMMENT 'Ap. Paterno',
  `apellidomaterno` varchar(35) DEFAULT NULL COMMENT 'Ap. Materno',
  `nombres` varchar(30) DEFAULT NULL COMMENT 'Nombres',
  `indicador_vip` varchar(10) DEFAULT NULL COMMENT 'Indicador VIP',
  `categoria_cliente` varchar(50) DEFAULT NULL COMMENT 'Cat. Cliente',
  `codigodelservicio` int(11) DEFAULT NULL COMMENT 'Cod. Servicio',
  `clasedeservicio` varchar(4) DEFAULT NULL COMMENT 'Clase Servicio',
  `categoriadeservicio` varchar(2) DEFAULT NULL COMMENT 'Categoria Servicio',
  `oficina_administrativa` varchar(3) DEFAULT NULL COMMENT 'Oficina Administrativa',
  `departamento` varchar(3) DEFAULT NULL COMMENT 'Departamento',
  `provincia` varchar(3) DEFAULT NULL COMMENT 'Provincia',
  `distrito` varchar(3) DEFAULT NULL COMMENT 'Distrito',
  `tipodevia` varchar(2) DEFAULT NULL COMMENT 'Tipo Via',
  `nombredelavia` varchar(30) DEFAULT NULL COMMENT 'Nombre vía',
  `numero` int(11) DEFAULT NULL COMMENT 'Numero',
  `piso` varchar(2) DEFAULT NULL COMMENT 'Piso',
  `interior` varchar(5) DEFAULT NULL COMMENT 'Interior',
  `manzana` varchar(5) DEFAULT NULL COMMENT 'Manzana',
  `lote` varchar(5) DEFAULT NULL COMMENT 'Lote',
  `nodo` varchar(2) DEFAULT NULL COMMENT 'Nodo',
  `plano` varchar(4) DEFAULT NULL COMMENT 'Plano',
  `sector` varchar(5) DEFAULT NULL COMMENT 'Sector',
  `troba` varchar(4) DEFAULT NULL COMMENT 'Troba',
  `lex` varchar(4) DEFAULT NULL COMMENT 'Amplificador',
  `tap` varchar(4) DEFAULT NULL COMMENT 'Tap',
  `borne` varchar(4) DEFAULT NULL COMMENT 'Borne',
  `estacion` varchar(8) DEFAULT NULL COMMENT 'Estacion',
  `situacion` varchar(4) DEFAULT NULL COMMENT 'Situacion',
  `estado` varchar(1) DEFAULT NULL COMMENT 'Estado Req',
  `fecharegistro` varchar(20) DEFAULT NULL COMMENT 'Fecha Registro',
  `usuariogeneracion` varchar(12) DEFAULT NULL COMMENT 'Usuario Genera',
  `ot` int(11) DEFAULT NULL COMMENT 'Orde de Trabajo',
  `fechaasignacion` varchar(20) DEFAULT NULL COMMENT 'Fecha Asignación',
  `estadoot` varchar(1) DEFAULT NULL COMMENT 'Estado OT',
  `contrata` int(11) DEFAULT NULL COMMENT 'Contrata',
  `fecha_liquidacion` datetime DEFAULT NULL COMMENT 'Fecha Liquidacion',
  `cod_liquidacion` varchar(10) DEFAULT NULL COMMENT 'Cod. Liquidacion',
  `detalle_liquidacion` varchar(10) DEFAULT NULL COMMENT 'Det. Liquidacion',
  `flag_playa` varchar(1) DEFAULT NULL COMMENT 'Indicador de Playa (1/0)',
  `nom_playa` varchar(100) DEFAULT NULL COMMENT 'Nombre Playa',
  `km_playa` varchar(10) DEFAULT NULL COMMENT 'Kilometro de Playa',
  `CRC` varchar(9) DEFAULT NULL COMMENT 'Codigo de reserva CRC',
  `bloque_canales` varchar(200) DEFAULT NULL COMMENT 'Bloque de Canales',
  `direccion_facturacion` varchar(200) DEFAULT NULL COMMENT 'Direccion de facturacion',
  `desc_motivo` varchar(100) DEFAULT NULL COMMENT 'Descripcion del motivo',
  `tipo_cliente_playa` varchar(1) DEFAULT NULL COMMENT 'Tipo de Cliente Playa (I/O)',
  `fecha_upload` datetime DEFAULT NULL,
  `nombre_archivo` varchar(40) DEFAULT NULL,
  KEY `idx_codcli` (`codigodelcliente`),
  KEY `idx_codser` (`codigodelservicio`),
  KEY `idx_contrata` (`contrata`),
  KEY `idx_codigo_req` (`codigo_req`),
  KEY `codigomotivoreq` (`codigomotivoreq`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `averias_modem_piloto`
--

DROP TABLE IF EXISTS `averias_modem_piloto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `averias_modem_piloto` (
  `codigodelcliente` int(11) DEFAULT NULL,
  `codigo_req` int(11) DEFAULT NULL,
  `ot` int(11) DEFAULT NULL,
  `fecharegistro` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `contrata` int(11) DEFAULT NULL,
  `codigotiporeq` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `codigomotivoreq` varchar(4) CHARACTER SET utf8 DEFAULT NULL,
  `apellidopaterno` varchar(35) CHARACTER SET utf8 DEFAULT NULL,
  `apellidomaterno` varchar(35) CHARACTER SET utf8 DEFAULT NULL,
  `nombres` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `nodo` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `plano` varchar(4) CHARACTER SET utf8 DEFAULT NULL,
  `Fabricante` varchar(20) DEFAULT NULL,
  `Modelo` varchar(100) DEFAULT NULL,
  `Versioon` varchar(100) DEFAULT NULL,
  `MACAddress` varchar(20) DEFAULT NULL,
  `fecha_upload` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `averias_ttpp`
--

DROP TABLE IF EXISTS `averias_ttpp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `averias_ttpp` (
  `nodo` varchar(2) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Nodo',
  `troba` varchar(4) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Troba',
  `dia` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `hora` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `cant` bigint(21) NOT NULL,
  UNIQUE KEY `nodo_2` (`nodo`,`troba`,`dia`,`hora`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `dia` (`dia`),
  KEY `hora` (`hora`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bajas_catv`
--

DROP TABLE IF EXISTS `bajas_catv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bajas_catv` (
  `codigo_req` int(11) DEFAULT NULL,
  `codigo_del_grupo_req` varchar(2) DEFAULT NULL,
  `codigo_tipo_req` varchar(2) DEFAULT NULL,
  `codigo_motivo_req` varchar(4) DEFAULT NULL,
  `codigo_del_cliente` int(11) DEFAULT NULL,
  `apellido_paterno` varchar(35) DEFAULT NULL,
  `apellido_materno` varchar(35) DEFAULT NULL,
  `nombres` varchar(30) DEFAULT NULL,
  `indicador_vip` varchar(10) DEFAULT NULL,
  `categoria_cliente` varchar(50) DEFAULT NULL,
  `codigo_del_servicio` int(11) DEFAULT NULL,
  `clase_de_servicio` varchar(100) DEFAULT NULL,
  `categoria_de_servicio` varchar(2) DEFAULT NULL,
  `oficina_administrativa` varchar(3) DEFAULT NULL,
  `departamento` varchar(3) DEFAULT NULL,
  `provincia` varchar(3) DEFAULT NULL,
  `distrito` varchar(3) DEFAULT NULL,
  `tipo_de_via` varchar(2) DEFAULT NULL,
  `nombre_de_la_via` varchar(30) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `piso` varchar(2) DEFAULT NULL,
  `interior` varchar(5) DEFAULT NULL,
  `manzana` varchar(5) DEFAULT NULL,
  `lote` varchar(5) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `plano` varchar(4) DEFAULT NULL,
  `sector` varchar(5) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `lex` varchar(4) DEFAULT NULL,
  `tap` varchar(4) DEFAULT NULL,
  `borne` varchar(4) DEFAULT NULL,
  `estacion` varchar(8) DEFAULT NULL,
  `situacion` varchar(4) DEFAULT NULL,
  `estado` varchar(1) DEFAULT NULL,
  `fecha_registro` varchar(20) DEFAULT NULL,
  `usuario_generacion` varchar(12) DEFAULT NULL,
  `ot` int(11) DEFAULT NULL,
  `fecha_asignacion` varchar(20) DEFAULT NULL,
  `estado_ot` varchar(1) DEFAULT NULL,
  `contrata` int(11) DEFAULT NULL,
  `tecnico` varchar(12) DEFAULT NULL,
  `codigo_de_liquidacion` varchar(12) DEFAULT NULL,
  `fecha_liquidacion` datetime DEFAULT NULL,
  `fecha_programacion` datetime DEFAULT NULL,
  `fecha_informacion` datetime DEFAULT NULL,
  `fecha_llegada` datetime DEFAULT NULL,
  `cross_cms` varchar(20) DEFAULT NULL,
  `sit_envio_actu` varchar(50) DEFAULT NULL,
  `ind_paquete` varchar(30) DEFAULT NULL,
  `tipvis_gestel` varchar(30) DEFAULT NULL,
  `tipvis_cms` varchar(30) DEFAULT NULL,
  `cod_sol_pai` varchar(30) DEFAULT NULL,
  `stdo_sol_pai` varchar(30) DEFAULT NULL,
  `fecha_reg_pai` datetime DEFAULT NULL,
  `ind_pos_fraude` varchar(30) DEFAULT NULL,
  `cod_mot_pos_fraude` varchar(10) DEFAULT NULL,
  `desc_mot_pos_fraude` varchar(100) DEFAULT NULL,
  `nro_ooss_gestel` varchar(30) DEFAULT NULL,
  `stdo_ooss_gestel` varchar(20) DEFAULT NULL,
  `desc_stdo_ooss_gestel` varchar(100) DEFAULT NULL,
  `tip_paquete` varchar(30) DEFAULT NULL,
  `cod_cmts` varchar(30) DEFAULT NULL,
  `desc_cmts2` varchar(100) DEFAULT NULL,
  `peticion_atis` varchar(30) DEFAULT NULL,
  `telefono_de_contacto` varchar(10) DEFAULT NULL,
  `celular_de_contacto` varchar(10) DEFAULT NULL,
  UNIQUE KEY `NewIndex1` (`codigo_req`),
  KEY `NewIndex2` (`codigo_del_cliente`),
  KEY `NewIndex3` (`ot`),
  KEY `idx_servicio` (`codigo_del_servicio`),
  KEY `fechaderegistro` (`fecha_registro`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `lex` (`lex`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `catv_descodliq`
--

DROP TABLE IF EXISTS `catv_descodliq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catv_descodliq` (
  `codliq` varchar(5) DEFAULT NULL,
  `desliq` varchar(150) DEFAULT NULL,
  `coddet` varchar(5) DEFAULT NULL,
  `desdet` varchar(150) DEFAULT NULL,
  `red` varchar(50) DEFAULT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `clasificacion` varchar(50) DEFAULT NULL,
  `nivelresp` varchar(50) DEFAULT NULL,
  `sumcod` varchar(20) DEFAULT NULL,
  KEY `NewIndex1` (`codliq`),
  KEY `NewIndex2` (`coddet`),
  KEY `NewIndex3` (`sumcod`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `clientes_cms`
--

DROP TABLE IF EXISTS `clientes_cms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes_cms` (
  `troba` varchar(100) DEFAULT NULL,
  `linext` varchar(100) DEFAULT NULL,
  `tap` varchar(100) DEFAULT NULL,
  `bornes` varchar(100) DEFAULT NULL,
  `nodo` varchar(100) DEFAULT NULL,
  `departamento` varchar(100) DEFAULT NULL,
  `provincia` varchar(100) DEFAULT NULL,
  `cliente` int(15) DEFAULT NULL,
  `apaterno` varchar(100) DEFAULT NULL,
  `amaterno` varchar(100) DEFAULT NULL,
  `nombres` varchar(100) DEFAULT NULL,
  `elemento` varchar(100) DEFAULT NULL,
  `estborne` varchar(100) DEFAULT NULL,
  `fecregi` varchar(100) DEFAULT NULL,
  `reqservicio` varchar(100) DEFAULT NULL,
  `codservicio` int(15) DEFAULT NULL,
  `oficina` varchar(100) DEFAULT NULL,
  `usuario` varchar(100) DEFAULT NULL,
  `indasig` varchar(100) DEFAULT NULL,
  `codsplit` varchar(100) DEFAULT NULL,
  `feccrea` varchar(100) DEFAULT NULL,
  `tipmotiv` varchar(100) DEFAULT NULL,
  `motivo` varchar(100) DEFAULT NULL,
  `observ` varchar(100) DEFAULT NULL,
  `indsplit` varchar(100) DEFAULT NULL,
  `indfiltalta` varchar(100) DEFAULT NULL,
  `indfiltbaja` varchar(100) DEFAULT NULL,
  `indprotec` varchar(100) DEFAULT NULL,
  `indcandado` varchar(100) DEFAULT NULL,
  `indcrq75` varchar(100) DEFAULT NULL,
  `indjebe` varchar(100) DEFAULT NULL,
  `indsenal` varchar(100) DEFAULT NULL,
  `indnumvias` varchar(100) DEFAULT NULL,
  `fecha_insert` datetime DEFAULT NULL,
  `clavetap` varchar(50) DEFAULT NULL,
  `claveborne` varchar(50) DEFAULT NULL,
  `id` bigint(20) NOT NULL DEFAULT '0',
  `direccion_cliente` varchar(255) DEFAULT NULL,
  `direccion_tap` varchar(255) DEFAULT NULL,
  `fecha_upload` datetime DEFAULT NULL,
  KEY `idxclavetap` (`clavetap`),
  KEY `NewIndex1` (`cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `clientes_un_servicio`
--

DROP TABLE IF EXISTS `clientes_un_servicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes_un_servicio` (
  `cliente` int(11) DEFAULT NULL,
  `servicio` int(11) NOT NULL,
  PRIMARY KEY (`servicio`),
  KEY `cliente` (`cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `clientesm1_xy`
--

DROP TABLE IF EXISTS `clientesm1_xy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientesm1_xy` (
  `servicio` int(11) NOT NULL,
  `desdpt` varchar(100) DEFAULT NULL,
  `despvc` varchar(100) DEFAULT NULL,
  `desdtt` varchar(100) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `plano` varchar(4) DEFAULT NULL,
  `CONCATEN` varchar(100) DEFAULT NULL,
  `NMTIPVIA_TDP` varchar(20) DEFAULT NULL,
  `NOM_VIA` varchar(100) DEFAULT NULL,
  `NUM_PUER` varchar(20) DEFAULT NULL,
  `NMTIPINT` varchar(20) DEFAULT NULL,
  `NUM_INT` varchar(20) DEFAULT NULL,
  `NMTIPVIV` varchar(20) DEFAULT NULL,
  `NOM_VIV` varchar(100) DEFAULT NULL,
  `MZ_NORM` varchar(20) DEFAULT NULL,
  `NUM_LOTE` varchar(20) DEFAULT NULL,
  `NMTIPURB_TDP` varchar(20) DEFAULT NULL,
  `URB_CONC` varchar(100) DEFAULT NULL,
  `x` varchar(30) DEFAULT NULL,
  `y` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`servicio`),
  KEY `nodo` (`nodo`),
  KEY `plano` (`plano`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `clientesm1_xy_backup`
--

DROP TABLE IF EXISTS `clientesm1_xy_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientesm1_xy_backup` (
  `servicio` varchar(255) DEFAULT NULL,
  `desdpt` varchar(255) DEFAULT NULL,
  `despvc` varchar(255) DEFAULT NULL,
  `desdtt` varchar(255) DEFAULT NULL,
  `nodo` varchar(255) DEFAULT NULL,
  `plano` varchar(255) DEFAULT NULL,
  `CONCATEN` varchar(255) DEFAULT NULL,
  `NMTIPVIA_TDP` varchar(255) DEFAULT NULL,
  `NOM_VIA` varchar(255) DEFAULT NULL,
  `NUM_PUER` varchar(255) DEFAULT NULL,
  `NMTIPINT` varchar(255) DEFAULT NULL,
  `NUM_INT` varchar(255) DEFAULT NULL,
  `NMTIPVIV` varchar(255) DEFAULT NULL,
  `NOM_VIV` varchar(255) DEFAULT NULL,
  `MZ_NORM` varchar(255) DEFAULT NULL,
  `NUM_LOTE` varchar(255) DEFAULT NULL,
  `NMTIPURB_TDP` varchar(255) DEFAULT NULL,
  `URB_CONC` varchar(255) DEFAULT NULL,
  `x` varchar(255) DEFAULT NULL,
  `y` varchar(255) DEFAULT NULL,
  KEY `servicio` (`servicio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cms_tiporeq_motivo`
--

DROP TABLE IF EXISTS `cms_tiporeq_motivo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_tiporeq_motivo` (
  `cabecera` int(11) DEFAULT NULL,
  `oficina` varchar(3) DEFAULT NULL,
  `grupo_req` varchar(2) DEFAULT NULL,
  `des_grupo_req` varchar(70) DEFAULT NULL,
  `tipo_req` varchar(2) DEFAULT NULL,
  `des_tipo_req` varchar(70) DEFAULT NULL,
  `motivo` varchar(4) DEFAULT NULL,
  `des_motivo` varchar(70) DEFAULT NULL,
  `ruta` int(11) DEFAULT NULL,
  `des_ruta` varchar(70) DEFAULT NULL,
  `estacion` varchar(20) DEFAULT NULL,
  `estado` varchar(3) DEFAULT NULL,
  `ind_apro_fact` varchar(3) DEFAULT NULL,
  KEY `tipo_req` (`tipo_req`),
  KEY `motivo` (`motivo`),
  KEY `grupo_req` (`grupo_req`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cms_tiporeq_motivo_1`
--

DROP TABLE IF EXISTS `cms_tiporeq_motivo_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_tiporeq_motivo_1` (
  `cabecera` int(11) DEFAULT NULL,
  `oficina` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `grupo_req` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `des_grupo_req` varchar(70) CHARACTER SET utf8 DEFAULT NULL,
  `tipo_req` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `des_tipo_req` varchar(70) CHARACTER SET utf8 DEFAULT NULL,
  `motivo` varchar(4) CHARACTER SET utf8 DEFAULT NULL,
  `des_motivo` varchar(70) CHARACTER SET utf8 DEFAULT NULL,
  `ruta` int(11) DEFAULT NULL,
  `des_ruta` varchar(70) CHARACTER SET utf8 DEFAULT NULL,
  `estacion` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `estado` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `ind_apro_fact` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  KEY `grupo_req` (`grupo_req`),
  KEY `tipo_req` (`tipo_req`),
  KEY `motivo` (`motivo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `codmotv`
--

DROP TABLE IF EXISTS `codmotv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `codmotv` (
  `codmotv` varchar(4) CHARACTER SET utf8 DEFAULT NULL,
  `desmotv` varchar(60) CHARACTER SET utf8 DEFAULT NULL,
  KEY `codmotv` (`codmotv`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `correccion_facilidades`
--

DROP TABLE IF EXISTS `correccion_facilidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `correccion_facilidades` (
  `CODCLI` varchar(255) DEFAULT NULL,
  `SERVICIO` varchar(255) DEFAULT NULL,
  `X_CLIENTE` varchar(255) DEFAULT NULL,
  `Y_CLIENTE` varchar(255) DEFAULT NULL,
  `TROBA_` varchar(255) DEFAULT NULL,
  `CODTAP_` varchar(255) DEFAULT NULL,
  `X_TAP` varchar(255) DEFAULT NULL,
  `Y_TAP` varchar(255) DEFAULT NULL,
  `DISTANCIA` varchar(255) DEFAULT NULL,
  `CAMBIO` varchar(255) DEFAULT NULL,
  KEY `id1` (`CODCLI`),
  KEY `id2` (`SERVICIO`),
  KEY `id3` (`DISTANCIA`),
  KEY `id4` (`CAMBIO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `correccion_facilidades2`
--

DROP TABLE IF EXISTS `correccion_facilidades2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `correccion_facilidades2` (
  `CODCLI` varchar(255) DEFAULT NULL,
  `SERVICIO` varchar(255) DEFAULT NULL,
  `DISTANCIA` varchar(255) DEFAULT NULL,
  KEY `CODCLI` (`CODCLI`),
  KEY `SERVICIO` (`SERVICIO`),
  KEY `DISTANCIA` (`DISTANCIA`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dias`
--

DROP TABLE IF EXISTS `dias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dias` (
  `dias` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `edificios`
--

DROP TABLE IF EXISTS `edificios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edificios` (
  `CLIENTE` int(10) DEFAULT NULL,
  `CUENTA` int(10) DEFAULT NULL,
  `SERVICIO` int(10) DEFAULT NULL,
  `CON_SRV` int(11) DEFAULT NULL,
  `CLASESRV` varchar(2) DEFAULT NULL,
  `TIPOSRV` int(11) DEFAULT NULL,
  `CATEGORIA` varchar(5) DEFAULT NULL,
  `OFI_CLI` varchar(3) DEFAULT NULL,
  `OFI_SRV` varchar(3) DEFAULT NULL,
  `CODDPT` varchar(3) DEFAULT NULL,
  `DESDPT` varchar(15) DEFAULT NULL,
  `CODPVC` varchar(3) DEFAULT NULL,
  `DESPVC` varchar(30) DEFAULT NULL,
  `CODDTT` varchar(3) DEFAULT NULL,
  `DESDTT` varchar(40) DEFAULT NULL,
  `INDFACT` varchar(2) DEFAULT NULL,
  `NODO` varchar(4) DEFAULT NULL,
  `DESNODO` varchar(30) DEFAULT NULL,
  `PLANO` varchar(5) DEFAULT NULL,
  `XIND_VIP` varchar(1) DEFAULT NULL,
  `TIPO_DOCUM` varchar(2) DEFAULT NULL,
  `NUMERORUC` varchar(12) DEFAULT NULL,
  `NUMERODOC` varchar(10) DEFAULT NULL,
  `TELEFCL1` varchar(15) DEFAULT NULL,
  `TELEFCL2` varchar(15) DEFAULT NULL,
  `TELEFCL3` varchar(15) DEFAULT NULL,
  `PETICATIS` varchar(20) DEFAULT NULL,
  `SEGMCLIENT` varchar(10) DEFAULT NULL,
  `ESTADODUNA` varchar(15) DEFAULT NULL,
  `NOMBRE` varchar(50) DEFAULT NULL,
  `APE_PAT` varchar(50) DEFAULT NULL,
  `APE_MAT` varchar(40) DEFAULT NULL,
  `CODNIT` varchar(10) DEFAULT NULL,
  `UBIGEOGIS` varchar(10) DEFAULT NULL,
  `DESUBIGEGI` varchar(40) DEFAULT NULL,
  `CODLEX` varchar(10) DEFAULT NULL,
  `CODTAP` varchar(10) DEFAULT NULL,
  `CODBOR` varchar(10) DEFAULT NULL,
  `DIREC_INST` varchar(90) DEFAULT NULL,
  `IND_DUO` varchar(10) DEFAULT NULL,
  `UBIPLAN` varchar(9) DEFAULT NULL,
  `PAIS` varchar(4) DEFAULT NULL,
  `UBIGEO` varchar(6) DEFAULT NULL,
  `ZONAL_ANT` varchar(3) DEFAULT NULL,
  `REGION` varchar(8) DEFAULT NULL,
  `ZONAL_NEW` varchar(10) DEFAULT NULL,
  `IND_DUNA` varchar(10) DEFAULT NULL,
  `AÑO_DUN` varchar(6) DEFAULT NULL,
  `CRUCE` varchar(4) DEFAULT NULL,
  `PAQUETE` varchar(15) DEFAULT NULL,
  `PAQUETE1` varchar(15) DEFAULT NULL,
  `SUB_NEG` varchar(4) DEFAULT NULL,
  `PROVEEDOR` varchar(4) DEFAULT NULL,
  `TECNOLOGIA` varchar(10) DEFAULT NULL,
  `PERU8K` varchar(7) DEFAULT NULL,
  `MARCAA` varchar(3) DEFAULT NULL,
  `CND_SRV_09` int(11) DEFAULT NULL,
  `CND_SRV_10` int(11) DEFAULT NULL,
  `CND_SRV_11` int(11) DEFAULT NULL,
  `EXCLUSANT` varchar(50) DEFAULT NULL,
  `PROV_ANT` varchar(12) DEFAULT NULL,
  `NEGO_ANT` varchar(10) DEFAULT NULL,
  `CSER_ANT` varchar(2) DEFAULT NULL,
  `PAQU_ANT` varchar(15) DEFAULT NULL,
  `PAQU1_ANT` varchar(10) DEFAULT NULL,
  `SEGMENTO` varchar(15) DEFAULT NULL,
  `SEGMENTO0` varchar(15) DEFAULT NULL,
  `EX_CTA` varchar(13) DEFAULT NULL,
  `MARCA_SUS` int(11) DEFAULT NULL,
  `EXCLU_SUS` varchar(32) DEFAULT NULL,
  `EX_BJ_INCO` varchar(50) DEFAULT NULL,
  `IND_EXCLUS` varchar(46) DEFAULT NULL,
  `SEG_CMS` varchar(2) DEFAULT NULL,
  `JEFCOM` varchar(10) DEFAULT NULL,
  `EECC` varchar(8) DEFAULT NULL,
  `REGION_COC` varchar(8) DEFAULT NULL,
  `ZON_REGION` varchar(4) DEFAULT NULL,
  `PREM_MAS` varchar(7) DEFAULT NULL,
  `DET_REGION` varchar(15) DEFAULT NULL,
  `JEF_REGION` varchar(8) DEFAULT NULL,
  `SEG_SLAS` varchar(11) DEFAULT NULL,
  `TOP_NOTOP` varchar(17) DEFAULT NULL,
  `JEFATU_NUE` varchar(4) DEFAULT NULL,
  `CLIEN_SRV` varchar(15) DEFAULT NULL,
  `MICROZONA` varchar(10) DEFAULT NULL,
  `LLAVE_UBIG` varchar(15) DEFAULT NULL,
  `TERRENO` varchar(15) DEFAULT NULL,
  `EXCLUYE` varchar(1) DEFAULT NULL,
  `IND_VIP` varchar(1) DEFAULT NULL,
  `TELEFONO` int(11) DEFAULT NULL,
  `TIPO` varchar(10) DEFAULT NULL,
  `DIRECCION` varchar(75) DEFAULT NULL,
  `IP` varchar(20) DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `CMTS` varchar(20) DEFAULT NULL,
  `TEC` varchar(5) DEFAULT NULL,
  `DIGITALIZA` varchar(2) DEFAULT NULL,
  `PAQUETE_HD` varchar(2) DEFAULT NULL,
  `SERVPACK` varchar(50) DEFAULT NULL,
  `VEL_SERVPA` varchar(10) DEFAULT NULL,
  `TIPO_VIA` varchar(4) DEFAULT NULL,
  `VIA` varchar(39) DEFAULT NULL,
  `NRO` varchar(6) DEFAULT NULL,
  `PISO` varchar(4) DEFAULT NULL,
  `INTERIOR` varchar(7) DEFAULT NULL,
  `MZ` varchar(7) DEFAULT NULL,
  `LT` varchar(7) DEFAULT NULL,
  `TIPOPERU8K` varchar(20) DEFAULT NULL,
  `CLIENCCM1` varchar(2) DEFAULT NULL,
  `VOZIP` varchar(2) DEFAULT NULL,
  `PRODCOMER` varchar(100) DEFAULT NULL,
  `VEL_PRODCO` varchar(50) DEFAULT NULL,
  `DIGITAL2` int(11) DEFAULT NULL,
  `DIG_FECHA` varchar(20) DEFAULT NULL,
  `DIG_ESTADO` varchar(18) DEFAULT NULL,
  `DECO_ACT` int(11) DEFAULT NULL,
  `DECO_SUSP` int(11) DEFAULT NULL,
  `TIPREQ_PED` varchar(10) DEFAULT NULL,
  `proceso` date DEFAULT NULL,
  `edificio` varchar(6) CHARACTER SET utf8 NOT NULL DEFAULT '',
  KEY `NewIndex1` (`CLIENTE`),
  KEY `NewIndex2` (`SERVICIO`),
  KEY `NewIndex3` (`NODO`),
  KEY `NewIndex4` (`PLANO`),
  KEY `NewIndex5` (`edificio`),
  KEY `NewIndex6` (`CODLEX`),
  KEY `NewIndex7` (`CODTAP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fftt_harold`
--

DROP TABLE IF EXISTS `fftt_harold`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fftt_harold` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplif` varchar(2) DEFAULT NULL,
  `nnodo` varchar(2) DEFAULT NULL,
  `ntroba` varchar(4) DEFAULT NULL,
  `clavefftt` varchar(8) DEFAULT NULL,
  UNIQUE KEY `clavefftt` (`nodo`,`troba`,`amplif`),
  KEY `troba` (`troba`),
  KEY `amplif` (`amplif`),
  KEY `nodo` (`nodo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gestion_alertas`
--

DROP TABLE IF EXISTS `gestion_alertas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gestion_alertas` (
  `ITEM` int(11) NOT NULL AUTO_INCREMENT,
  `NODO` varchar(2) DEFAULT NULL,
  `TROBA` varchar(4) DEFAULT NULL,
  `AMP` varchar(80) DEFAULT NULL,
  `TIPODETRABAJO` varchar(200) DEFAULT NULL,
  `SUPERVISOR` varchar(150) DEFAULT NULL,
  `FINICIO` varchar(20) DEFAULT NULL,
  `HINICIO` varchar(10) DEFAULT NULL,
  `HTERMINO` varchar(10) DEFAULT NULL,
  `HORARIO` varchar(10) DEFAULT NULL,
  `CORTESN` varchar(10) DEFAULT NULL,
  `OPERADOR` varchar(100) DEFAULT NULL,
  `FECHA` varchar(20) DEFAULT NULL,
  `HORA` varchar(10) DEFAULT NULL,
  `TRABAJO` varchar(100) DEFAULT NULL,
  `REMEDY` varchar(10) DEFAULT NULL,
  `TECNICO` varchar(100) DEFAULT NULL,
  `RPM` varchar(10) DEFAULT NULL,
  `CONTRATA` varchar(60) DEFAULT NULL,
  `HORACIERRE` varchar(10) DEFAULT NULL,
  `OBSERVACIONES` varchar(200) DEFAULT NULL,
  `ESTADO` varchar(10) DEFAULT NULL,
  `fecha_registro` varchar(20) DEFAULT NULL,
  `fecha_apertura` varchar(20) DEFAULT NULL,
  `fecha_cierre` varchar(20) DEFAULT NULL,
  `fecha_cancela` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ITEM`),
  KEY `NewIndex1` (`NODO`),
  KEY `NewIndex2` (`TROBA`),
  KEY `NewIndex3` (`FINICIO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `glteasg001`
--

DROP TABLE IF EXISTS `glteasg001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glteasg001` (
  `oficina` varchar(100) DEFAULT NULL,
  `departamento` varchar(100) DEFAULT NULL,
  `provincia` varchar(102) DEFAULT NULL,
  `nodo` varchar(100) DEFAULT NULL,
  `troba` varchar(100) DEFAULT NULL,
  `linext` varchar(100) DEFAULT NULL,
  `tap` varchar(100) DEFAULT NULL,
  `tipotap` varchar(100) DEFAULT NULL,
  `estado` varchar(100) DEFAULT NULL,
  `nroposte` varchar(100) DEFAULT NULL,
  `numborne` varchar(100) DEFAULT NULL,
  `bornesocup` varchar(100) DEFAULT NULL,
  `imped` varchar(100) DEFAULT NULL,
  `plano` varchar(100) DEFAULT NULL,
  `codarea` varchar(100) DEFAULT NULL,
  `sector` varchar(100) DEFAULT NULL,
  `spliter` varchar(100) DEFAULT NULL,
  `indtapdirec` varchar(100) DEFAULT NULL,
  `fecreac` varchar(100) DEFAULT NULL,
  `fecinst` varchar(100) DEFAULT NULL,
  `fecrevi` varchar(100) DEFAULT NULL,
  `fecactu` varchar(100) DEFAULT NULL,
  `fecregi` varchar(100) DEFAULT NULL,
  `distrito` varchar(100) DEFAULT NULL,
  `desdistrito` varchar(100) DEFAULT NULL,
  `tipovia` varchar(100) DEFAULT NULL,
  `nomvia` varchar(100) DEFAULT NULL,
  `numvia` varchar(100) DEFAULT NULL,
  `inte` varchar(100) DEFAULT NULL,
  `piso` varchar(100) DEFAULT NULL,
  `manz` varchar(100) DEFAULT NULL,
  `lote` varchar(100) DEFAULT NULL,
  `tipourb` varchar(100) DEFAULT NULL,
  `urb` varchar(100) DEFAULT NULL,
  `usuario` varchar(100) DEFAULT NULL,
  `fecha_insert` datetime DEFAULT NULL,
  `clavetap` varchar(50) DEFAULT NULL,
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `linext` (`linext`),
  KEY `tap` (`tap`),
  KEY `NewIndex1` (`clavetap`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `horas`
--

DROP TABLE IF EXISTS `horas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `horas` (
  `horas` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `masivas`
--

DROP TABLE IF EXISTS `masivas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `masivas` (
  `Oficina` varchar(3) DEFAULT NULL,
  `Requerimiento` int(11) DEFAULT NULL,
  `Nodo` varchar(2) DEFAULT NULL,
  `Plano` varchar(4) DEFAULT NULL,
  `Departamento` varchar(4) DEFAULT NULL,
  `Provincia` varchar(4) DEFAULT NULL,
  `Tipo_Requerimiento` varchar(4) DEFAULT NULL,
  `Numero_Fercuencia_Averia` int(11) DEFAULT NULL,
  `Tipo_Frecuencia_Averia` varchar(100) DEFAULT NULL,
  `Codigo_Motivo` varchar(4) DEFAULT NULL,
  `Motivo` varchar(100) DEFAULT NULL,
  `codmotact` varchar(4) DEFAULT NULL,
  `desmotact` varchar(100) DEFAULT NULL,
  `nro_tranf` int(11) DEFAULT NULL,
  `Situacion` varchar(4) DEFAULT NULL,
  `Codigo_Contrata` int(11) DEFAULT NULL,
  `Nombre_Contrata` varchar(100) DEFAULT NULL,
  `codareahbl` varchar(50) DEFAULT NULL,
  `IndicadorActuacion` varchar(10) DEFAULT NULL,
  `IndicadorCita` varchar(10) DEFAULT NULL,
  `CodigoCita` varchar(10) DEFAULT NULL,
  `FechaInicioCita` varchar(20) DEFAULT NULL,
  `FechaFinCita` varchar(20) DEFAULT NULL,
  `FechaCumplimiento` varchar(20) DEFAULT NULL,
  `EstadoCita` varchar(10) DEFAULT NULL,
  `EstadoActuacionGaudi` varchar(20) DEFAULT NULL,
  `EstadoActuacionCMS` varchar(20) DEFAULT NULL,
  `FechaEnvioGaudi` varchar(20) DEFAULT NULL,
  `FechaRecepcionActuacion` varchar(20) DEFAULT NULL,
  `CodigoErrorEnvio` varchar(10) DEFAULT NULL,
  `DescripcionErrorEnvio` varchar(100) DEFAULT NULL,
  `fechaCambioEstado` varchar(20) DEFAULT NULL,
  `fechaliquidacion` varchar(20) DEFAULT NULL,
  `fechaInformada` varchar(20) DEFAULT NULL,
  `fechaRecepcionCierre` varchar(20) DEFAULT NULL,
  `fechacompletoCierre` varchar(20) DEFAULT NULL,
  `CodigoErrorCierre` varchar(10) DEFAULT NULL,
  `DescripcionErrorCierre` varchar(100) DEFAULT NULL,
  `fechaCorrepcionCierre` varchar(20) DEFAULT NULL,
  `Usuario` varchar(20) DEFAULT NULL,
  `CodTipoAct` varchar(20) DEFAULT NULL,
  `Codigo_Tecnico` varchar(20) DEFAULT NULL,
  `Nombre_Tecnico` varchar(80) DEFAULT NULL,
  `fecpri_rec` varchar(20) DEFAULT NULL,
  `fecreg_mas` varchar(20) DEFAULT NULL,
  `Fecha_Asignacion` varchar(20) DEFAULT NULL,
  `Fecha_Ultima_Transferencia` varchar(20) DEFAULT NULL,
  `Fecha_Liquidacion` varchar(20) DEFAULT NULL,
  `Codigo_Franqueo` varchar(20) DEFAULT NULL,
  `Rubro` varchar(20) DEFAULT NULL,
  `Codigo_Liquidacion` varchar(20) DEFAULT NULL,
  `Descripcion_Codigo` varchar(100) DEFAULT NULL,
  `Codigo_Detalle` varchar(20) DEFAULT NULL,
  `Descripcion_Detalle` varchar(100) DEFAULT NULL,
  `Observacion_Orden_Trabajo` varchar(300) DEFAULT NULL,
  `Cantidad_Requerida` int(11) DEFAULT NULL,
  `Nro_Cantidad` int(11) DEFAULT NULL,
  `demotot_atn` int(11) DEFAULT NULL,
  `demotot_mas` int(11) DEFAULT NULL,
  `demotot_asig` int(11) DEFAULT NULL,
  `Trab_Realizado` varchar(2) DEFAULT NULL,
  `Estado_GO` varchar(2) DEFAULT NULL,
  `Solicitud_Tecnica` varchar(50) DEFAULT NULL,
  `Fecha_Envio_GO` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `masivas_historico`
--

DROP TABLE IF EXISTS `masivas_historico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `masivas_historico` (
  `check` int(11) NOT NULL AUTO_INCREMENT,
  `numfrecave` int(11) NOT NULL,
  `tipfrecave` varchar(2) DEFAULT NULL,
  `fecreg` varchar(20) DEFAULT NULL,
  `codofcadm` varchar(3) DEFAULT NULL,
  `codcmts` varchar(1) DEFAULT NULL,
  `codnod` varchar(2) NOT NULL,
  `nroplano` varchar(4) NOT NULL,
  `codtrtrn` varchar(4) DEFAULT NULL,
  `edofrecave` varchar(1) DEFAULT NULL,
  `cantreq` int(11) DEFAULT NULL,
  `nrocant` int(11) DEFAULT NULL,
  `fecultact` varchar(20) DEFAULT NULL,
  `coddpt` varchar(3) DEFAULT NULL,
  `codpvc` varchar(3) DEFAULT NULL,
  `codreqmnt` int(11) NOT NULL,
  `codctr` int(11) DEFAULT NULL,
  `codedo` varchar(1) DEFAULT NULL,
  `fecliq` varchar(20) DEFAULT NULL,
  `indorigreq` varchar(1) DEFAULT NULL,
  `cantreqliq` int(11) DEFAULT NULL,
  `codareahbl` varchar(10) DEFAULT NULL,
  `indactuacion` varchar(10) DEFAULT NULL,
  `indseginc` int(11) DEFAULT NULL,
  `indinc` int(11) DEFAULT NULL,
  `codinc` varchar(10) DEFAULT NULL,
  `fecha_upload` varchar(20) DEFAULT NULL,
  UNIQUE KEY `NewIndex4` (`codreqmnt`),
  KEY `NewIndex1` (`codnod`),
  KEY `NewIndex2` (`nroplano`),
  KEY `NewIndex3` (`fecreg`),
  KEY `check` (`check`)
) ENGINE=InnoDB AUTO_INCREMENT=8900873 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `masivas_liq`
--

DROP TABLE IF EXISTS `masivas_liq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `masivas_liq` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `fecha` varchar(10) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  `estado` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `masivas_temp`
--

DROP TABLE IF EXISTS `masivas_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `masivas_temp` (
  `check` int(11) NOT NULL AUTO_INCREMENT,
  `numfrecave` int(11) NOT NULL,
  `tipfrecave` varchar(2) DEFAULT NULL,
  `fecreg` varchar(20) DEFAULT NULL,
  `codofcadm` varchar(3) DEFAULT NULL,
  `codcmts` varchar(1) DEFAULT NULL,
  `codnod` varchar(2) NOT NULL,
  `nroplano` varchar(4) NOT NULL,
  `codtrtrn` varchar(4) DEFAULT NULL,
  `edofrecave` varchar(1) DEFAULT NULL,
  `cantreq` int(11) DEFAULT NULL,
  `nrocant` int(11) DEFAULT NULL,
  `fecultact` varchar(20) DEFAULT NULL,
  `coddpt` varchar(3) DEFAULT NULL,
  `codpvc` varchar(3) DEFAULT NULL,
  `codreqmnt` int(11) NOT NULL,
  `codctr` int(11) DEFAULT NULL,
  `codedo` varchar(1) DEFAULT NULL,
  `fecliq` varchar(20) DEFAULT NULL,
  `indorigreq` varchar(1) DEFAULT NULL,
  `cantreqliq` int(11) DEFAULT NULL,
  `codareahbl` varchar(10) DEFAULT NULL,
  `indactuacion` varchar(10) DEFAULT NULL,
  `indseginc` int(11) DEFAULT NULL,
  `indinc` int(11) DEFAULT NULL,
  `codinc` varchar(10) DEFAULT NULL,
  `fecha_upload` varchar(20) DEFAULT NULL,
  UNIQUE KEY `NewIndex4` (`codnod`,`nroplano`),
  KEY `NewIndex1` (`codnod`),
  KEY `NewIndex2` (`nroplano`),
  KEY `NewIndex3` (`fecreg`),
  KEY `check` (`check`)
) ENGINE=InnoDB AUTO_INCREMENT=8922133 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `masivas_temp_c`
--

DROP TABLE IF EXISTS `masivas_temp_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `masivas_temp_c` (
  `check` varchar(2) NOT NULL,
  `numfrecave` int(11) NOT NULL,
  `tipfrecave` varchar(2) DEFAULT NULL,
  `fecreg` varchar(20) DEFAULT NULL,
  `codofcadm` varchar(3) DEFAULT NULL,
  `codcmts` varchar(1) DEFAULT NULL,
  `codnod` varchar(2) NOT NULL,
  `nroplano` varchar(4) NOT NULL,
  `codtrtrn` varchar(4) DEFAULT NULL,
  `edofrecave` varchar(1) DEFAULT NULL,
  `cantreq` int(11) DEFAULT NULL,
  `nrocant` int(11) DEFAULT NULL,
  `fecultact` varchar(20) DEFAULT NULL,
  `coddpt` varchar(3) DEFAULT NULL,
  `codpvc` varchar(3) DEFAULT NULL,
  `codreqmnt` int(11) NOT NULL,
  `codctr` int(11) DEFAULT NULL,
  `codedo` varchar(1) DEFAULT NULL,
  `fecliq` varchar(20) DEFAULT NULL,
  `indorigreq` varchar(1) DEFAULT NULL,
  `cantreqliq` int(11) DEFAULT NULL,
  `codareahbl` varchar(10) DEFAULT NULL,
  `indactuacion` varchar(10) DEFAULT NULL,
  `indseginc` int(11) DEFAULT NULL,
  `indinc` int(11) DEFAULT NULL,
  `codinc` varchar(10) DEFAULT NULL,
  `fecha_upload` varchar(20) DEFAULT NULL,
  UNIQUE KEY `NewIndex4` (`codnod`,`nroplano`),
  KEY `NewIndex1` (`codnod`),
  KEY `NewIndex2` (`nroplano`),
  KEY `NewIndex3` (`fecreg`),
  KEY `check` (`check`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `masivas_tempx`
--

DROP TABLE IF EXISTS `masivas_tempx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `masivas_tempx` (
  `Oficina` varchar(50) DEFAULT NULL,
  `codreqmnt` int(11) DEFAULT NULL,
  `codnod` varchar(50) DEFAULT NULL,
  `nroplano` varchar(50) DEFAULT NULL,
  `Departamento` int(11) DEFAULT NULL,
  `Provincia` int(11) DEFAULT NULL,
  `Tipo_Requerimiento` varchar(50) DEFAULT NULL,
  `Numero_Fercuencia_Averia` int(11) DEFAULT NULL,
  `Tipo_Frecuencia_Averia` varchar(50) DEFAULT NULL,
  `Codigo_Motivo` varchar(50) DEFAULT NULL,
  `Motivo` varchar(50) DEFAULT NULL,
  `codmotact` int(11) DEFAULT NULL,
  `desmotact` varchar(50) DEFAULT NULL,
  `nro_tranf` int(11) DEFAULT NULL,
  `Situacion` int(11) DEFAULT NULL,
  `Codigo_Contrata` int(11) DEFAULT NULL,
  `Nombre_Contrata` varchar(50) DEFAULT NULL,
  `codareahbl` varchar(50) DEFAULT NULL,
  `IndicadorActuacion` varchar(50) DEFAULT NULL,
  `IndicadorCita` varchar(50) DEFAULT NULL,
  `CodigoCita` varchar(50) DEFAULT NULL,
  `FechaInicioCita` varchar(20) DEFAULT NULL,
  `FechaFinCita` varchar(20) DEFAULT NULL,
  `FechaCumplimiento` varchar(20) DEFAULT NULL,
  `EstadoCita` varchar(50) DEFAULT NULL,
  `EstadoActuacionGaudi` varchar(50) DEFAULT NULL,
  `EstadoActuacionCMS` varchar(50) DEFAULT NULL,
  `FechaEnvioGaudi` varchar(20) DEFAULT NULL,
  `FechaRecepcionActuacion` varchar(20) DEFAULT NULL,
  `CodigoErrorEnvio` varchar(50) DEFAULT NULL,
  `DescripcionErrorEnvio` varchar(50) DEFAULT NULL,
  `fechaCambioEstado` varchar(20) DEFAULT NULL,
  `fecliq` varchar(20) DEFAULT NULL,
  `fechaInformada` varchar(20) DEFAULT NULL,
  `fechaRecepcionCierre` varchar(20) DEFAULT NULL,
  `fechacompletoCierre` varchar(20) DEFAULT NULL,
  `CodigoErrorCierre` varchar(50) DEFAULT NULL,
  `DescripcionErrorCierre` varchar(50) DEFAULT NULL,
  `fechaCorrepcionCierre` varchar(20) DEFAULT NULL,
  `Usuario` varchar(50) DEFAULT NULL,
  `CodTipoAct` varchar(50) DEFAULT NULL,
  `Codigo_Tecnico` varchar(50) DEFAULT NULL,
  `Nombre_Tecnico` varchar(50) DEFAULT NULL,
  `fecpri_rec` varchar(50) DEFAULT NULL,
  `fecreg_mas` varchar(50) DEFAULT NULL,
  `fecreg` varchar(20) DEFAULT NULL,
  `Fecha_Ultima_Transferencia` varchar(20) DEFAULT NULL,
  `Fecha_Liquidacion` varchar(20) DEFAULT NULL,
  `Codigo_Franqueo` varchar(50) DEFAULT NULL,
  `Rubro` varchar(50) DEFAULT NULL,
  `Codigo_Liquidacion` varchar(50) DEFAULT NULL,
  `Descripcion_Codigo` varchar(50) DEFAULT NULL,
  `Codigo_Detalle` varchar(50) DEFAULT NULL,
  `Descripcion_Detalle` varchar(50) DEFAULT NULL,
  `Observacion_Orden_Trabajo` varchar(50) DEFAULT NULL,
  `Cantidad_Requerida` int(11) DEFAULT NULL,
  `Nro_Cantidad` int(11) DEFAULT NULL,
  `demotot_atn` varchar(50) DEFAULT NULL,
  `demotot_mas` varchar(50) DEFAULT NULL,
  `demotot_asig` int(11) DEFAULT NULL,
  `Trab_Realizado` varchar(50) DEFAULT NULL,
  `Estado_GO` varchar(50) DEFAULT NULL,
  `Solicitud_Tecnica` varchar(50) DEFAULT NULL,
  `fecha_upload` varchar(20) DEFAULT NULL,
  UNIQUE KEY `codreqmnt` (`codreqmnt`),
  KEY `codnod` (`codnod`),
  KEY `nroplano` (`nroplano`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `masivas_tempx_c`
--

DROP TABLE IF EXISTS `masivas_tempx_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `masivas_tempx_c` (
  `Oficina` varchar(50) DEFAULT NULL,
  `codreqmnt` int(11) DEFAULT NULL,
  `codnod` varchar(50) DEFAULT NULL,
  `nroplano` varchar(50) DEFAULT NULL,
  `Departamento` int(11) DEFAULT NULL,
  `Provincia` int(11) DEFAULT NULL,
  `Tipo_Requerimiento` varchar(50) DEFAULT NULL,
  `Numero_Fercuencia_Averia` int(11) DEFAULT NULL,
  `Tipo_Frecuencia_Averia` varchar(50) DEFAULT NULL,
  `Codigo_Motivo` varchar(50) DEFAULT NULL,
  `Motivo` varchar(50) DEFAULT NULL,
  `codmotact` int(11) DEFAULT NULL,
  `desmotact` varchar(50) DEFAULT NULL,
  `nro_tranf` int(11) DEFAULT NULL,
  `Situacion` int(11) DEFAULT NULL,
  `Codigo_Contrata` int(11) DEFAULT NULL,
  `Nombre_Contrata` varchar(50) DEFAULT NULL,
  `codareahbl` varchar(50) DEFAULT NULL,
  `IndicadorActuacion` varchar(50) DEFAULT NULL,
  `IndicadorCita` varchar(50) DEFAULT NULL,
  `CodigoCita` varchar(50) DEFAULT NULL,
  `FechaInicioCita` varchar(20) DEFAULT NULL,
  `FechaFinCita` varchar(20) DEFAULT NULL,
  `FechaCumplimiento` varchar(20) DEFAULT NULL,
  `EstadoCita` varchar(50) DEFAULT NULL,
  `EstadoActuacionGaudi` varchar(50) DEFAULT NULL,
  `EstadoActuacionCMS` varchar(50) DEFAULT NULL,
  `FechaEnvioGaudi` varchar(20) DEFAULT NULL,
  `FechaRecepcionActuacion` varchar(20) DEFAULT NULL,
  `CodigoErrorEnvio` varchar(50) DEFAULT NULL,
  `DescripcionErrorEnvio` varchar(50) DEFAULT NULL,
  `fechaCambioEstado` varchar(20) DEFAULT NULL,
  `fecliq` varchar(20) DEFAULT NULL,
  `fechaInformada` varchar(20) DEFAULT NULL,
  `fechaRecepcionCierre` varchar(20) DEFAULT NULL,
  `fechacompletoCierre` varchar(20) DEFAULT NULL,
  `CodigoErrorCierre` varchar(50) DEFAULT NULL,
  `DescripcionErrorCierre` varchar(50) DEFAULT NULL,
  `fechaCorrepcionCierre` varchar(20) DEFAULT NULL,
  `Usuario` varchar(50) DEFAULT NULL,
  `CodTipoAct` varchar(50) DEFAULT NULL,
  `Codigo_Tecnico` varchar(50) DEFAULT NULL,
  `Nombre_Tecnico` varchar(50) DEFAULT NULL,
  `fecpri_rec` varchar(50) DEFAULT NULL,
  `fecreg_mas` varchar(50) DEFAULT NULL,
  `fecreg` varchar(20) DEFAULT NULL,
  `Fecha_Ultima_Transferencia` varchar(20) DEFAULT NULL,
  `Fecha_Liquidacion` varchar(20) DEFAULT NULL,
  `Codigo_Franqueo` varchar(50) DEFAULT NULL,
  `Rubro` varchar(50) DEFAULT NULL,
  `Codigo_Liquidacion` varchar(50) DEFAULT NULL,
  `Descripcion_Codigo` varchar(50) DEFAULT NULL,
  `Codigo_Detalle` varchar(50) DEFAULT NULL,
  `Descripcion_Detalle` varchar(50) DEFAULT NULL,
  `Observacion_Orden_Trabajo` varchar(50) DEFAULT NULL,
  `Cantidad_Requerida` int(11) DEFAULT NULL,
  `Nro_Cantidad` int(11) DEFAULT NULL,
  `demotot_atn` varchar(50) DEFAULT NULL,
  `demotot_mas` varchar(50) DEFAULT NULL,
  `demotot_asig` int(11) DEFAULT NULL,
  `Trab_Realizado` varchar(50) DEFAULT NULL,
  `Estado_GO` varchar(50) DEFAULT NULL,
  `Solicitud_Tecnica` varchar(50) DEFAULT NULL,
  `fecha_upload` varchar(20) DEFAULT NULL,
  UNIQUE KEY `codreqmnt` (`codreqmnt`),
  KEY `codnod` (`codnod`),
  KEY `nroplano` (`nroplano`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `negocios`
--

DROP TABLE IF EXISTS `negocios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `negocios` (
  `CLIENTE` int(11) DEFAULT NULL,
  `CUENTA` int(11) DEFAULT NULL,
  `SERVICIO` int(11) DEFAULT NULL,
  `CON_SRV` int(11) DEFAULT NULL,
  `CLASESRV` int(11) DEFAULT NULL,
  `TIPOSRV` int(11) DEFAULT NULL,
  `CATEGORIA` varchar(2) DEFAULT NULL,
  `OFI_CLI` varchar(20) DEFAULT NULL,
  `OFI_SRV` varchar(20) DEFAULT NULL,
  `CODDPT` int(11) DEFAULT NULL,
  `DESDPT` varchar(100) DEFAULT NULL,
  `CODPVC` int(11) DEFAULT NULL,
  `DESPVC` varchar(100) DEFAULT NULL,
  `CODDTT` int(11) DEFAULT NULL,
  `DESDTT` varchar(100) DEFAULT NULL,
  `INDFACT` varchar(5) DEFAULT NULL,
  `NODO` varchar(5) DEFAULT NULL,
  `PLANO` varchar(5) DEFAULT NULL,
  `CODLEX` int(11) DEFAULT NULL,
  `CODTAP` int(11) DEFAULT NULL,
  `CODBOR` int(11) DEFAULT NULL,
  `IND_VIP` varchar(5) DEFAULT NULL,
  `TIPO_DOCUM` varchar(5) DEFAULT NULL,
  `NUMERORUC` int(25) DEFAULT NULL,
  `NUMERODOC` varchar(14) DEFAULT NULL,
  `TELEFCL1` varchar(14) DEFAULT NULL,
  `TELEFCL2` varchar(14) DEFAULT NULL,
  `TELEFCL3` varchar(14) DEFAULT NULL,
  `APE_PAT` varchar(50) DEFAULT NULL,
  `APE_MAT` varchar(50) DEFAULT NULL,
  `NOMBRE` varchar(50) DEFAULT NULL,
  `PETATIS` varchar(50) DEFAULT NULL,
  `UBIPLAN` int(11) DEFAULT NULL,
  `PAIS` varchar(50) DEFAULT NULL,
  `UBIGEO` int(11) DEFAULT NULL,
  `ZONAL_ANT` varchar(50) DEFAULT NULL,
  `REGION` varchar(50) DEFAULT NULL,
  `ZONAL_NEW` varchar(50) DEFAULT NULL,
  `IND_DUNA` varchar(50) DEFAULT NULL,
  `AÑO_DUN` varchar(50) DEFAULT NULL,
  `CRUCE` varchar(50) DEFAULT NULL,
  `PAQUETE` varchar(50) DEFAULT NULL,
  `PAQUETE1` varchar(50) DEFAULT NULL,
  `SUB_NEG` varchar(50) DEFAULT NULL,
  `PROVEEDOR` varchar(50) DEFAULT NULL,
  `TECNOLOGIA` varchar(50) DEFAULT NULL,
  `PERU8K` varchar(50) DEFAULT NULL,
  `EX_CTA` varchar(50) DEFAULT NULL,
  `MARCAA` int(11) DEFAULT NULL,
  `CND_SRV_01` int(11) DEFAULT NULL,
  `CND_SRV_02` int(11) DEFAULT NULL,
  `CND_SRV_03` int(11) DEFAULT NULL,
  `EXCLUSANT` varchar(50) DEFAULT NULL,
  `PROV_ANT` varchar(50) DEFAULT NULL,
  `NEGO_ANT` varchar(50) DEFAULT NULL,
  `CSER_ANT` int(11) DEFAULT NULL,
  `PAQU_ANT` varchar(50) DEFAULT NULL,
  `PAQU1_ANT` varchar(50) DEFAULT NULL,
  `SEGMENTO` varchar(50) DEFAULT NULL,
  `MARCA_SUS` int(11) DEFAULT NULL,
  `EXCLU_SUS` varchar(50) DEFAULT NULL,
  `EX_BJ_INCO` varchar(50) DEFAULT NULL,
  `IND_EXCLUS` varchar(50) DEFAULT NULL,
  `MARCAB` varchar(50) DEFAULT NULL,
  `FEPROC` varchar(20) DEFAULT NULL,
  `SEG_CMS` varchar(30) DEFAULT NULL,
  `SEGMENTO_NEG` varchar(30) DEFAULT NULL,
  `SUBSEGMENTO_NEG` varchar(30) DEFAULT NULL,
  `TIPREQ` varchar(30) DEFAULT NULL,
  `CODMOTV` varchar(30) DEFAULT NULL,
  `FECREGSRV` varchar(20) DEFAULT NULL,
  `DIGITALIZADO` varchar(30) DEFAULT NULL,
  `FECHASUSPENSION` varchar(30) DEFAULT NULL,
  `TIPOREQSUSPENSION` varchar(30) DEFAULT NULL,
  `CODCLI` int(11) DEFAULT NULL,
  `CLIENTE_1` varchar(150) DEFAULT NULL,
  `RUC` varchar(20) DEFAULT NULL,
  KEY `CLIENTE` (`CLIENTE`),
  KEY `NODO` (`NODO`),
  KEY `PLANO` (`PLANO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nodo_troba`
--

DROP TABLE IF EXISTS `nodo_troba`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nodo_troba` (
  `nodo` varchar(4) DEFAULT NULL,
  `plano` varchar(5) DEFAULT NULL,
  UNIQUE KEY `nodo_2` (`nodo`,`plano`),
  KEY `nodo` (`nodo`),
  KEY `plano` (`plano`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nodo_troba_c`
--

DROP TABLE IF EXISTS `nodo_troba_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nodo_troba_c` (
  `ofi_cli` varchar(3) DEFAULT NULL,
  `nodo` varchar(4) DEFAULT NULL,
  `plano` varchar(5) DEFAULT NULL,
  UNIQUE KEY `ofi_cli` (`ofi_cli`,`nodo`,`plano`),
  KEY `NewIndex1` (`ofi_cli`),
  KEY `NewIndex2` (`nodo`),
  KEY `NewIndex3` (`plano`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nomfile`
--

DROP TABLE IF EXISTS `nomfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nomfile` (
  `permisos` varchar(31) DEFAULT NULL,
  `id` varchar(6) DEFAULT NULL,
  `usuario` varchar(13) DEFAULT NULL,
  `usuario1` varchar(9) DEFAULT NULL,
  `tamaño` varchar(40) DEFAULT NULL,
  `mes` varchar(20) DEFAULT NULL,
  `dia` varchar(20) DEFAULT NULL,
  `hora` varchar(20) DEFAULT NULL,
  `archivo` varchar(100) DEFAULT NULL,
  UNIQUE KEY `archivo` (`archivo`(20))
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `planta_clarita`
--

DROP TABLE IF EXISTS `planta_clarita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `planta_clarita` (
  `CLIENTE` int(10) DEFAULT NULL,
  `CUENTA` int(10) DEFAULT NULL,
  `SERVICIO` int(20) DEFAULT NULL,
  `CON_SRV` int(11) DEFAULT NULL,
  `CLASESRV` varchar(2) DEFAULT NULL,
  `TIPOSRV` int(11) DEFAULT NULL,
  `CATEGORIA` varchar(3) DEFAULT NULL,
  `OFI_CLI` varchar(3) DEFAULT NULL,
  `OFI_SRV` varchar(3) DEFAULT NULL,
  `CODDPT` varchar(3) DEFAULT NULL,
  `DESDPT` varchar(15) DEFAULT NULL,
  `CODPVC` varchar(3) DEFAULT NULL,
  `DESPVC` varchar(30) DEFAULT NULL,
  `CODDTT` varchar(3) DEFAULT NULL,
  `DESDTT` varchar(40) DEFAULT NULL,
  `INDFACT` varchar(2) DEFAULT NULL,
  `NODO` varchar(4) DEFAULT NULL,
  `DESNODO` varchar(30) DEFAULT NULL,
  `PLANO` varchar(5) DEFAULT NULL,
  `XIND_VIP` varchar(1) DEFAULT NULL,
  `TIPO_DOCUM` varchar(2) DEFAULT NULL,
  `NUMERORUC` varchar(20) DEFAULT NULL,
  `NUMERODOC` varchar(20) DEFAULT NULL,
  `TELEFCL1` varchar(15) DEFAULT NULL,
  `TELEFCL2` varchar(15) DEFAULT NULL,
  `TELEFCL3` varchar(15) DEFAULT NULL,
  `PETICATIS` varchar(20) DEFAULT NULL,
  `SEGMCLIENT` varchar(10) DEFAULT NULL,
  `ESTADODUNA` varchar(15) DEFAULT NULL,
  `NOMBRE` varchar(50) DEFAULT NULL,
  `APE_PAT` varchar(50) DEFAULT NULL,
  `APE_MAT` varchar(40) DEFAULT NULL,
  `CODNIT` varchar(10) DEFAULT NULL,
  `UBIGEOGIS` varchar(10) DEFAULT NULL,
  `DESUBIGEGI` varchar(40) DEFAULT NULL,
  `CODLEX` varchar(10) DEFAULT NULL,
  `CODTAP` varchar(10) DEFAULT NULL,
  `CODBOR` varchar(10) DEFAULT NULL,
  `DIREC_INST` varchar(90) DEFAULT NULL,
  `IND_DUO` varchar(10) DEFAULT NULL,
  `tipo_linea` varchar(6) DEFAULT NULL,
  `telef_ip` varchar(10) DEFAULT NULL,
  `prom_linea` varchar(47) DEFAULT NULL,
  `des_prom_linea` varchar(60) DEFAULT NULL,
  `nodeid` varchar(10) DEFAULT NULL,
  `veloc_cms` int(10) DEFAULT NULL,
  `tiptec` varchar(50) DEFAULT NULL,
  `localidad` varchar(30) DEFAULT NULL,
  `torre` varchar(6) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `Movistar_Total` varchar(1) DEFAULT NULL,
  `UBIPLAN` varchar(9) DEFAULT NULL,
  `PAIS` varchar(4) DEFAULT NULL,
  `UBIGEO` varchar(6) DEFAULT NULL,
  `ZONAL_ANT` varchar(3) DEFAULT NULL,
  `REGION` varchar(8) DEFAULT NULL,
  `ZONAL_NEW` varchar(10) DEFAULT NULL,
  `IND_DUNA` varchar(10) DEFAULT NULL,
  `AÑO_DUN` varchar(6) DEFAULT NULL,
  `CRUCE` varchar(4) DEFAULT NULL,
  `PAQUETE` varchar(15) DEFAULT NULL,
  `PAQUETE1` varchar(15) DEFAULT NULL,
  `SUB_NEG` varchar(4) DEFAULT NULL,
  `PROVEEDOR` varchar(4) DEFAULT NULL,
  `TECNOLOGIA` varchar(10) DEFAULT NULL,
  `PERU8K` varchar(7) DEFAULT NULL,
  `MARCAA` varchar(3) DEFAULT NULL,
  `CND_SRV_09` int(11) DEFAULT NULL,
  `CND_SRV_10` int(11) DEFAULT NULL,
  `CND_SRV_11` int(11) DEFAULT NULL,
  `EXCLUSANT` varchar(50) DEFAULT NULL,
  `PROV_ANT` varchar(12) DEFAULT NULL,
  `NEGO_ANT` varchar(10) DEFAULT NULL,
  `CSER_ANT` varchar(2) DEFAULT NULL,
  `PAQU_ANT` varchar(15) DEFAULT NULL,
  `PAQU1_ANT` varchar(10) DEFAULT NULL,
  `SEGMENTO` varchar(15) DEFAULT NULL,
  `SEGMENTO0` varchar(15) DEFAULT NULL,
  `EX_CTA` varchar(13) DEFAULT NULL,
  `MARCA_SUS` int(11) DEFAULT NULL,
  `EXCLU_SUS` varchar(32) DEFAULT NULL,
  `EX_BJ_INCO` varchar(50) DEFAULT NULL,
  `IND_EXCLUS` varchar(46) DEFAULT NULL,
  `SEG_CMS` varchar(2) DEFAULT NULL,
  `JEFCOM` varchar(10) DEFAULT NULL,
  `EECC` varchar(8) DEFAULT NULL,
  `REGION_COC` varchar(8) DEFAULT NULL,
  `ZON_REGION` varchar(4) DEFAULT NULL,
  `PREM_MAS` varchar(7) DEFAULT NULL,
  `DET_REGION` varchar(15) DEFAULT NULL,
  `JEF_REGION` varchar(8) DEFAULT NULL,
  `SEG_SLAS` varchar(11) DEFAULT NULL,
  `TOP_NOTOP` varchar(17) DEFAULT NULL,
  `JEFATU_NUE` varchar(4) DEFAULT NULL,
  `CLIEN_SRV` varchar(15) DEFAULT NULL,
  `MICROZONA` varchar(10) DEFAULT NULL,
  `LLAVE_UBIG` varchar(15) DEFAULT NULL,
  `TERRENO` varchar(15) DEFAULT NULL,
  `EXCLUYE` varchar(1) DEFAULT NULL,
  `IND_VIP` varchar(1) DEFAULT NULL,
  `TELEFONO` int(11) DEFAULT NULL,
  `TIPO` varchar(10) DEFAULT NULL,
  `DIRECCION` varchar(75) DEFAULT NULL,
  `IP` varchar(20) DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `CMTS` varchar(20) DEFAULT NULL,
  `TEC` varchar(5) DEFAULT NULL,
  `DIGITALIZA` varchar(2) DEFAULT NULL,
  `PAQUETE_HD` varchar(2) DEFAULT NULL,
  `SERVPACK` varchar(50) DEFAULT NULL,
  `VEL_SERVPA` varchar(10) DEFAULT NULL,
  `TIPO_VIA` varchar(4) DEFAULT NULL,
  `VIA` varchar(39) DEFAULT NULL,
  `NRO` varchar(6) DEFAULT NULL,
  `PISO` varchar(4) DEFAULT NULL,
  `INTERIOR` varchar(7) DEFAULT NULL,
  `MZ` varchar(7) DEFAULT NULL,
  `LT` varchar(7) DEFAULT NULL,
  `tipourbani` varchar(6) DEFAULT NULL,
  `urbanizaci` varchar(32) DEFAULT NULL,
  `TIPOPERU8K` varchar(20) DEFAULT NULL,
  `CLIENCCM1` varchar(2) DEFAULT NULL,
  `VOZIP` varchar(2) DEFAULT NULL,
  `PRODCOMER` varchar(100) DEFAULT NULL,
  `VEL_PRODCO` varchar(50) DEFAULT NULL,
  `DIGITAL2` int(11) DEFAULT NULL,
  `DIG_FECHA` varchar(20) DEFAULT NULL,
  `DIG_ESTADO` varchar(18) DEFAULT NULL,
  `DECO_ACT` int(11) DEFAULT NULL,
  `DECO_SUSP` int(11) DEFAULT NULL,
  `TIPREQ_PED` varchar(10) DEFAULT NULL,
  `proceso` date DEFAULT NULL,
  `FECHA_CARGA` char(10) DEFAULT NULL,
  `UNICO` char(2) CHARACTER SET utf8 DEFAULT NULL,
  `numcoo_x` varchar(30) DEFAULT NULL,
  `numcoo_y` varchar(30) DEFAULT NULL,
  `fuentexy` varchar(30) DEFAULT NULL,
  `nodotroba` varchar(10) DEFAULT NULL,
  `naked` varchar(20) DEFAULT NULL,
  `clicuenser` varchar(40) DEFAULT NULL,
  `grupo_microzona` varchar(15) DEFAULT NULL,
  `mtotal` varchar(2) DEFAULT NULL,
  `identifica` varchar(20) DEFAULT NULL,
  UNIQUE KEY `CLIENTE_2` (`CLIENTE`,`SERVICIO`),
  KEY `CLIENTE` (`CLIENTE`),
  KEY `CLASESRV` (`CLASESRV`),
  KEY `TIPOSRV` (`TIPOSRV`),
  KEY `OFI_CLI` (`OFI_CLI`),
  KEY `DESDPT` (`DESDPT`),
  KEY `CODDPT` (`CODDPT`),
  KEY `CODPVC` (`CODPVC`),
  KEY `DESPVC` (`DESPVC`),
  KEY `CODDTT` (`CODDTT`),
  KEY `DESDTT` (`DESDTT`),
  KEY `NODO` (`NODO`),
  KEY `PLANO` (`PLANO`),
  KEY `TELEFCL1` (`TELEFCL1`),
  KEY `TELEFCL2` (`TELEFCL2`),
  KEY `TELEFCL3` (`TELEFCL3`),
  KEY `UNICO` (`UNICO`),
  KEY `NOMBRE` (`NOMBRE`),
  KEY `CUENTA` (`CUENTA`),
  KEY `APE_MAT` (`APE_MAT`),
  KEY `APE_PAT` (`APE_PAT`),
  KEY `identifica` (`identifica`),
  KEY `clicuenser` (`clicuenser`),
  KEY `grupo_microzona` (`grupo_microzona`),
  KEY `mtotal` (`mtotal`),
  KEY `SERVICIO` (`SERVICIO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `planta_clarita_Mov1`
--

DROP TABLE IF EXISTS `planta_clarita_Mov1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `planta_clarita_Mov1` (
  `CLIENTE` int(10) DEFAULT NULL,
  `CUENTA` int(10) DEFAULT NULL,
  `SERVICIO` int(10) DEFAULT NULL,
  `CON_SRV` int(11) DEFAULT NULL,
  `CLASESRV` varchar(2) DEFAULT NULL,
  `TIPOSRV` int(11) DEFAULT NULL,
  `CATEGORIA` varchar(3) DEFAULT NULL,
  `OFI_CLI` varchar(3) DEFAULT NULL,
  `OFI_SRV` varchar(3) DEFAULT NULL,
  `CODDPT` varchar(3) DEFAULT NULL,
  `DESDPT` varchar(15) DEFAULT NULL,
  `CODPVC` varchar(3) DEFAULT NULL,
  `DESPVC` varchar(30) DEFAULT NULL,
  `CODDTT` varchar(3) DEFAULT NULL,
  `DESDTT` varchar(40) DEFAULT NULL,
  `INDFACT` varchar(2) DEFAULT NULL,
  `NODO` varchar(4) DEFAULT NULL,
  `DESNODO` varchar(30) DEFAULT NULL,
  `PLANO` varchar(5) DEFAULT NULL,
  `XIND_VIP` varchar(1) DEFAULT NULL,
  `TIPO_DOCUM` varchar(2) DEFAULT NULL,
  `NUMERORUC` varchar(12) DEFAULT NULL,
  `NUMERODOC` varchar(10) DEFAULT NULL,
  `TELEFCL1` varchar(15) DEFAULT NULL,
  `TELEFCL2` varchar(15) DEFAULT NULL,
  `TELEFCL3` varchar(15) DEFAULT NULL,
  `PETICATIS` varchar(20) DEFAULT NULL,
  `SEGMCLIENT` varchar(10) DEFAULT NULL,
  `ESTADODUNA` varchar(15) DEFAULT NULL,
  `NOMBRE` varchar(50) DEFAULT NULL,
  `APE_PAT` varchar(50) DEFAULT NULL,
  `APE_MAT` varchar(40) DEFAULT NULL,
  `CODNIT` varchar(10) DEFAULT NULL,
  `UBIGEOGIS` varchar(10) DEFAULT NULL,
  `DESUBIGEGI` varchar(40) DEFAULT NULL,
  `CODLEX` varchar(10) DEFAULT NULL,
  `CODTAP` varchar(10) DEFAULT NULL,
  `CODBOR` varchar(10) DEFAULT NULL,
  `DIREC_INST` varchar(90) DEFAULT NULL,
  `IND_DUO` varchar(10) DEFAULT NULL,
  `tipo_linea` varchar(15) DEFAULT NULL,
  `telefono_VOIP` varchar(15) DEFAULT NULL,
  `prom_VOIP` varchar(15) DEFAULT NULL,
  `descripcion_prom_linea` varchar(40) DEFAULT NULL,
  `nodoId_VOIP` varchar(15) DEFAULT NULL,
  `UBIPLAN` varchar(9) DEFAULT NULL,
  `PAIS` varchar(4) DEFAULT NULL,
  `UBIGEO` varchar(6) DEFAULT NULL,
  `ZONAL_ANT` varchar(3) DEFAULT NULL,
  `REGION` varchar(8) DEFAULT NULL,
  `ZONAL_NEW` varchar(10) DEFAULT NULL,
  `IND_DUNA` varchar(10) DEFAULT NULL,
  `AÑO_DUN` varchar(6) DEFAULT NULL,
  `CRUCE` varchar(4) DEFAULT NULL,
  `PAQUETE` varchar(15) DEFAULT NULL,
  `PAQUETE1` varchar(15) DEFAULT NULL,
  `SUB_NEG` varchar(4) DEFAULT NULL,
  `PROVEEDOR` varchar(4) DEFAULT NULL,
  `TECNOLOGIA` varchar(10) DEFAULT NULL,
  `PERU8K` varchar(7) DEFAULT NULL,
  `MARCAA` varchar(3) DEFAULT NULL,
  `CND_SRV_09` int(11) DEFAULT NULL,
  `CND_SRV_10` int(11) DEFAULT NULL,
  `CND_SRV_11` int(11) DEFAULT NULL,
  `EXCLUSANT` varchar(50) DEFAULT NULL,
  `PROV_ANT` varchar(12) DEFAULT NULL,
  `NEGO_ANT` varchar(10) DEFAULT NULL,
  `CSER_ANT` varchar(2) DEFAULT NULL,
  `PAQU_ANT` varchar(15) DEFAULT NULL,
  `PAQU1_ANT` varchar(10) DEFAULT NULL,
  `SEGMENTO` varchar(15) DEFAULT NULL,
  `SEGMENTO0` varchar(15) DEFAULT NULL,
  `EX_CTA` varchar(13) DEFAULT NULL,
  `MARCA_SUS` int(11) DEFAULT NULL,
  `EXCLU_SUS` varchar(32) DEFAULT NULL,
  `EX_BJ_INCO` varchar(50) DEFAULT NULL,
  `IND_EXCLUS` varchar(46) DEFAULT NULL,
  `SEG_CMS` varchar(2) DEFAULT NULL,
  `JEFCOM` varchar(10) DEFAULT NULL,
  `EECC` varchar(8) DEFAULT NULL,
  `REGION_COC` varchar(8) DEFAULT NULL,
  `ZON_REGION` varchar(4) DEFAULT NULL,
  `PREM_MAS` varchar(7) DEFAULT NULL,
  `DET_REGION` varchar(15) DEFAULT NULL,
  `JEF_REGION` varchar(8) DEFAULT NULL,
  `SEG_SLAS` varchar(11) DEFAULT NULL,
  `TOP_NOTOP` varchar(17) DEFAULT NULL,
  `JEFATU_NUE` varchar(4) DEFAULT NULL,
  `CLIEN_SRV` varchar(15) DEFAULT NULL,
  `MICROZONA` varchar(10) DEFAULT NULL,
  `LLAVE_UBIG` varchar(15) DEFAULT NULL,
  `TERRENO` varchar(15) DEFAULT NULL,
  `EXCLUYE` varchar(1) DEFAULT NULL,
  `IND_VIP` varchar(1) DEFAULT NULL,
  `TELEFONO` int(11) DEFAULT NULL,
  `TIPO` varchar(10) DEFAULT NULL,
  `DIRECCION` varchar(75) DEFAULT NULL,
  `IP` varchar(20) DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `CMTS` varchar(20) DEFAULT NULL,
  `TEC` varchar(5) DEFAULT NULL,
  `DIGITALIZA` varchar(2) DEFAULT NULL,
  `PAQUETE_HD` varchar(2) DEFAULT NULL,
  `SERVPACK` varchar(50) DEFAULT NULL,
  `VEL_SERVPA` varchar(10) DEFAULT NULL,
  `TIPO_VIA` varchar(4) DEFAULT NULL,
  `VIA` varchar(39) DEFAULT NULL,
  `NRO` varchar(6) DEFAULT NULL,
  `PISO` varchar(4) DEFAULT NULL,
  `INTERIOR` varchar(7) DEFAULT NULL,
  `MZ` varchar(7) DEFAULT NULL,
  `LT` varchar(7) DEFAULT NULL,
  `TIPOPERU8K` varchar(20) DEFAULT NULL,
  `CLIENCCM1` varchar(2) DEFAULT NULL,
  `VOZIP` varchar(2) DEFAULT NULL,
  `PRODCOMER` varchar(100) DEFAULT NULL,
  `VEL_PRODCO` varchar(50) DEFAULT NULL,
  `DIGITAL2` int(11) DEFAULT NULL,
  `DIG_FECHA` varchar(20) DEFAULT NULL,
  `DIG_ESTADO` varchar(18) DEFAULT NULL,
  `DECO_ACT` int(11) DEFAULT NULL,
  `DECO_SUSP` int(11) DEFAULT NULL,
  `TIPREQ_PED` varchar(10) DEFAULT NULL,
  `proceso` date DEFAULT NULL,
  `FECHA_CARGA` date DEFAULT NULL,
  UNIQUE KEY `CLIENTE` (`CLIENTE`,`NODO`,`PLANO`),
  KEY `SERVICIO` (`SERVICIO`),
  KEY `CLIENTE_2` (`CLIENTE`),
  KEY `OFI_CLI` (`OFI_CLI`),
  KEY `NODO` (`NODO`),
  KEY `PLANO` (`PLANO`),
  KEY `CODLEX` (`CODLEX`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `planta_clarita_c`
--

DROP TABLE IF EXISTS `planta_clarita_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `planta_clarita_c` (
  `CLIENTE` int(10) DEFAULT NULL,
  `CUENTA` int(10) DEFAULT NULL,
  `SERVICIO` int(20) DEFAULT NULL,
  `CON_SRV` int(11) DEFAULT NULL,
  `CLASESRV` varchar(2) DEFAULT NULL,
  `TIPOSRV` int(11) DEFAULT NULL,
  `CATEGORIA` varchar(3) DEFAULT NULL,
  `OFI_CLI` varchar(3) DEFAULT NULL,
  `OFI_SRV` varchar(3) DEFAULT NULL,
  `CODDPT` varchar(3) DEFAULT NULL,
  `DESDPT` varchar(15) DEFAULT NULL,
  `CODPVC` varchar(3) DEFAULT NULL,
  `DESPVC` varchar(30) DEFAULT NULL,
  `CODDTT` varchar(3) DEFAULT NULL,
  `DESDTT` varchar(40) DEFAULT NULL,
  `INDFACT` varchar(2) DEFAULT NULL,
  `NODO` varchar(4) DEFAULT NULL,
  `DESNODO` varchar(30) DEFAULT NULL,
  `PLANO` varchar(5) DEFAULT NULL,
  `XIND_VIP` varchar(1) DEFAULT NULL,
  `TIPO_DOCUM` varchar(2) DEFAULT NULL,
  `NUMERORUC` varchar(20) DEFAULT NULL,
  `NUMERODOC` varchar(20) DEFAULT NULL,
  `TELEFCL1` varchar(15) DEFAULT NULL,
  `TELEFCL2` varchar(15) DEFAULT NULL,
  `TELEFCL3` varchar(15) DEFAULT NULL,
  `PETICATIS` varchar(20) DEFAULT NULL,
  `SEGMCLIENT` varchar(10) DEFAULT NULL,
  `ESTADODUNA` varchar(15) DEFAULT NULL,
  `NOMBRE` varchar(50) DEFAULT NULL,
  `APE_PAT` varchar(50) DEFAULT NULL,
  `APE_MAT` varchar(40) DEFAULT NULL,
  `CODNIT` varchar(10) DEFAULT NULL,
  `UBIGEOGIS` varchar(10) DEFAULT NULL,
  `DESUBIGEGI` varchar(40) DEFAULT NULL,
  `CODLEX` varchar(10) DEFAULT NULL,
  `CODTAP` varchar(10) DEFAULT NULL,
  `CODBOR` varchar(10) DEFAULT NULL,
  `DIREC_INST` varchar(90) DEFAULT NULL,
  `IND_DUO` varchar(10) DEFAULT NULL,
  `tipo_linea` varchar(6) DEFAULT NULL,
  `telef_ip` varchar(10) DEFAULT NULL,
  `prom_linea` varchar(47) DEFAULT NULL,
  `des_prom_linea` varchar(60) DEFAULT NULL,
  `nodeid` varchar(10) DEFAULT NULL,
  `veloc_cms` int(10) DEFAULT NULL,
  `tiptec` varchar(50) DEFAULT NULL,
  `localidad` varchar(30) DEFAULT NULL,
  `torre` varchar(6) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `Movistar_Total` varchar(1) DEFAULT NULL,
  `UBIPLAN` varchar(9) DEFAULT NULL,
  `PAIS` varchar(4) DEFAULT NULL,
  `UBIGEO` varchar(6) DEFAULT NULL,
  `ZONAL_ANT` varchar(3) DEFAULT NULL,
  `REGION` varchar(8) DEFAULT NULL,
  `ZONAL_NEW` varchar(10) DEFAULT NULL,
  `IND_DUNA` varchar(10) DEFAULT NULL,
  `AÑO_DUN` varchar(6) DEFAULT NULL,
  `CRUCE` varchar(4) DEFAULT NULL,
  `PAQUETE` varchar(15) DEFAULT NULL,
  `PAQUETE1` varchar(15) DEFAULT NULL,
  `SUB_NEG` varchar(4) DEFAULT NULL,
  `PROVEEDOR` varchar(4) DEFAULT NULL,
  `TECNOLOGIA` varchar(10) DEFAULT NULL,
  `PERU8K` varchar(7) DEFAULT NULL,
  `MARCAA` varchar(3) DEFAULT NULL,
  `CND_SRV_09` int(11) DEFAULT NULL,
  `CND_SRV_10` int(11) DEFAULT NULL,
  `CND_SRV_11` int(11) DEFAULT NULL,
  `EXCLUSANT` varchar(50) DEFAULT NULL,
  `PROV_ANT` varchar(12) DEFAULT NULL,
  `NEGO_ANT` varchar(10) DEFAULT NULL,
  `CSER_ANT` varchar(2) DEFAULT NULL,
  `PAQU_ANT` varchar(15) DEFAULT NULL,
  `PAQU1_ANT` varchar(10) DEFAULT NULL,
  `SEGMENTO` varchar(15) DEFAULT NULL,
  `SEGMENTO0` varchar(15) DEFAULT NULL,
  `EX_CTA` varchar(13) DEFAULT NULL,
  `MARCA_SUS` int(11) DEFAULT NULL,
  `EXCLU_SUS` varchar(32) DEFAULT NULL,
  `EX_BJ_INCO` varchar(50) DEFAULT NULL,
  `IND_EXCLUS` varchar(46) DEFAULT NULL,
  `SEG_CMS` varchar(2) DEFAULT NULL,
  `JEFCOM` varchar(10) DEFAULT NULL,
  `EECC` varchar(8) DEFAULT NULL,
  `REGION_COC` varchar(8) DEFAULT NULL,
  `ZON_REGION` varchar(4) DEFAULT NULL,
  `PREM_MAS` varchar(7) DEFAULT NULL,
  `DET_REGION` varchar(15) DEFAULT NULL,
  `JEF_REGION` varchar(8) DEFAULT NULL,
  `SEG_SLAS` varchar(11) DEFAULT NULL,
  `TOP_NOTOP` varchar(17) DEFAULT NULL,
  `JEFATU_NUE` varchar(4) DEFAULT NULL,
  `CLIEN_SRV` varchar(15) DEFAULT NULL,
  `MICROZONA` varchar(10) DEFAULT NULL,
  `LLAVE_UBIG` varchar(15) DEFAULT NULL,
  `TERRENO` varchar(15) DEFAULT NULL,
  `EXCLUYE` varchar(1) DEFAULT NULL,
  `IND_VIP` varchar(1) DEFAULT NULL,
  `TELEFONO` int(11) DEFAULT NULL,
  `TIPO` varchar(10) DEFAULT NULL,
  `DIRECCION` varchar(75) DEFAULT NULL,
  `IP` varchar(20) DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `CMTS` varchar(20) DEFAULT NULL,
  `TEC` varchar(5) DEFAULT NULL,
  `DIGITALIZA` varchar(2) DEFAULT NULL,
  `PAQUETE_HD` varchar(2) DEFAULT NULL,
  `SERVPACK` varchar(50) DEFAULT NULL,
  `VEL_SERVPA` varchar(10) DEFAULT NULL,
  `TIPO_VIA` varchar(4) DEFAULT NULL,
  `VIA` varchar(39) DEFAULT NULL,
  `NRO` varchar(6) DEFAULT NULL,
  `PISO` varchar(4) DEFAULT NULL,
  `INTERIOR` varchar(7) DEFAULT NULL,
  `MZ` varchar(7) DEFAULT NULL,
  `LT` varchar(7) DEFAULT NULL,
  `tipourbani` varchar(6) DEFAULT NULL,
  `urbanizaci` varchar(32) DEFAULT NULL,
  `TIPOPERU8K` varchar(20) DEFAULT NULL,
  `CLIENCCM1` varchar(2) DEFAULT NULL,
  `VOZIP` varchar(2) DEFAULT NULL,
  `PRODCOMER` varchar(100) DEFAULT NULL,
  `VEL_PRODCO` varchar(50) DEFAULT NULL,
  `DIGITAL2` int(11) DEFAULT NULL,
  `DIG_FECHA` varchar(20) DEFAULT NULL,
  `DIG_ESTADO` varchar(18) DEFAULT NULL,
  `DECO_ACT` int(11) DEFAULT NULL,
  `DECO_SUSP` int(11) DEFAULT NULL,
  `TIPREQ_PED` varchar(10) DEFAULT NULL,
  `proceso` date DEFAULT NULL,
  `FECHA_CARGA` char(10) DEFAULT NULL,
  `UNICO` char(2) CHARACTER SET utf8 DEFAULT NULL,
  `numcoo_x` varchar(30) DEFAULT NULL,
  `numcoo_y` varchar(30) DEFAULT NULL,
  `fuentexy` varchar(30) DEFAULT NULL,
  `nodotroba` varchar(10) DEFAULT NULL,
  `naked` varchar(20) DEFAULT NULL,
  `clicuenser` varchar(40) DEFAULT NULL,
  `grupo_microzona` varchar(15) DEFAULT NULL,
  `mtotal` varchar(2) DEFAULT NULL,
  `identifica` varchar(20) DEFAULT NULL,
  UNIQUE KEY `CLIENTE_2` (`CLIENTE`,`SERVICIO`),
  KEY `CLIENTE` (`CLIENTE`),
  KEY `CLASESRV` (`CLASESRV`),
  KEY `TIPOSRV` (`TIPOSRV`),
  KEY `OFI_CLI` (`OFI_CLI`),
  KEY `DESDPT` (`DESDPT`),
  KEY `CODDPT` (`CODDPT`),
  KEY `CODPVC` (`CODPVC`),
  KEY `DESPVC` (`DESPVC`),
  KEY `CODDTT` (`CODDTT`),
  KEY `DESDTT` (`DESDTT`),
  KEY `NODO` (`NODO`),
  KEY `PLANO` (`PLANO`),
  KEY `TELEFCL1` (`TELEFCL1`),
  KEY `TELEFCL2` (`TELEFCL2`),
  KEY `TELEFCL3` (`TELEFCL3`),
  KEY `UNICO` (`UNICO`),
  KEY `NOMBRE` (`NOMBRE`),
  KEY `CUENTA` (`CUENTA`),
  KEY `APE_MAT` (`APE_MAT`),
  KEY `APE_PAT` (`APE_PAT`),
  KEY `identifica` (`identifica`),
  KEY `clicuenser` (`clicuenser`),
  KEY `grupo_microzona` (`grupo_microzona`),
  KEY `mtotal` (`mtotal`),
  KEY `SERVICIO` (`SERVICIO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `planta_clarita_d`
--

DROP TABLE IF EXISTS `planta_clarita_d`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `planta_clarita_d` (
  `CLIENTE` int(10) DEFAULT NULL,
  `CUENTA` int(10) DEFAULT NULL,
  `SERVICIO` int(20) DEFAULT NULL,
  `CON_SRV` int(11) DEFAULT NULL,
  `CLASESRV` varchar(2) DEFAULT NULL,
  `TIPOSRV` int(11) DEFAULT NULL,
  `CATEGORIA` varchar(3) DEFAULT NULL,
  `OFI_CLI` varchar(3) DEFAULT NULL,
  `OFI_SRV` varchar(3) DEFAULT NULL,
  `CODDPT` varchar(3) DEFAULT NULL,
  `DESDPT` varchar(15) DEFAULT NULL,
  `CODPVC` varchar(3) DEFAULT NULL,
  `DESPVC` varchar(30) DEFAULT NULL,
  `CODDTT` varchar(3) DEFAULT NULL,
  `DESDTT` varchar(40) DEFAULT NULL,
  `INDFACT` varchar(2) DEFAULT NULL,
  `NODO` varchar(4) DEFAULT NULL,
  `DESNODO` varchar(30) DEFAULT NULL,
  `PLANO` varchar(5) DEFAULT NULL,
  `XIND_VIP` varchar(1) DEFAULT NULL,
  `TIPO_DOCUM` varchar(2) DEFAULT NULL,
  `NUMERORUC` varchar(20) DEFAULT NULL,
  `NUMERODOC` varchar(20) DEFAULT NULL,
  `TELEFCL1` varchar(15) DEFAULT NULL,
  `TELEFCL2` varchar(15) DEFAULT NULL,
  `TELEFCL3` varchar(15) DEFAULT NULL,
  `PETICATIS` varchar(20) DEFAULT NULL,
  `SEGMCLIENT` varchar(10) DEFAULT NULL,
  `ESTADODUNA` varchar(15) DEFAULT NULL,
  `NOMBRE` varchar(50) DEFAULT NULL,
  `APE_PAT` varchar(50) DEFAULT NULL,
  `APE_MAT` varchar(40) DEFAULT NULL,
  `CODNIT` varchar(10) DEFAULT NULL,
  `UBIGEOGIS` varchar(10) DEFAULT NULL,
  `DESUBIGEGI` varchar(40) DEFAULT NULL,
  `CODLEX` varchar(10) DEFAULT NULL,
  `CODTAP` varchar(10) DEFAULT NULL,
  `CODBOR` varchar(10) DEFAULT NULL,
  `DIREC_INST` varchar(90) DEFAULT NULL,
  `IND_DUO` varchar(10) DEFAULT NULL,
  `tipo_linea` varchar(6) DEFAULT NULL,
  `telef_ip` varchar(10) DEFAULT NULL,
  `prom_linea` varchar(47) DEFAULT NULL,
  `des_prom_linea` varchar(60) DEFAULT NULL,
  `nodeid` varchar(10) DEFAULT NULL,
  `veloc_cms` int(10) DEFAULT NULL,
  `tiptec` varchar(50) DEFAULT NULL,
  `localidad` varchar(30) DEFAULT NULL,
  `torre` varchar(6) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `Movistar_Total` varchar(1) DEFAULT NULL,
  `UBIPLAN` varchar(9) DEFAULT NULL,
  `PAIS` varchar(4) DEFAULT NULL,
  `UBIGEO` varchar(6) DEFAULT NULL,
  `ZONAL_ANT` varchar(3) DEFAULT NULL,
  `REGION` varchar(8) DEFAULT NULL,
  `ZONAL_NEW` varchar(10) DEFAULT NULL,
  `IND_DUNA` varchar(10) DEFAULT NULL,
  `AÑO_DUN` varchar(6) DEFAULT NULL,
  `CRUCE` varchar(4) DEFAULT NULL,
  `PAQUETE` varchar(15) DEFAULT NULL,
  `PAQUETE1` varchar(15) DEFAULT NULL,
  `SUB_NEG` varchar(4) DEFAULT NULL,
  `PROVEEDOR` varchar(4) DEFAULT NULL,
  `TECNOLOGIA` varchar(10) DEFAULT NULL,
  `PERU8K` varchar(7) DEFAULT NULL,
  `MARCAA` varchar(3) DEFAULT NULL,
  `CND_SRV_09` int(11) DEFAULT NULL,
  `CND_SRV_10` int(11) DEFAULT NULL,
  `CND_SRV_11` int(11) DEFAULT NULL,
  `EXCLUSANT` varchar(50) DEFAULT NULL,
  `PROV_ANT` varchar(12) DEFAULT NULL,
  `NEGO_ANT` varchar(10) DEFAULT NULL,
  `CSER_ANT` varchar(2) DEFAULT NULL,
  `PAQU_ANT` varchar(15) DEFAULT NULL,
  `PAQU1_ANT` varchar(10) DEFAULT NULL,
  `SEGMENTO` varchar(15) DEFAULT NULL,
  `SEGMENTO0` varchar(15) DEFAULT NULL,
  `EX_CTA` varchar(13) DEFAULT NULL,
  `MARCA_SUS` int(11) DEFAULT NULL,
  `EXCLU_SUS` varchar(32) DEFAULT NULL,
  `EX_BJ_INCO` varchar(50) DEFAULT NULL,
  `IND_EXCLUS` varchar(46) DEFAULT NULL,
  `SEG_CMS` varchar(2) DEFAULT NULL,
  `JEFCOM` varchar(10) DEFAULT NULL,
  `EECC` varchar(8) DEFAULT NULL,
  `REGION_COC` varchar(8) DEFAULT NULL,
  `ZON_REGION` varchar(4) DEFAULT NULL,
  `PREM_MAS` varchar(7) DEFAULT NULL,
  `DET_REGION` varchar(15) DEFAULT NULL,
  `JEF_REGION` varchar(8) DEFAULT NULL,
  `SEG_SLAS` varchar(11) DEFAULT NULL,
  `TOP_NOTOP` varchar(17) DEFAULT NULL,
  `JEFATU_NUE` varchar(4) DEFAULT NULL,
  `CLIEN_SRV` varchar(15) DEFAULT NULL,
  `MICROZONA` varchar(10) DEFAULT NULL,
  `LLAVE_UBIG` varchar(15) DEFAULT NULL,
  `TERRENO` varchar(15) DEFAULT NULL,
  `EXCLUYE` varchar(1) DEFAULT NULL,
  `IND_VIP` varchar(1) DEFAULT NULL,
  `TELEFONO` int(11) DEFAULT NULL,
  `TIPO` varchar(10) DEFAULT NULL,
  `DIRECCION` varchar(75) DEFAULT NULL,
  `IP` varchar(20) DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `CMTS` varchar(20) DEFAULT NULL,
  `TEC` varchar(5) DEFAULT NULL,
  `DIGITALIZA` varchar(2) DEFAULT NULL,
  `PAQUETE_HD` varchar(2) DEFAULT NULL,
  `SERVPACK` varchar(50) DEFAULT NULL,
  `VEL_SERVPA` varchar(10) DEFAULT NULL,
  `TIPO_VIA` varchar(4) DEFAULT NULL,
  `VIA` varchar(39) DEFAULT NULL,
  `NRO` varchar(6) DEFAULT NULL,
  `PISO` varchar(4) DEFAULT NULL,
  `INTERIOR` varchar(7) DEFAULT NULL,
  `MZ` varchar(7) DEFAULT NULL,
  `LT` varchar(7) DEFAULT NULL,
  `tipourbani` varchar(6) DEFAULT NULL,
  `urbanizaci` varchar(32) DEFAULT NULL,
  `TIPOPERU8K` varchar(20) DEFAULT NULL,
  `CLIENCCM1` varchar(2) DEFAULT NULL,
  `VOZIP` varchar(2) DEFAULT NULL,
  `PRODCOMER` varchar(100) DEFAULT NULL,
  `VEL_PRODCO` varchar(50) DEFAULT NULL,
  `DIGITAL2` int(11) DEFAULT NULL,
  `DIG_FECHA` varchar(20) DEFAULT NULL,
  `DIG_ESTADO` varchar(18) DEFAULT NULL,
  `DECO_ACT` int(11) DEFAULT NULL,
  `DECO_SUSP` int(11) DEFAULT NULL,
  `TIPREQ_PED` varchar(10) DEFAULT NULL,
  `proceso` date DEFAULT NULL,
  `FECHA_CARGA` char(10) DEFAULT NULL,
  `UNICO` char(2) CHARACTER SET utf8 DEFAULT NULL,
  `numcoo_x` varchar(30) DEFAULT NULL,
  `numcoo_y` varchar(30) DEFAULT NULL,
  `fuentexy` varchar(30) DEFAULT NULL,
  `nodotroba` varchar(10) DEFAULT NULL,
  `naked` varchar(20) DEFAULT NULL,
  `clicuenser` varchar(40) DEFAULT NULL,
  `grupo_microzona` varchar(15) DEFAULT NULL,
  `mtotal` varchar(2) DEFAULT NULL,
  `identifica` varchar(20) DEFAULT NULL,
  UNIQUE KEY `CLIENTE_2` (`CLIENTE`,`SERVICIO`),
  KEY `CLIENTE` (`CLIENTE`),
  KEY `CLASESRV` (`CLASESRV`),
  KEY `TIPOSRV` (`TIPOSRV`),
  KEY `OFI_CLI` (`OFI_CLI`),
  KEY `DESDPT` (`DESDPT`),
  KEY `CODDPT` (`CODDPT`),
  KEY `CODPVC` (`CODPVC`),
  KEY `DESPVC` (`DESPVC`),
  KEY `CODDTT` (`CODDTT`),
  KEY `DESDTT` (`DESDTT`),
  KEY `NODO` (`NODO`),
  KEY `PLANO` (`PLANO`),
  KEY `TELEFCL1` (`TELEFCL1`),
  KEY `TELEFCL2` (`TELEFCL2`),
  KEY `TELEFCL3` (`TELEFCL3`),
  KEY `UNICO` (`UNICO`),
  KEY `NOMBRE` (`NOMBRE`),
  KEY `CUENTA` (`CUENTA`),
  KEY `APE_MAT` (`APE_MAT`),
  KEY `APE_PAT` (`APE_PAT`),
  KEY `identifica` (`identifica`),
  KEY `clicuenser` (`clicuenser`),
  KEY `grupo_microzona` (`grupo_microzona`),
  KEY `mtotal` (`mtotal`),
  KEY `SERVICIO` (`SERVICIO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `planta_clarita_edificios`
--

DROP TABLE IF EXISTS `planta_clarita_edificios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `planta_clarita_edificios` (
  `item` int(11) NOT NULL AUTO_INCREMENT,
  `desdtt` varchar(50) DEFAULT NULL,
  `via` varchar(39) DEFAULT NULL,
  `nro` int(11) DEFAULT NULL,
  `encargado` varchar(150) DEFAULT NULL,
  `telcontac` varchar(15) DEFAULT NULL,
  `carta` varchar(10) DEFAULT NULL,
  `presidente` varchar(150) DEFAULT NULL,
  `telpresi` varchar(40) DEFAULT NULL,
  `dia` varchar(20) DEFAULT NULL,
  `horaini` varchar(5) DEFAULT NULL,
  `horafin` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`item`),
  UNIQUE KEY `ubigeo` (`desdtt`,`via`,`nro`),
  KEY `via` (`via`),
  KEY `nro` (`nro`),
  KEY `encargado` (`encargado`),
  KEY `telcontac` (`telcontac`),
  KEY `carta` (`carta`),
  KEY `desdtt` (`desdtt`)
) ENGINE=InnoDB AUTO_INCREMENT=1970837 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `planta_clarita_olld`
--

DROP TABLE IF EXISTS `planta_clarita_olld`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `planta_clarita_olld` (
  `CLIENTE` int(10) DEFAULT NULL,
  `CUENTA` int(10) DEFAULT NULL,
  `SERVICIO` varchar(20) DEFAULT NULL,
  `CON_SRV` int(11) DEFAULT NULL,
  `CLASESRV` varchar(2) DEFAULT NULL,
  `TIPOSRV` int(11) DEFAULT NULL,
  `CATEGORIA` varchar(3) DEFAULT NULL,
  `OFI_CLI` varchar(3) DEFAULT NULL,
  `OFI_SRV` varchar(3) DEFAULT NULL,
  `CODDPT` varchar(3) DEFAULT NULL,
  `DESDPT` varchar(15) DEFAULT NULL,
  `CODPVC` varchar(3) DEFAULT NULL,
  `DESPVC` varchar(30) DEFAULT NULL,
  `CODDTT` varchar(3) DEFAULT NULL,
  `DESDTT` varchar(40) DEFAULT NULL,
  `INDFACT` varchar(2) DEFAULT NULL,
  `NODO` varchar(4) DEFAULT NULL,
  `DESNODO` varchar(30) DEFAULT NULL,
  `PLANO` varchar(5) DEFAULT NULL,
  `XIND_VIP` varchar(1) DEFAULT NULL,
  `TIPO_DOCUM` varchar(2) DEFAULT NULL,
  `NUMERORUC` varchar(12) DEFAULT NULL,
  `NUMERODOC` varchar(10) DEFAULT NULL,
  `TELEFCL1` varchar(15) DEFAULT NULL,
  `TELEFCL2` varchar(15) DEFAULT NULL,
  `TELEFCL3` varchar(15) DEFAULT NULL,
  `PETICATIS` varchar(20) DEFAULT NULL,
  `SEGMCLIENT` varchar(10) DEFAULT NULL,
  `ESTADODUNA` varchar(15) DEFAULT NULL,
  `NOMBRE` varchar(50) DEFAULT NULL,
  `APE_PAT` varchar(50) DEFAULT NULL,
  `APE_MAT` varchar(40) DEFAULT NULL,
  `CODNIT` varchar(10) DEFAULT NULL,
  `UBIGEOGIS` varchar(10) DEFAULT NULL,
  `DESUBIGEGI` varchar(40) DEFAULT NULL,
  `CODLEX` varchar(10) DEFAULT NULL,
  `CODTAP` varchar(10) DEFAULT NULL,
  `CODBOR` varchar(10) DEFAULT NULL,
  `DIREC_INST` varchar(90) DEFAULT NULL,
  `IND_DUO` varchar(10) DEFAULT NULL,
  `tipo_linea` varchar(6) DEFAULT NULL,
  `telef_ip` varchar(10) DEFAULT NULL,
  `prom_linea` varchar(47) DEFAULT NULL,
  `des_prom_linea` varchar(60) DEFAULT NULL,
  `nodeid` varchar(10) DEFAULT NULL,
  `veloc_cms` int(10) DEFAULT NULL,
  `UBIPLAN` varchar(9) DEFAULT NULL,
  `PAIS` varchar(4) DEFAULT NULL,
  `UBIGEO` varchar(6) DEFAULT NULL,
  `ZONAL_ANT` varchar(3) DEFAULT NULL,
  `REGION` varchar(8) DEFAULT NULL,
  `ZONAL_NEW` varchar(10) DEFAULT NULL,
  `IND_DUNA` varchar(10) DEFAULT NULL,
  `AÑO_DUN` varchar(6) DEFAULT NULL,
  `CRUCE` varchar(4) DEFAULT NULL,
  `PAQUETE` varchar(15) DEFAULT NULL,
  `PAQUETE1` varchar(15) DEFAULT NULL,
  `SUB_NEG` varchar(4) DEFAULT NULL,
  `PROVEEDOR` varchar(4) DEFAULT NULL,
  `TECNOLOGIA` varchar(10) DEFAULT NULL,
  `PERU8K` varchar(7) DEFAULT NULL,
  `MARCAA` varchar(3) DEFAULT NULL,
  `CND_SRV_09` int(11) DEFAULT NULL,
  `CND_SRV_10` int(11) DEFAULT NULL,
  `CND_SRV_11` int(11) DEFAULT NULL,
  `EXCLUSANT` varchar(50) DEFAULT NULL,
  `PROV_ANT` varchar(12) DEFAULT NULL,
  `NEGO_ANT` varchar(10) DEFAULT NULL,
  `CSER_ANT` varchar(2) DEFAULT NULL,
  `PAQU_ANT` varchar(15) DEFAULT NULL,
  `PAQU1_ANT` varchar(10) DEFAULT NULL,
  `SEGMENTO` varchar(15) DEFAULT NULL,
  `SEGMENTO0` varchar(15) DEFAULT NULL,
  `EX_CTA` varchar(13) DEFAULT NULL,
  `MARCA_SUS` int(11) DEFAULT NULL,
  `EXCLU_SUS` varchar(32) DEFAULT NULL,
  `EX_BJ_INCO` varchar(50) DEFAULT NULL,
  `IND_EXCLUS` varchar(46) DEFAULT NULL,
  `SEG_CMS` varchar(2) DEFAULT NULL,
  `JEFCOM` varchar(10) DEFAULT NULL,
  `EECC` varchar(8) DEFAULT NULL,
  `REGION_COC` varchar(8) DEFAULT NULL,
  `ZON_REGION` varchar(4) DEFAULT NULL,
  `PREM_MAS` varchar(7) DEFAULT NULL,
  `DET_REGION` varchar(15) DEFAULT NULL,
  `JEF_REGION` varchar(8) DEFAULT NULL,
  `SEG_SLAS` varchar(11) DEFAULT NULL,
  `TOP_NOTOP` varchar(17) DEFAULT NULL,
  `JEFATU_NUE` varchar(4) DEFAULT NULL,
  `CLIEN_SRV` varchar(15) DEFAULT NULL,
  `MICROZONA` varchar(10) DEFAULT NULL,
  `LLAVE_UBIG` varchar(15) DEFAULT NULL,
  `TERRENO` varchar(15) DEFAULT NULL,
  `EXCLUYE` varchar(1) DEFAULT NULL,
  `IND_VIP` varchar(1) DEFAULT NULL,
  `TELEFONO` int(11) DEFAULT NULL,
  `TIPO` varchar(10) DEFAULT NULL,
  `DIRECCION` varchar(75) DEFAULT NULL,
  `IP` varchar(20) DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `CMTS` varchar(20) DEFAULT NULL,
  `TEC` varchar(5) DEFAULT NULL,
  `DIGITALIZA` varchar(2) DEFAULT NULL,
  `PAQUETE_HD` varchar(2) DEFAULT NULL,
  `SERVPACK` varchar(50) DEFAULT NULL,
  `VEL_SERVPA` varchar(10) DEFAULT NULL,
  `TIPO_VIA` varchar(4) DEFAULT NULL,
  `VIA` varchar(39) DEFAULT NULL,
  `NRO` varchar(6) DEFAULT NULL,
  `PISO` varchar(4) DEFAULT NULL,
  `INTERIOR` varchar(7) DEFAULT NULL,
  `MZ` varchar(7) DEFAULT NULL,
  `LT` varchar(7) DEFAULT NULL,
  `tipourbani` varchar(6) DEFAULT NULL,
  `urbanizaci` varchar(32) DEFAULT NULL,
  `TIPOPERU8K` varchar(20) DEFAULT NULL,
  `CLIENCCM1` varchar(2) DEFAULT NULL,
  `VOZIP` varchar(2) DEFAULT NULL,
  `PRODCOMER` varchar(100) DEFAULT NULL,
  `VEL_PRODCO` varchar(50) DEFAULT NULL,
  `DIGITAL2` int(11) DEFAULT NULL,
  `DIG_FECHA` varchar(20) DEFAULT NULL,
  `DIG_ESTADO` varchar(18) DEFAULT NULL,
  `DECO_ACT` int(11) DEFAULT NULL,
  `DECO_SUSP` int(11) DEFAULT NULL,
  `TIPREQ_PED` varchar(10) DEFAULT NULL,
  `proceso` date DEFAULT NULL,
  `FECHA_CARGA` char(10) DEFAULT NULL,
  `UNICO` char(2) CHARACTER SET utf8 DEFAULT NULL,
  KEY `CLIENTE` (`CLIENTE`),
  KEY `VIA` (`VIA`),
  KEY `NRO` (`NRO`),
  KEY `DESDTT` (`DESDTT`),
  KEY `idxnodo` (`NODO`),
  KEY `idxplano` (`PLANO`),
  KEY `idxservicio` (`SERVICIO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `planta_clarita_rec`
--

DROP TABLE IF EXISTS `planta_clarita_rec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `planta_clarita_rec` (
  `CLIENTE` double DEFAULT NULL,
  `CUENTA` int(10) DEFAULT NULL,
  `SERVICIO` int(10) DEFAULT NULL,
  `CON_SRV` int(11) DEFAULT NULL,
  `CLASESRV` varchar(2) DEFAULT NULL,
  `TIPOSRV` int(11) DEFAULT NULL,
  `CATEGORIA` varchar(3) DEFAULT NULL,
  `OFI_CLI` varchar(3) DEFAULT NULL,
  `OFI_SRV` varchar(3) DEFAULT NULL,
  `CODDPT` varchar(3) DEFAULT NULL,
  `DESDPT` varchar(15) DEFAULT NULL,
  `CODPVC` varchar(3) DEFAULT NULL,
  `DESPVC` varchar(30) DEFAULT NULL,
  `CODDTT` varchar(3) DEFAULT NULL,
  `DESDTT` varchar(40) DEFAULT NULL,
  `INDFACT` varchar(2) DEFAULT NULL,
  `NODO` varchar(4) DEFAULT NULL,
  `DESNODO` varchar(30) DEFAULT NULL,
  `PLANO` varchar(5) DEFAULT NULL,
  `XIND_VIP` varchar(1) DEFAULT NULL,
  `TIPO_DOCUM` varchar(2) DEFAULT NULL,
  `NUMERORUC` varchar(12) DEFAULT NULL,
  `NUMERODOC` varchar(10) DEFAULT NULL,
  `TELEFCL1` varchar(15) DEFAULT NULL,
  `TELEFCL2` varchar(15) DEFAULT NULL,
  `TELEFCL3` varchar(15) DEFAULT NULL,
  `PETICATIS` varchar(20) DEFAULT NULL,
  `SEGMCLIENT` varchar(10) DEFAULT NULL,
  `ESTADODUNA` varchar(15) DEFAULT NULL,
  `NOMBRE` varchar(50) DEFAULT NULL,
  `APE_PAT` varchar(50) DEFAULT NULL,
  `APE_MAT` varchar(40) DEFAULT NULL,
  `CODNIT` varchar(10) DEFAULT NULL,
  `UBIGEOGIS` varchar(10) DEFAULT NULL,
  `DESUBIGEGI` varchar(40) DEFAULT NULL,
  `CODLEX` varchar(10) DEFAULT NULL,
  `CODTAP` varchar(10) DEFAULT NULL,
  `CODBOR` varchar(10) DEFAULT NULL,
  `DIREC_INST` varchar(90) DEFAULT NULL,
  `IND_DUO` varchar(10) DEFAULT NULL,
  `tipo_linea` varchar(6) DEFAULT NULL,
  `telef_ip` varchar(10) DEFAULT NULL,
  `prom_linea` varchar(47) DEFAULT NULL,
  `des_prom_linea` varchar(60) DEFAULT NULL,
  `nodeid` varchar(10) DEFAULT NULL,
  `UBIPLAN` varchar(9) DEFAULT NULL,
  `PAIS` varchar(4) DEFAULT NULL,
  `UBIGEO` varchar(6) DEFAULT NULL,
  `ZONAL_ANT` varchar(3) DEFAULT NULL,
  `REGION` varchar(8) DEFAULT NULL,
  `ZONAL_NEW` varchar(10) DEFAULT NULL,
  `IND_DUNA` varchar(10) DEFAULT NULL,
  `AÑO_DUN` varchar(6) DEFAULT NULL,
  `CRUCE` varchar(4) DEFAULT NULL,
  `PAQUETE` varchar(15) DEFAULT NULL,
  `PAQUETE1` varchar(15) DEFAULT NULL,
  `SUB_NEG` varchar(4) DEFAULT NULL,
  `PROVEEDOR` varchar(4) DEFAULT NULL,
  `TECNOLOGIA` varchar(10) DEFAULT NULL,
  `PERU8K` varchar(7) DEFAULT NULL,
  `MARCAA` varchar(3) DEFAULT NULL,
  `CND_SRV_09` int(11) DEFAULT NULL,
  `CND_SRV_10` int(11) DEFAULT NULL,
  `CND_SRV_11` int(11) DEFAULT NULL,
  `EXCLUSANT` varchar(50) DEFAULT NULL,
  `PROV_ANT` varchar(12) DEFAULT NULL,
  `NEGO_ANT` varchar(10) DEFAULT NULL,
  `CSER_ANT` varchar(2) DEFAULT NULL,
  `PAQU_ANT` varchar(15) DEFAULT NULL,
  `PAQU1_ANT` varchar(10) DEFAULT NULL,
  `SEGMENTO` varchar(15) DEFAULT NULL,
  `SEGMENTO0` varchar(15) DEFAULT NULL,
  `EX_CTA` varchar(13) DEFAULT NULL,
  `MARCA_SUS` int(11) DEFAULT NULL,
  `EXCLU_SUS` varchar(32) DEFAULT NULL,
  `EX_BJ_INCO` varchar(50) DEFAULT NULL,
  `IND_EXCLUS` varchar(46) DEFAULT NULL,
  `SEG_CMS` varchar(2) DEFAULT NULL,
  `JEFCOM` varchar(10) DEFAULT NULL,
  `EECC` varchar(8) DEFAULT NULL,
  `REGION_COC` varchar(8) DEFAULT NULL,
  `ZON_REGION` varchar(4) DEFAULT NULL,
  `PREM_MAS` varchar(7) DEFAULT NULL,
  `DET_REGION` varchar(15) DEFAULT NULL,
  `JEF_REGION` varchar(8) DEFAULT NULL,
  `SEG_SLAS` varchar(11) DEFAULT NULL,
  `TOP_NOTOP` varchar(17) DEFAULT NULL,
  `JEFATU_NUE` varchar(4) DEFAULT NULL,
  `CLIEN_SRV` varchar(15) DEFAULT NULL,
  `MICROZONA` varchar(10) DEFAULT NULL,
  `LLAVE_UBIG` varchar(15) DEFAULT NULL,
  `TERRENO` varchar(15) DEFAULT NULL,
  `EXCLUYE` varchar(1) DEFAULT NULL,
  `IND_VIP` varchar(1) DEFAULT NULL,
  `TELEFONO` int(11) DEFAULT NULL,
  `TIPO` varchar(10) DEFAULT NULL,
  `DIRECCION` varchar(75) DEFAULT NULL,
  `IP` varchar(20) DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `CMTS` varchar(20) DEFAULT NULL,
  `TEC` varchar(5) DEFAULT NULL,
  `DIGITALIZA` varchar(2) DEFAULT NULL,
  `PAQUETE_HD` varchar(2) DEFAULT NULL,
  `SERVPACK` varchar(50) DEFAULT NULL,
  `VEL_SERVPA` varchar(10) DEFAULT NULL,
  `TIPO_VIA` varchar(4) DEFAULT NULL,
  `VIA` varchar(39) DEFAULT NULL,
  `NRO` varchar(6) DEFAULT NULL,
  `PISO` varchar(4) DEFAULT NULL,
  `INTERIOR` varchar(7) DEFAULT NULL,
  `MZ` varchar(7) DEFAULT NULL,
  `LT` varchar(7) DEFAULT NULL,
  `TIPOPERU8K` varchar(20) DEFAULT NULL,
  `CLIENCCM1` varchar(2) DEFAULT NULL,
  `VOZIP` varchar(2) DEFAULT NULL,
  `PRODCOMER` varchar(100) DEFAULT NULL,
  `VEL_PRODCO` varchar(50) DEFAULT NULL,
  `DIGITAL2` int(11) DEFAULT NULL,
  `DIG_FECHA` varchar(20) DEFAULT NULL,
  `DIG_ESTADO` varchar(18) DEFAULT NULL,
  `DECO_ACT` int(11) DEFAULT NULL,
  `DECO_SUSP` int(11) DEFAULT NULL,
  `TIPREQ_PED` varchar(10) DEFAULT NULL,
  `proceso` date DEFAULT NULL,
  `FECHA_CARGA` char(10) DEFAULT NULL,
  `canserv` int(11) DEFAULT NULL,
  KEY `id_cliente` (`CLIENTE`),
  KEY `canserv` (`canserv`),
  KEY `NODO` (`NODO`),
  KEY `PLANO` (`PLANO`),
  KEY `CODLEX` (`CODLEX`),
  KEY `CODTAP` (`CODTAP`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `planta_clarita_rec_d`
--

DROP TABLE IF EXISTS `planta_clarita_rec_d`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `planta_clarita_rec_d` (
  `CLIENTE` double DEFAULT NULL,
  `CUENTA` int(10) DEFAULT NULL,
  `SERVICIO` int(10) DEFAULT NULL,
  `CON_SRV` int(11) DEFAULT NULL,
  `CLASESRV` varchar(2) DEFAULT NULL,
  `TIPOSRV` int(11) DEFAULT NULL,
  `CATEGORIA` varchar(3) DEFAULT NULL,
  `OFI_CLI` varchar(3) DEFAULT NULL,
  `OFI_SRV` varchar(3) DEFAULT NULL,
  `CODDPT` varchar(3) DEFAULT NULL,
  `DESDPT` varchar(15) DEFAULT NULL,
  `CODPVC` varchar(3) DEFAULT NULL,
  `DESPVC` varchar(30) DEFAULT NULL,
  `CODDTT` varchar(3) DEFAULT NULL,
  `DESDTT` varchar(40) DEFAULT NULL,
  `INDFACT` varchar(2) DEFAULT NULL,
  `NODO` varchar(4) DEFAULT NULL,
  `DESNODO` varchar(30) DEFAULT NULL,
  `PLANO` varchar(5) DEFAULT NULL,
  `XIND_VIP` varchar(1) DEFAULT NULL,
  `TIPO_DOCUM` varchar(2) DEFAULT NULL,
  `NUMERORUC` varchar(12) DEFAULT NULL,
  `NUMERODOC` varchar(10) DEFAULT NULL,
  `TELEFCL1` varchar(15) DEFAULT NULL,
  `TELEFCL2` varchar(15) DEFAULT NULL,
  `TELEFCL3` varchar(15) DEFAULT NULL,
  `PETICATIS` varchar(20) DEFAULT NULL,
  `SEGMCLIENT` varchar(10) DEFAULT NULL,
  `ESTADODUNA` varchar(15) DEFAULT NULL,
  `NOMBRE` varchar(50) DEFAULT NULL,
  `APE_PAT` varchar(50) DEFAULT NULL,
  `APE_MAT` varchar(40) DEFAULT NULL,
  `CODNIT` varchar(10) DEFAULT NULL,
  `UBIGEOGIS` varchar(10) DEFAULT NULL,
  `DESUBIGEGI` varchar(40) DEFAULT NULL,
  `CODLEX` varchar(10) DEFAULT NULL,
  `CODTAP` varchar(10) DEFAULT NULL,
  `CODBOR` varchar(10) DEFAULT NULL,
  `DIREC_INST` varchar(90) DEFAULT NULL,
  `IND_DUO` varchar(10) DEFAULT NULL,
  `tipo_linea` varchar(6) DEFAULT NULL,
  `telef_ip` varchar(10) DEFAULT NULL,
  `prom_linea` varchar(47) DEFAULT NULL,
  `des_prom_linea` varchar(60) DEFAULT NULL,
  `nodeid` varchar(10) DEFAULT NULL,
  `UBIPLAN` varchar(9) DEFAULT NULL,
  `PAIS` varchar(4) DEFAULT NULL,
  `UBIGEO` varchar(6) DEFAULT NULL,
  `ZONAL_ANT` varchar(3) DEFAULT NULL,
  `REGION` varchar(8) DEFAULT NULL,
  `ZONAL_NEW` varchar(10) DEFAULT NULL,
  `IND_DUNA` varchar(10) DEFAULT NULL,
  `AÑO_DUN` varchar(6) DEFAULT NULL,
  `CRUCE` varchar(4) DEFAULT NULL,
  `PAQUETE` varchar(15) DEFAULT NULL,
  `PAQUETE1` varchar(15) DEFAULT NULL,
  `SUB_NEG` varchar(4) DEFAULT NULL,
  `PROVEEDOR` varchar(4) DEFAULT NULL,
  `TECNOLOGIA` varchar(10) DEFAULT NULL,
  `PERU8K` varchar(7) DEFAULT NULL,
  `MARCAA` varchar(3) DEFAULT NULL,
  `CND_SRV_09` int(11) DEFAULT NULL,
  `CND_SRV_10` int(11) DEFAULT NULL,
  `CND_SRV_11` int(11) DEFAULT NULL,
  `EXCLUSANT` varchar(50) DEFAULT NULL,
  `PROV_ANT` varchar(12) DEFAULT NULL,
  `NEGO_ANT` varchar(10) DEFAULT NULL,
  `CSER_ANT` varchar(2) DEFAULT NULL,
  `PAQU_ANT` varchar(15) DEFAULT NULL,
  `PAQU1_ANT` varchar(10) DEFAULT NULL,
  `SEGMENTO` varchar(15) DEFAULT NULL,
  `SEGMENTO0` varchar(15) DEFAULT NULL,
  `EX_CTA` varchar(13) DEFAULT NULL,
  `MARCA_SUS` int(11) DEFAULT NULL,
  `EXCLU_SUS` varchar(32) DEFAULT NULL,
  `EX_BJ_INCO` varchar(50) DEFAULT NULL,
  `IND_EXCLUS` varchar(46) DEFAULT NULL,
  `SEG_CMS` varchar(2) DEFAULT NULL,
  `JEFCOM` varchar(10) DEFAULT NULL,
  `EECC` varchar(8) DEFAULT NULL,
  `REGION_COC` varchar(8) DEFAULT NULL,
  `ZON_REGION` varchar(4) DEFAULT NULL,
  `PREM_MAS` varchar(7) DEFAULT NULL,
  `DET_REGION` varchar(15) DEFAULT NULL,
  `JEF_REGION` varchar(8) DEFAULT NULL,
  `SEG_SLAS` varchar(11) DEFAULT NULL,
  `TOP_NOTOP` varchar(17) DEFAULT NULL,
  `JEFATU_NUE` varchar(4) DEFAULT NULL,
  `CLIEN_SRV` varchar(15) DEFAULT NULL,
  `MICROZONA` varchar(10) DEFAULT NULL,
  `LLAVE_UBIG` varchar(15) DEFAULT NULL,
  `TERRENO` varchar(15) DEFAULT NULL,
  `EXCLUYE` varchar(1) DEFAULT NULL,
  `IND_VIP` varchar(1) DEFAULT NULL,
  `TELEFONO` int(11) DEFAULT NULL,
  `TIPO` varchar(10) DEFAULT NULL,
  `DIRECCION` varchar(75) DEFAULT NULL,
  `IP` varchar(20) DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `CMTS` varchar(20) DEFAULT NULL,
  `TEC` varchar(5) DEFAULT NULL,
  `DIGITALIZA` varchar(2) DEFAULT NULL,
  `PAQUETE_HD` varchar(2) DEFAULT NULL,
  `SERVPACK` varchar(50) DEFAULT NULL,
  `VEL_SERVPA` varchar(10) DEFAULT NULL,
  `TIPO_VIA` varchar(4) DEFAULT NULL,
  `VIA` varchar(39) DEFAULT NULL,
  `NRO` varchar(6) DEFAULT NULL,
  `PISO` varchar(4) DEFAULT NULL,
  `INTERIOR` varchar(7) DEFAULT NULL,
  `MZ` varchar(7) DEFAULT NULL,
  `LT` varchar(7) DEFAULT NULL,
  `TIPOPERU8K` varchar(20) DEFAULT NULL,
  `CLIENCCM1` varchar(2) DEFAULT NULL,
  `VOZIP` varchar(2) DEFAULT NULL,
  `PRODCOMER` varchar(100) DEFAULT NULL,
  `VEL_PRODCO` varchar(50) DEFAULT NULL,
  `DIGITAL2` int(11) DEFAULT NULL,
  `DIG_FECHA` varchar(20) DEFAULT NULL,
  `DIG_ESTADO` varchar(18) DEFAULT NULL,
  `DECO_ACT` int(11) DEFAULT NULL,
  `DECO_SUSP` int(11) DEFAULT NULL,
  `TIPREQ_PED` varchar(10) DEFAULT NULL,
  `proceso` date DEFAULT NULL,
  `FECHA_CARGA` char(10) DEFAULT NULL,
  `canserv` int(11) DEFAULT NULL,
  KEY `id_cliente` (`CLIENTE`),
  KEY `canserv` (`canserv`),
  KEY `NODO` (`NODO`),
  KEY `PLANO` (`PLANO`),
  KEY `CODLEX` (`CODLEX`),
  KEY `CODTAP` (`CODTAP`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `planta_hfc`
--

DROP TABLE IF EXISTS `planta_hfc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `planta_hfc` (
  `CLIENTE` int(10) DEFAULT NULL,
  `CUENTA` int(10) DEFAULT NULL,
  `SERVICIO` int(11) NOT NULL,
  `CON_SRV` int(11) DEFAULT NULL,
  `CLASESRV` varchar(2) DEFAULT NULL,
  `TIPOSRV` int(11) DEFAULT NULL,
  `CATEGORIA` varchar(3) DEFAULT NULL,
  `OFI_CLI` varchar(3) DEFAULT NULL,
  `OFI_SRV` varchar(3) DEFAULT NULL,
  `CODDPT` varchar(3) DEFAULT NULL,
  `DESDPT` varchar(15) DEFAULT NULL,
  `CODPVC` varchar(3) DEFAULT NULL,
  `DESPVC` varchar(30) DEFAULT NULL,
  `CODDTT` varchar(3) DEFAULT NULL,
  `DESDTT` varchar(40) DEFAULT NULL,
  `INDFACT` varchar(2) DEFAULT NULL,
  `NODO` varchar(4) DEFAULT NULL,
  `DESNODO` varchar(30) DEFAULT NULL,
  `PLANO` varchar(5) DEFAULT NULL,
  `XIND_VIP` varchar(1) DEFAULT NULL,
  `TIPO_DOCUM` varchar(2) DEFAULT NULL,
  `NUMERORUC` varchar(12) DEFAULT NULL,
  `NUMERODOC` varchar(10) DEFAULT NULL,
  `TELEFCL1` varchar(15) DEFAULT NULL,
  `TELEFCL2` varchar(15) DEFAULT NULL,
  `TELEFCL3` varchar(15) DEFAULT NULL,
  `PETICATIS` varchar(20) DEFAULT NULL,
  `SEGMCLIENT` varchar(10) DEFAULT NULL,
  `ESTADODUNA` varchar(15) DEFAULT NULL,
  `NOMBRE` varchar(50) DEFAULT NULL,
  `APE_PAT` varchar(50) DEFAULT NULL,
  `APE_MAT` varchar(40) DEFAULT NULL,
  `CODNIT` varchar(10) DEFAULT NULL,
  `UBIGEOGIS` varchar(10) DEFAULT NULL,
  `DESUBIGEGI` varchar(40) DEFAULT NULL,
  `CODLEX` varchar(10) DEFAULT NULL,
  `CODTAP` varchar(10) DEFAULT NULL,
  `CODBOR` varchar(10) DEFAULT NULL,
  `DIREC_INST` varchar(90) DEFAULT NULL,
  `IND_DUO` varchar(10) DEFAULT NULL,
  `tipo_linea` varchar(6) DEFAULT NULL,
  `telef_ip` varchar(10) DEFAULT NULL,
  `prom_linea` varchar(47) DEFAULT NULL,
  `des_prom_linea` varchar(60) DEFAULT NULL,
  `nodeid` varchar(10) DEFAULT NULL,
  `veloc_cms` int(10) DEFAULT NULL,
  `tiptec` varchar(50) DEFAULT NULL,
  `UBIPLAN` varchar(9) DEFAULT NULL,
  `PAIS` varchar(4) DEFAULT NULL,
  `UBIGEO` varchar(6) DEFAULT NULL,
  `ZONAL_ANT` varchar(3) DEFAULT NULL,
  `REGION` varchar(8) DEFAULT NULL,
  `ZONAL_NEW` varchar(10) DEFAULT NULL,
  `IND_DUNA` varchar(10) DEFAULT NULL,
  `AÑO_DUN` varchar(6) DEFAULT NULL,
  `CRUCE` varchar(4) DEFAULT NULL,
  `PAQUETE` varchar(15) DEFAULT NULL,
  `PAQUETE1` varchar(15) DEFAULT NULL,
  `SUB_NEG` varchar(4) DEFAULT NULL,
  `PROVEEDOR` varchar(4) DEFAULT NULL,
  `TECNOLOGIA` varchar(10) DEFAULT NULL,
  `PERU8K` varchar(7) DEFAULT NULL,
  `MARCAA` varchar(3) DEFAULT NULL,
  `CND_SRV_09` int(11) DEFAULT NULL,
  `CND_SRV_10` int(11) DEFAULT NULL,
  `CND_SRV_11` int(11) DEFAULT NULL,
  `EXCLUSANT` varchar(50) DEFAULT NULL,
  `PROV_ANT` varchar(12) DEFAULT NULL,
  `NEGO_ANT` varchar(10) DEFAULT NULL,
  `CSER_ANT` varchar(2) DEFAULT NULL,
  `PAQU_ANT` varchar(15) DEFAULT NULL,
  `PAQU1_ANT` varchar(10) DEFAULT NULL,
  `SEGMENTO` varchar(15) DEFAULT NULL,
  `SEGMENTO0` varchar(15) DEFAULT NULL,
  `EX_CTA` varchar(13) DEFAULT NULL,
  `MARCA_SUS` int(11) DEFAULT NULL,
  `EXCLU_SUS` varchar(32) DEFAULT NULL,
  `EX_BJ_INCO` varchar(50) DEFAULT NULL,
  `IND_EXCLUS` varchar(46) DEFAULT NULL,
  `SEG_CMS` varchar(2) DEFAULT NULL,
  `JEFCOM` varchar(10) DEFAULT NULL,
  `EECC` varchar(8) DEFAULT NULL,
  `REGION_COC` varchar(8) DEFAULT NULL,
  `ZON_REGION` varchar(4) DEFAULT NULL,
  `PREM_MAS` varchar(7) DEFAULT NULL,
  `DET_REGION` varchar(15) DEFAULT NULL,
  `JEF_REGION` varchar(8) DEFAULT NULL,
  `SEG_SLAS` varchar(11) DEFAULT NULL,
  `TOP_NOTOP` varchar(17) DEFAULT NULL,
  `JEFATU_NUE` varchar(4) DEFAULT NULL,
  `CLIEN_SRV` varchar(15) DEFAULT NULL,
  `MICROZONA` varchar(10) DEFAULT NULL,
  `LLAVE_UBIG` varchar(15) DEFAULT NULL,
  `TERRENO` varchar(15) DEFAULT NULL,
  `EXCLUYE` varchar(1) DEFAULT NULL,
  `IND_VIP` varchar(1) DEFAULT NULL,
  `TELEFONO` int(11) DEFAULT NULL,
  `TIPO` varchar(10) DEFAULT NULL,
  `DIRECCION` varchar(75) DEFAULT NULL,
  `IP` varchar(20) DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `CMTS` varchar(20) DEFAULT NULL,
  `TEC` varchar(5) DEFAULT NULL,
  `DIGITALIZA` varchar(2) DEFAULT NULL,
  `PAQUETE_HD` varchar(2) DEFAULT NULL,
  `SERVPACK` varchar(50) DEFAULT NULL,
  `VEL_SERVPA` varchar(10) DEFAULT NULL,
  `TIPO_VIA` varchar(4) DEFAULT NULL,
  `VIA` varchar(39) DEFAULT NULL,
  `NRO` int(6) DEFAULT NULL,
  `PISO` varchar(4) DEFAULT NULL,
  `INTERIOR` varchar(7) DEFAULT NULL,
  `MZ` varchar(7) DEFAULT NULL,
  `LT` varchar(7) DEFAULT NULL,
  `tipourbani` varchar(6) DEFAULT NULL,
  `urbanizaci` varchar(32) DEFAULT NULL,
  `TIPOPERU8K` varchar(20) DEFAULT NULL,
  `CLIENCCM1` varchar(2) DEFAULT NULL,
  `VOZIP` varchar(2) DEFAULT NULL,
  `PRODCOMER` varchar(100) DEFAULT NULL,
  `VEL_PRODCO` varchar(50) DEFAULT NULL,
  `DIGITAL2` int(11) DEFAULT NULL,
  `DIG_FECHA` varchar(20) DEFAULT NULL,
  `DIG_ESTADO` varchar(18) DEFAULT NULL,
  `DECO_ACT` int(11) DEFAULT NULL,
  `DECO_SUSP` int(11) DEFAULT NULL,
  `TIPREQ_PED` varchar(10) DEFAULT NULL,
  `proceso` date DEFAULT NULL,
  `FECHA_CARGA` char(10) DEFAULT NULL,
  `UNICO` char(2) CHARACTER SET utf8 DEFAULT NULL,
  `numcoo_x` varchar(30) DEFAULT NULL,
  `numcoo_y` varchar(30) DEFAULT NULL,
  `fuentexy` varchar(30) DEFAULT NULL,
  `nodotroba` varchar(10) DEFAULT NULL,
  `naked` varchar(20) DEFAULT NULL,
  UNIQUE KEY `SERVICIO` (`SERVICIO`),
  KEY `CLIENTE` (`CLIENTE`),
  KEY `CLASESRV` (`CLASESRV`),
  KEY `TIPOSRV` (`TIPOSRV`),
  KEY `OFI_CLI` (`OFI_CLI`),
  KEY `DESDPT` (`DESDPT`),
  KEY `CODDPT` (`CODDPT`),
  KEY `CODPVC` (`CODPVC`),
  KEY `DESPVC` (`DESPVC`),
  KEY `CODDTT` (`CODDTT`),
  KEY `DESDTT` (`DESDTT`),
  KEY `NODO` (`NODO`),
  KEY `PLANO` (`PLANO`),
  KEY `TELEFCL1` (`TELEFCL1`),
  KEY `TELEFCL2` (`TELEFCL2`),
  KEY `TELEFCL3` (`TELEFCL3`),
  KEY `UNICO` (`UNICO`),
  KEY `VIA` (`VIA`),
  KEY `NRO` (`NRO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prov_liq_catv_pais`
--

DROP TABLE IF EXISTS `prov_liq_catv_pais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prov_liq_catv_pais` (
  `codigo_req` int(11) DEFAULT NULL,
  `codigo_del_grupo_req` varchar(2) DEFAULT NULL,
  `codigo_tipo_req` varchar(2) DEFAULT NULL,
  `codigo_motivo_req` varchar(4) DEFAULT NULL,
  `codigo_del_cliente` int(11) DEFAULT NULL,
  `apellido_paterno` varchar(35) DEFAULT NULL,
  `apellido_materno` varchar(35) DEFAULT NULL,
  `nombres` varchar(30) DEFAULT NULL,
  `indicador_vip` varchar(10) DEFAULT NULL,
  `categoria_cliente` varchar(50) DEFAULT NULL,
  `codigo_del_servicio` int(11) DEFAULT NULL,
  `clase_de_servicio` varchar(100) DEFAULT NULL,
  `categoria_de_servicio` varchar(2) DEFAULT NULL,
  `oficina_administrativa` varchar(3) DEFAULT NULL,
  `departamento` varchar(3) DEFAULT NULL,
  `provincia` varchar(3) DEFAULT NULL,
  `distrito` varchar(3) DEFAULT NULL,
  `tipo_de_via` varchar(2) DEFAULT NULL,
  `nombre_de_la_via` varchar(30) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `piso` varchar(2) DEFAULT NULL,
  `interior` varchar(5) DEFAULT NULL,
  `manzana` varchar(5) DEFAULT NULL,
  `lote` varchar(5) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `plano` varchar(4) DEFAULT NULL,
  `sector` varchar(5) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `lex` varchar(4) DEFAULT NULL,
  `tap` varchar(4) DEFAULT NULL,
  `borne` varchar(4) DEFAULT NULL,
  `estacion` varchar(8) DEFAULT NULL,
  `situacion` varchar(4) DEFAULT NULL,
  `estado` varchar(1) DEFAULT NULL,
  `fecha_registro` varchar(20) DEFAULT NULL,
  `usuario_generacion` varchar(12) DEFAULT NULL,
  `ot` int(11) DEFAULT NULL,
  `fecha_asignacion` varchar(20) DEFAULT NULL,
  `estado_ot` varchar(1) DEFAULT NULL,
  `contrata` int(11) DEFAULT NULL,
  `tecnico` varchar(12) DEFAULT NULL,
  `codigo_de_liquidacion` varchar(12) DEFAULT NULL,
  `fecha_liquidacion` datetime DEFAULT NULL,
  `fecha_programacion` datetime DEFAULT NULL,
  `fecha_informacion` datetime DEFAULT NULL,
  `fecha_llegada` datetime DEFAULT NULL,
  `cross_cms` varchar(20) DEFAULT NULL,
  `sit_envio_actu` varchar(50) DEFAULT NULL,
  `ind_paquete` varchar(30) DEFAULT NULL,
  `tipvis_gestel` varchar(30) DEFAULT NULL,
  `tipvis_cms` varchar(30) DEFAULT NULL,
  `cod_sol_pai` varchar(30) DEFAULT NULL,
  `stdo_sol_pai` varchar(30) DEFAULT NULL,
  `fecha_reg_pai` datetime DEFAULT NULL,
  `ind_pos_fraude` varchar(30) DEFAULT NULL,
  `cod_mot_pos_fraude` varchar(10) DEFAULT NULL,
  `desc_mot_pos_fraude` varchar(100) DEFAULT NULL,
  `nro_ooss_gestel` varchar(30) DEFAULT NULL,
  `stdo_ooss_gestel` varchar(20) DEFAULT NULL,
  `desc_stdo_ooss_gestel` varchar(100) DEFAULT NULL,
  `tip_paquete` varchar(30) DEFAULT NULL,
  `cod_cmts` varchar(30) DEFAULT NULL,
  `desc_cmts2` varchar(100) DEFAULT NULL,
  `peticion_atis` varchar(30) DEFAULT NULL,
  `telefono_de_contacto` varchar(10) DEFAULT NULL,
  `celular_de_contacto` varchar(10) DEFAULT NULL,
  UNIQUE KEY `NewIndex1` (`codigo_req`),
  KEY `NewIndex2` (`codigo_del_cliente`),
  KEY `NewIndex3` (`ot`),
  KEY `idx_servicio` (`codigo_del_servicio`),
  KEY `fechaderegistro` (`fecha_registro`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prov_liq_catv_pais_c`
--

DROP TABLE IF EXISTS `prov_liq_catv_pais_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prov_liq_catv_pais_c` (
  `codigo_req` int(11) DEFAULT NULL,
  `codigo_del_grupo_req` varchar(2) DEFAULT NULL,
  `codigo_tipo_req` varchar(2) DEFAULT NULL,
  `codigo_motivo_req` varchar(4) DEFAULT NULL,
  `codigo_del_cliente` int(11) DEFAULT NULL,
  `apellido_paterno` varchar(35) DEFAULT NULL,
  `apellido_materno` varchar(35) DEFAULT NULL,
  `nombres` varchar(30) DEFAULT NULL,
  `indicador_vip` varchar(10) DEFAULT NULL,
  `categoria_cliente` varchar(50) DEFAULT NULL,
  `codigo_del_servicio` int(11) DEFAULT NULL,
  `clase_de_servicio` varchar(100) DEFAULT NULL,
  `categoria_de_servicio` varchar(2) DEFAULT NULL,
  `oficina_administrativa` varchar(3) DEFAULT NULL,
  `departamento` varchar(3) DEFAULT NULL,
  `provincia` varchar(3) DEFAULT NULL,
  `distrito` varchar(3) DEFAULT NULL,
  `tipo_de_via` varchar(2) DEFAULT NULL,
  `nombre_de_la_via` varchar(30) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `piso` varchar(2) DEFAULT NULL,
  `interior` varchar(5) DEFAULT NULL,
  `manzana` varchar(5) DEFAULT NULL,
  `lote` varchar(5) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `plano` varchar(4) DEFAULT NULL,
  `sector` varchar(5) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `lex` varchar(4) DEFAULT NULL,
  `tap` varchar(4) DEFAULT NULL,
  `borne` varchar(4) DEFAULT NULL,
  `estacion` varchar(8) DEFAULT NULL,
  `situacion` varchar(4) DEFAULT NULL,
  `estado` varchar(1) DEFAULT NULL,
  `fecha_registro` varchar(20) DEFAULT NULL,
  `usuario_generacion` varchar(12) DEFAULT NULL,
  `ot` int(11) DEFAULT NULL,
  `fecha_asignacion` varchar(20) DEFAULT NULL,
  `estado_ot` varchar(1) DEFAULT NULL,
  `contrata` int(11) DEFAULT NULL,
  `tecnico` varchar(12) DEFAULT NULL,
  `codigo_de_liquidacion` varchar(12) DEFAULT NULL,
  `fecha_liquidacion` datetime DEFAULT NULL,
  `fecha_programacion` datetime DEFAULT NULL,
  `fecha_informacion` datetime DEFAULT NULL,
  `fecha_llegada` datetime DEFAULT NULL,
  `cross_cms` varchar(20) DEFAULT NULL,
  `sit_envio_actu` varchar(50) DEFAULT NULL,
  `ind_paquete` varchar(30) DEFAULT NULL,
  `tipvis_gestel` varchar(30) DEFAULT NULL,
  `tipvis_cms` varchar(30) DEFAULT NULL,
  `cod_sol_pai` varchar(30) DEFAULT NULL,
  `stdo_sol_pai` varchar(30) DEFAULT NULL,
  `fecha_reg_pai` datetime DEFAULT NULL,
  `ind_pos_fraude` varchar(30) DEFAULT NULL,
  `cod_mot_pos_fraude` varchar(10) DEFAULT NULL,
  `desc_mot_pos_fraude` varchar(100) DEFAULT NULL,
  `nro_ooss_gestel` varchar(30) DEFAULT NULL,
  `stdo_ooss_gestel` varchar(20) DEFAULT NULL,
  `desc_stdo_ooss_gestel` varchar(100) DEFAULT NULL,
  `tip_paquete` varchar(30) DEFAULT NULL,
  `cod_cmts` varchar(30) DEFAULT NULL,
  `desc_cmts2` varchar(100) DEFAULT NULL,
  `peticion_atis` varchar(30) DEFAULT NULL,
  `telefono_de_contacto` varchar(10) DEFAULT NULL,
  `celular_de_contacto` varchar(10) DEFAULT NULL,
  UNIQUE KEY `NewIndex1` (`codigo_req`),
  KEY `NewIndex2` (`codigo_del_cliente`),
  KEY `NewIndex3` (`ot`),
  KEY `idx_servicio` (`codigo_del_servicio`),
  KEY `fechaderegistro` (`fecha_registro`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `lex` (`lex`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prov_liq_catv_pais_comp`
--

DROP TABLE IF EXISTS `prov_liq_catv_pais_comp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prov_liq_catv_pais_comp` (
  `codigo_req` int(11) DEFAULT NULL,
  `Ind_Origen_Req` varchar(1) DEFAULT NULL,
  `indice_de_componente` varchar(30) DEFAULT NULL,
  `codigo_de_componente` int(11) DEFAULT NULL,
  `codigo_elemento_servicio` varchar(3) DEFAULT NULL,
  `codigo_material` varchar(20) DEFAULT NULL,
  `numero_de_serie` varchar(32) DEFAULT NULL,
  `estado_componente` varchar(5) DEFAULT NULL,
  `fecha_carga` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `NewIndex3` (`codigo_req`,`indice_de_componente`),
  KEY `NewIndex1` (`codigo_req`),
  KEY `NewIndex2` (`codigo_req`,`codigo_de_componente`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prov_liq_catv_pais_comp_c`
--

DROP TABLE IF EXISTS `prov_liq_catv_pais_comp_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prov_liq_catv_pais_comp_c` (
  `codigo_req` int(11) DEFAULT NULL,
  `Ind_Origen_Req` varchar(1) DEFAULT NULL,
  `indice_de_componente` varchar(30) DEFAULT NULL,
  `codigo_de_componente` int(11) DEFAULT NULL,
  `codigo_elemento_servicio` varchar(3) DEFAULT NULL,
  `codigo_material` varchar(20) DEFAULT NULL,
  `numero_de_serie` varchar(32) DEFAULT NULL,
  `estado_componente` varchar(5) DEFAULT NULL,
  `fecha_carga` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `NewIndex3` (`codigo_req`,`indice_de_componente`),
  KEY `NewIndex1` (`codigo_req`),
  KEY `NewIndex2` (`codigo_req`,`codigo_de_componente`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prov_pen_catv_pais`
--

DROP TABLE IF EXISTS `prov_pen_catv_pais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prov_pen_catv_pais` (
  `codigo_req` int(11) DEFAULT NULL,
  `codigo_del_grupo_req` varchar(2) DEFAULT NULL,
  `codigo_tipo_req` varchar(2) DEFAULT NULL,
  `codigo_motivo_req` varchar(4) DEFAULT NULL,
  `codigo_del_cliente` int(11) DEFAULT NULL,
  `apellido_paterno` varchar(35) DEFAULT NULL,
  `apellido_materno` varchar(35) DEFAULT NULL,
  `nombres` varchar(30) DEFAULT NULL,
  `indicador_vip` varchar(10) DEFAULT NULL,
  `categoria_cliente` varchar(50) DEFAULT NULL,
  `codigo_del_servicio` int(11) DEFAULT NULL,
  `clase_de_servicio` varchar(100) DEFAULT NULL,
  `categoria_de_servicio` varchar(2) DEFAULT NULL,
  `oficina_administrativa` varchar(3) DEFAULT NULL,
  `departamento` varchar(3) DEFAULT NULL,
  `provincia` varchar(3) DEFAULT NULL,
  `distrito` varchar(3) DEFAULT NULL,
  `tipo_de_via` varchar(2) DEFAULT NULL,
  `nombre_de_la_via` varchar(30) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `piso` varchar(2) DEFAULT NULL,
  `interior` varchar(5) DEFAULT NULL,
  `manzana` varchar(5) DEFAULT NULL,
  `lote` varchar(5) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `plano` varchar(4) DEFAULT NULL,
  `sector` varchar(5) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `lex` varchar(4) DEFAULT NULL,
  `tap` varchar(4) DEFAULT NULL,
  `borne` varchar(4) DEFAULT NULL,
  `estacion` varchar(8) DEFAULT NULL,
  `situacion` varchar(4) DEFAULT NULL,
  `estado` varchar(1) DEFAULT NULL,
  `fecha_registro` varchar(20) DEFAULT NULL,
  `usuario_generacion` varchar(12) DEFAULT NULL,
  `ot` int(11) DEFAULT NULL,
  `fecha_asignacion` varchar(20) DEFAULT NULL,
  `estado_ot` varchar(1) DEFAULT NULL,
  `contrata` int(11) DEFAULT NULL,
  `fecha_programacion` datetime DEFAULT NULL,
  `fecha_informacion` datetime DEFAULT NULL,
  `fecha_llegada` datetime DEFAULT NULL,
  `cross_cms` varchar(20) DEFAULT NULL,
  `sit_envio_actu` varchar(50) DEFAULT NULL,
  `ind_paquete` varchar(30) DEFAULT NULL,
  `tipvis_gestel` varchar(30) DEFAULT NULL,
  `tipvis_cms` varchar(30) DEFAULT NULL,
  `cod_sol_pai` varchar(30) DEFAULT NULL,
  `stdo_sol_pai` varchar(30) DEFAULT NULL,
  `fecha_reg_pai` datetime DEFAULT NULL,
  `ind_pos_fraude` varchar(30) DEFAULT NULL,
  `cod_mot_pos_fraude` varchar(10) DEFAULT NULL,
  `desc_mot_pos_fraude` varchar(100) DEFAULT NULL,
  `nro_ooss_gestel` varchar(30) DEFAULT NULL,
  `stdo_ooss_gestel` varchar(20) DEFAULT NULL,
  `desc_stdo_ooss_gestel` varchar(100) DEFAULT NULL,
  `tip_paquete` varchar(30) DEFAULT NULL,
  `cod_cmts` varchar(30) DEFAULT NULL,
  `desc_cmts2` varchar(100) DEFAULT NULL,
  `peticion_atis` varchar(30) DEFAULT NULL,
  `motivo_devolucion` varchar(50) DEFAULT NULL,
  `obs_devolucion` varchar(100) DEFAULT NULL,
  `telefono_contacto` varchar(30) DEFAULT NULL,
  `celular_contacto` varchar(50) DEFAULT NULL,
  `tratamiento_pai` varchar(10) DEFAULT NULL,
  `tecnico_devolucion` varchar(10) DEFAULT NULL,
  `tipo_oper_comercial` varchar(10) DEFAULT NULL,
  `flag_playa` varchar(1) DEFAULT NULL COMMENT 'Indicador de Playa (1/0)',
  `nom_playa` varchar(50) DEFAULT NULL COMMENT 'Nombre de Playa',
  `km_playa` varchar(10) DEFAULT NULL COMMENT 'Kilometro de Playa',
  `CRC` varchar(10) DEFAULT NULL COMMENT 'Codigo de cupo de playa CRC',
  `bloque_canales` varchar(200) DEFAULT NULL COMMENT 'Informacion de bloque Canales',
  `direccion_facturacion` varchar(200) DEFAULT NULL COMMENT 'Direccion de facturacion',
  `desc_motivo` varchar(100) DEFAULT NULL COMMENT 'descripcion de motivo',
  `tipo_cliente_playa` varchar(1) DEFAULT NULL COMMENT 'tipo cliente (I/P)',
  `file_fuente` varchar(150) DEFAULT NULL,
  `fecha_upload` datetime DEFAULT NULL,
  UNIQUE KEY `NewIndex1` (`codigo_req`),
  KEY `idx_contrata` (`contrata`),
  KEY `idx_nodo_plano` (`nodo`,`plano`),
  KEY `idx_codser` (`codigo_del_servicio`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prov_pen_catv_pais_20160811`
--

DROP TABLE IF EXISTS `prov_pen_catv_pais_20160811`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prov_pen_catv_pais_20160811` (
  `codigo_req` int(11) DEFAULT NULL,
  `codigo_del_grupo_req` varchar(2) DEFAULT NULL,
  `codigo_tipo_req` varchar(2) DEFAULT NULL,
  `codigo_motivo_req` varchar(4) DEFAULT NULL,
  `codigo_del_cliente` int(11) DEFAULT NULL,
  `apellido_paterno` varchar(35) DEFAULT NULL,
  `apellido_materno` varchar(35) DEFAULT NULL,
  `nombres` varchar(30) DEFAULT NULL,
  `indicador_vip` varchar(10) DEFAULT NULL,
  `categoria_cliente` varchar(50) DEFAULT NULL,
  `codigo_del_servicio` int(11) DEFAULT NULL,
  `clase_de_servicio` varchar(100) DEFAULT NULL,
  `categoria_de_servicio` varchar(2) DEFAULT NULL,
  `oficina_administrativa` varchar(3) DEFAULT NULL,
  `departamento` varchar(3) DEFAULT NULL,
  `provincia` varchar(3) DEFAULT NULL,
  `distrito` varchar(3) DEFAULT NULL,
  `tipo_de_via` varchar(2) DEFAULT NULL,
  `nombre_de_la_via` varchar(30) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `piso` varchar(2) DEFAULT NULL,
  `interior` varchar(5) DEFAULT NULL,
  `manzana` varchar(5) DEFAULT NULL,
  `lote` varchar(5) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `plano` varchar(4) DEFAULT NULL,
  `sector` varchar(5) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `lex` varchar(4) DEFAULT NULL,
  `tap` varchar(4) DEFAULT NULL,
  `borne` varchar(4) DEFAULT NULL,
  `estacion` varchar(8) DEFAULT NULL,
  `situacion` varchar(4) DEFAULT NULL,
  `estado` varchar(1) DEFAULT NULL,
  `fecha_registro` varchar(20) DEFAULT NULL,
  `usuario_generacion` varchar(12) DEFAULT NULL,
  `ot` int(11) DEFAULT NULL,
  `fecha_asignacion` varchar(20) DEFAULT NULL,
  `estado_ot` varchar(1) DEFAULT NULL,
  `contrata` int(11) DEFAULT NULL,
  `fecha_programacion` datetime DEFAULT NULL,
  `fecha_informacion` datetime DEFAULT NULL,
  `fecha_llegada` datetime DEFAULT NULL,
  `cross_cms` varchar(20) DEFAULT NULL,
  `sit_envio_actu` varchar(50) DEFAULT NULL,
  `ind_paquete` varchar(30) DEFAULT NULL,
  `tipvis_gestel` varchar(30) DEFAULT NULL,
  `tipvis_cms` varchar(30) DEFAULT NULL,
  `cod_sol_pai` varchar(30) DEFAULT NULL,
  `stdo_sol_pai` varchar(30) DEFAULT NULL,
  `fecha_reg_pai` datetime DEFAULT NULL,
  `ind_pos_fraude` varchar(30) DEFAULT NULL,
  `cod_mot_pos_fraude` varchar(10) DEFAULT NULL,
  `desc_mot_pos_fraude` varchar(100) DEFAULT NULL,
  `nro_ooss_gestel` varchar(30) DEFAULT NULL,
  `stdo_ooss_gestel` varchar(20) DEFAULT NULL,
  `desc_stdo_ooss_gestel` varchar(100) DEFAULT NULL,
  `tip_paquete` varchar(30) DEFAULT NULL,
  `cod_cmts` varchar(30) DEFAULT NULL,
  `desc_cmts2` varchar(100) DEFAULT NULL,
  `peticion_atis` varchar(30) DEFAULT NULL,
  `motivo_devolucion` varchar(50) DEFAULT NULL,
  `obs_devolucion` varchar(100) DEFAULT NULL,
  `telefono_contacto` varchar(30) DEFAULT NULL,
  `celular_contacto` varchar(50) DEFAULT NULL,
  `tratamiento_pai` varchar(10) DEFAULT NULL,
  `tecnico_devolucion` varchar(10) DEFAULT NULL,
  `tipo_oper_comercial` varchar(10) DEFAULT NULL,
  `flag_playa` varchar(1) DEFAULT NULL,
  `nom_playa` varchar(50) DEFAULT NULL,
  `km_playa` varchar(10) DEFAULT NULL,
  `CRC` varchar(10) DEFAULT NULL,
  `bloque_canales` varchar(200) DEFAULT NULL,
  `direccion_facturacion` varchar(200) DEFAULT NULL,
  `desc_motivo` varchar(100) DEFAULT NULL,
  `tipo_cliente_playa` varchar(1) DEFAULT NULL,
  `file_fuente` varchar(150) DEFAULT NULL,
  `fecha_upload` varchar(20) DEFAULT NULL,
  UNIQUE KEY `NewIndex1` (`codigo_req`),
  KEY `NewIndex2` (`codigo_del_cliente`),
  KEY `NewIndex3` (`codigo_tipo_req`),
  KEY `NewIndex4` (`codigo_del_grupo_req`),
  KEY `NewIndex5` (`fecha_registro`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prov_pen_catv_pais_c`
--

DROP TABLE IF EXISTS `prov_pen_catv_pais_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prov_pen_catv_pais_c` (
  `codigo_req` int(11) DEFAULT NULL,
  `codigo_del_grupo_req` varchar(2) DEFAULT NULL,
  `codigo_tipo_req` varchar(2) DEFAULT NULL,
  `codigo_motivo_req` varchar(4) DEFAULT NULL,
  `codigo_del_cliente` int(11) DEFAULT NULL,
  `apellido_paterno` varchar(35) DEFAULT NULL,
  `apellido_materno` varchar(35) DEFAULT NULL,
  `nombres` varchar(30) DEFAULT NULL,
  `indicador_vip` varchar(10) DEFAULT NULL,
  `categoria_cliente` varchar(50) DEFAULT NULL,
  `codigo_del_servicio` int(11) DEFAULT NULL,
  `clase_de_servicio` varchar(100) DEFAULT NULL,
  `categoria_de_servicio` varchar(2) DEFAULT NULL,
  `oficina_administrativa` varchar(3) DEFAULT NULL,
  `departamento` varchar(3) DEFAULT NULL,
  `provincia` varchar(3) DEFAULT NULL,
  `distrito` varchar(3) DEFAULT NULL,
  `tipo_de_via` varchar(2) DEFAULT NULL,
  `nombre_de_la_via` varchar(30) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `piso` varchar(2) DEFAULT NULL,
  `interior` varchar(5) DEFAULT NULL,
  `manzana` varchar(5) DEFAULT NULL,
  `lote` varchar(5) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `plano` varchar(4) DEFAULT NULL,
  `sector` varchar(5) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `lex` varchar(4) DEFAULT NULL,
  `tap` varchar(4) DEFAULT NULL,
  `borne` varchar(4) DEFAULT NULL,
  `estacion` varchar(8) DEFAULT NULL,
  `situacion` varchar(4) DEFAULT NULL,
  `estado` varchar(1) DEFAULT NULL,
  `fecha_registro` varchar(20) DEFAULT NULL,
  `usuario_generacion` varchar(12) DEFAULT NULL,
  `ot` int(11) DEFAULT NULL,
  `fecha_asignacion` varchar(20) DEFAULT NULL,
  `estado_ot` varchar(1) DEFAULT NULL,
  `contrata` int(11) DEFAULT NULL,
  `fecha_programacion` datetime DEFAULT NULL,
  `fecha_informacion` datetime DEFAULT NULL,
  `fecha_llegada` datetime DEFAULT NULL,
  `cross_cms` varchar(20) DEFAULT NULL,
  `sit_envio_actu` varchar(50) DEFAULT NULL,
  `ind_paquete` varchar(30) DEFAULT NULL,
  `tipvis_gestel` varchar(30) DEFAULT NULL,
  `tipvis_cms` varchar(30) DEFAULT NULL,
  `cod_sol_pai` varchar(30) DEFAULT NULL,
  `stdo_sol_pai` varchar(30) DEFAULT NULL,
  `fecha_reg_pai` datetime DEFAULT NULL,
  `ind_pos_fraude` varchar(30) DEFAULT NULL,
  `cod_mot_pos_fraude` varchar(10) DEFAULT NULL,
  `desc_mot_pos_fraude` varchar(100) DEFAULT NULL,
  `nro_ooss_gestel` varchar(30) DEFAULT NULL,
  `stdo_ooss_gestel` varchar(20) DEFAULT NULL,
  `desc_stdo_ooss_gestel` varchar(100) DEFAULT NULL,
  `tip_paquete` varchar(30) DEFAULT NULL,
  `cod_cmts` varchar(30) DEFAULT NULL,
  `desc_cmts2` varchar(100) DEFAULT NULL,
  `peticion_atis` varchar(30) DEFAULT NULL,
  `motivo_devolucion` varchar(50) DEFAULT NULL,
  `obs_devolucion` varchar(100) DEFAULT NULL,
  `telefono_contacto` varchar(30) DEFAULT NULL,
  `celular_contacto` varchar(50) DEFAULT NULL,
  `tratamiento_pai` varchar(10) DEFAULT NULL,
  `tecnico_devolucion` varchar(10) DEFAULT NULL,
  `tipo_oper_comercial` varchar(10) DEFAULT NULL,
  `flag_playa` varchar(1) DEFAULT NULL COMMENT 'Indicador de Playa (1/0)',
  `nom_playa` varchar(50) DEFAULT NULL COMMENT 'Nombre de Playa',
  `km_playa` varchar(10) DEFAULT NULL COMMENT 'Kilometro de Playa',
  `CRC` varchar(10) DEFAULT NULL COMMENT 'Codigo de cupo de playa CRC',
  `bloque_canales` varchar(200) DEFAULT NULL COMMENT 'Informacion de bloque Canales',
  `direccion_facturacion` varchar(200) DEFAULT NULL COMMENT 'Direccion de facturacion',
  `desc_motivo` varchar(100) DEFAULT NULL COMMENT 'descripcion de motivo',
  `tipo_cliente_playa` varchar(1) DEFAULT NULL COMMENT 'tipo cliente (I/P)',
  `file_fuente` varchar(150) DEFAULT NULL,
  `fecha_upload` datetime DEFAULT NULL,
  UNIQUE KEY `NewIndex1` (`codigo_req`),
  KEY `idx_contrata` (`contrata`),
  KEY `idx_nodo_plano` (`nodo`,`plano`),
  KEY `idx_codser` (`codigo_del_servicio`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `re_pen_atencion`
--

DROP TABLE IF EXISTS `re_pen_atencion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `re_pen_atencion` (
  `FECHA_CORTE` varchar(20) DEFAULT NULL,
  `SEGMENTO` varchar(35) DEFAULT NULL,
  `SISTEMA` varchar(10) DEFAULT NULL,
  `COD_PEDIDO` int(11) DEFAULT NULL,
  `TIPO_IMPACTO` varchar(50) DEFAULT NULL,
  `IND_CUMPLIMIENTO` varchar(10) DEFAULT NULL,
  `FECHA_COMPROMISO` varchar(20) DEFAULT NULL,
  `DIAS_FALTANTES` int(11) DEFAULT NULL,
  `IND_ABC` varchar(10) DEFAULT NULL,
  `IND_AGENDAMIENTO` varchar(10) DEFAULT NULL,
  `IND_GAUDI` varchar(10) DEFAULT NULL,
  `TIPO_AGENDA` varchar(50) DEFAULT NULL,
  `TIPO_OPERACION_COMERCIAL` varchar(50) DEFAULT NULL,
  `COD_OC` varchar(50) DEFAULT NULL,
  `PRODUCTO` varchar(50) DEFAULT NULL,
  `FECHA_REGISTRO` varchar(20) DEFAULT NULL,
  `DIAS_REG` int(11) DEFAULT NULL,
  `FECHA_BOLSA` varchar(20) DEFAULT NULL,
  `DIAS_BOLSA` int(11) DEFAULT NULL,
  `AREA` varchar(50) DEFAULT NULL,
  `BOLSA` varchar(50) DEFAULT NULL,
  `NUM_TELEF` varchar(15) DEFAULT NULL,
  `NUM_TELEF_CONTACTO` varchar(15) DEFAULT NULL,
  `COD_CLIENTE` int(11) DEFAULT NULL,
  `COD_CUENTA` int(11) DEFAULT NULL,
  `NUM_INSCRIP` int(11) DEFAULT NULL,
  `TIPO_DOC_CTA` varchar(15) DEFAULT NULL,
  `NUM_DOC_CTA` int(11) DEFAULT NULL,
  `COD_UBIGEO` varchar(15) DEFAULT NULL,
  `DES_DISTRITO` varchar(150) DEFAULT NULL,
  `CIUDAD` varchar(150) DEFAULT NULL,
  `DES_CIUDAD` varchar(150) DEFAULT NULL,
  `LUGAR` varchar(150) DEFAULT NULL,
  `ZONAL` varchar(50) DEFAULT NULL,
  `ZONAL_FINAL` varchar(50) DEFAULT NULL,
  `MDF` varchar(50) DEFAULT NULL,
  `NODO` varchar(50) DEFAULT NULL,
  `JEFATURA` varchar(50) DEFAULT NULL,
  `TIPO_VIA` varchar(50) DEFAULT NULL,
  `NOMBRE_VIA` varchar(150) DEFAULT NULL,
  `NUMERO_VIA` varchar(150) DEFAULT NULL,
  `DIR_COMPLE1` varchar(150) DEFAULT NULL,
  `DIR_COMPLE2` varchar(150) DEFAULT NULL,
  `CICLO_FACT` varchar(150) DEFAULT NULL,
  `NOMBRE_FACT` varchar(150) DEFAULT NULL,
  `APELLIDO_FACT` varchar(150) DEFAULT NULL,
  `COD_USUARIO` varchar(150) DEFAULT NULL,
  `COD_PTO` varchar(150) DEFAULT NULL,
  `DES_PTO` varchar(150) DEFAULT NULL,
  `DES_CANAL` varchar(150) DEFAULT NULL,
  `COD_VENDEDOR` varchar(150) DEFAULT NULL,
  `OOSS` varchar(150) DEFAULT NULL,
  `CODMOV` varchar(150) DEFAULT NULL,
  `COD_MOTIVO` varchar(150) DEFAULT NULL,
  `NRO_SEC` varchar(150) DEFAULT NULL,
  `COMENTARIO_LARGO` varchar(150) DEFAULT NULL,
  `COMENTARIO_CORTO` varchar(150) DEFAULT NULL,
  `COD_SER` varchar(150) DEFAULT NULL,
  `DES_SERV` varchar(150) DEFAULT NULL,
  `ESTADO_SOLIC_PLANTA` varchar(150) DEFAULT NULL,
  `IND_REVISADO` varchar(150) DEFAULT NULL,
  `MOTIVO_REVISION` varchar(150) DEFAULT NULL,
  `DESCRIPCION_REVISION` varchar(150) DEFAULT NULL,
  `TIPO_BOLSA` varchar(150) DEFAULT NULL,
  `TIPO_ACTUACION` varchar(150) DEFAULT NULL,
  `COD_ESTACION` varchar(150) DEFAULT NULL,
  `DES_ESTACION` varchar(150) DEFAULT NULL,
  `BOLSA_ORIGEN` varchar(150) DEFAULT NULL,
  `DES_PTO_ORIGEN` varchar(150) DEFAULT NULL,
  `CM_FLUJO` varchar(150) DEFAULT NULL,
  `COD_CONTRATA` varchar(150) DEFAULT NULL,
  `DES_CONTRATA` varchar(150) DEFAULT NULL,
  `MOT_ACT` varchar(150) DEFAULT NULL,
  `DESCRIPCION` varchar(150) DEFAULT NULL,
  `FECHA_PROG_CMS` varchar(150) DEFAULT NULL,
  `IND_CUMPLIMIENTO_ESTACION` varchar(150) DEFAULT NULL,
  `IND_INCIDENCIA_SIST` varchar(150) DEFAULT NULL,
  `DES_PROBLEMA` varchar(150) DEFAULT NULL,
  `AGRUP_PTO` varchar(150) DEFAULT NULL,
  `APE_MAT_FACT` varchar(150) DEFAULT NULL,
  `BOLSA_CASUISTICA` varchar(150) DEFAULT NULL,
  `REQ_FE_SITPED` varchar(150) DEFAULT NULL,
  `EQUIPO_SIS` varchar(150) DEFAULT NULL,
  `DES_INCIDENCIA` varchar(150) DEFAULT NULL,
  `MULTI_CASUISTICA` varchar(150) DEFAULT NULL,
  `DIAS_BOLSA_N` varchar(150) DEFAULT NULL,
  `TIPO_TUP` varchar(150) DEFAULT NULL,
  `TIPO_SPEEDY` varchar(150) DEFAULT NULL,
  `TIPO_ESTANCO` varchar(150) DEFAULT NULL,
  `COC_CMS_COD_MOTIVO` varchar(150) DEFAULT NULL,
  `INDICADOR_RECLAMO` varchar(150) DEFAULT NULL,
  `DES_RECLAMO` varchar(150) DEFAULT NULL,
  `TRASLADOS_MP` varchar(150) DEFAULT NULL,
  `COD_CLIENTE_ASOCIADO` varchar(150) DEFAULT NULL,
  `CODIGO_CONTACTO_TR` varchar(150) DEFAULT NULL,
  `FECHA_ALTA_CONTACTO_TR` varchar(150) DEFAULT NULL,
  `IND_CROSS` varchar(150) DEFAULT NULL,
  `COC_CMS_COD_TIPO_REQ` varchar(150) DEFAULT NULL,
  `CODIGO_REMEDY` varchar(150) DEFAULT NULL,
  `TIPO_INCIDENCIA` varchar(150) DEFAULT NULL,
  KEY `NewIndex1` (`COD_CLIENTE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `re_pen_atencion_c`
--

DROP TABLE IF EXISTS `re_pen_atencion_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `re_pen_atencion_c` (
  `FECHA_CORTE` varchar(20) DEFAULT NULL,
  `SEGMENTO` varchar(35) DEFAULT NULL,
  `SISTEMA` varchar(10) DEFAULT NULL,
  `COD_PEDIDO` int(11) DEFAULT NULL,
  `TIPO_IMPACTO` varchar(50) DEFAULT NULL,
  `IND_CUMPLIMIENTO` varchar(10) DEFAULT NULL,
  `FECHA_COMPROMISO` varchar(20) DEFAULT NULL,
  `DIAS_FALTANTES` int(11) DEFAULT NULL,
  `IND_ABC` varchar(10) DEFAULT NULL,
  `IND_AGENDAMIENTO` varchar(10) DEFAULT NULL,
  `IND_GAUDI` varchar(10) DEFAULT NULL,
  `TIPO_AGENDA` varchar(50) DEFAULT NULL,
  `TIPO_OPERACION_COMERCIAL` varchar(50) DEFAULT NULL,
  `COD_OC` varchar(50) DEFAULT NULL,
  `PRODUCTO` varchar(50) DEFAULT NULL,
  `FECHA_REGISTRO` varchar(20) DEFAULT NULL,
  `DIAS_REG` int(11) DEFAULT NULL,
  `FECHA_BOLSA` varchar(20) DEFAULT NULL,
  `DIAS_BOLSA` int(11) DEFAULT NULL,
  `AREA` varchar(50) DEFAULT NULL,
  `BOLSA` varchar(50) DEFAULT NULL,
  `NUM_TELEF` varchar(15) DEFAULT NULL,
  `NUM_TELEF_CONTACTO` varchar(15) DEFAULT NULL,
  `COD_CLIENTE` int(11) DEFAULT NULL,
  `COD_CUENTA` int(11) DEFAULT NULL,
  `NUM_INSCRIP` int(11) DEFAULT NULL,
  `TIPO_DOC_CTA` varchar(15) DEFAULT NULL,
  `NUM_DOC_CTA` int(11) DEFAULT NULL,
  `COD_UBIGEO` varchar(15) DEFAULT NULL,
  `DES_DISTRITO` varchar(150) DEFAULT NULL,
  `CIUDAD` varchar(150) DEFAULT NULL,
  `DES_CIUDAD` varchar(150) DEFAULT NULL,
  `LUGAR` varchar(150) DEFAULT NULL,
  `ZONAL` varchar(50) DEFAULT NULL,
  `ZONAL_FINAL` varchar(50) DEFAULT NULL,
  `MDF` varchar(50) DEFAULT NULL,
  `NODO` varchar(50) DEFAULT NULL,
  `JEFATURA` varchar(50) DEFAULT NULL,
  `TIPO_VIA` varchar(50) DEFAULT NULL,
  `NOMBRE_VIA` varchar(150) DEFAULT NULL,
  `NUMERO_VIA` varchar(150) DEFAULT NULL,
  `DIR_COMPLE1` varchar(150) DEFAULT NULL,
  `DIR_COMPLE2` varchar(150) DEFAULT NULL,
  `CICLO_FACT` varchar(150) DEFAULT NULL,
  `NOMBRE_FACT` varchar(150) DEFAULT NULL,
  `APELLIDO_FACT` varchar(150) DEFAULT NULL,
  `COD_USUARIO` varchar(150) DEFAULT NULL,
  `COD_PTO` varchar(150) DEFAULT NULL,
  `DES_PTO` varchar(150) DEFAULT NULL,
  `DES_CANAL` varchar(150) DEFAULT NULL,
  `COD_VENDEDOR` varchar(150) DEFAULT NULL,
  `OOSS` varchar(150) DEFAULT NULL,
  `CODMOV` varchar(150) DEFAULT NULL,
  `COD_MOTIVO` varchar(150) DEFAULT NULL,
  `NRO_SEC` varchar(150) DEFAULT NULL,
  `COMENTARIO_LARGO` varchar(150) DEFAULT NULL,
  `COMENTARIO_CORTO` varchar(150) DEFAULT NULL,
  `COD_SER` varchar(150) DEFAULT NULL,
  `DES_SERV` varchar(150) DEFAULT NULL,
  `ESTADO_SOLIC_PLANTA` varchar(150) DEFAULT NULL,
  `IND_REVISADO` varchar(150) DEFAULT NULL,
  `MOTIVO_REVISION` varchar(150) DEFAULT NULL,
  `DESCRIPCION_REVISION` varchar(150) DEFAULT NULL,
  `TIPO_BOLSA` varchar(150) DEFAULT NULL,
  `TIPO_ACTUACION` varchar(150) DEFAULT NULL,
  `COD_ESTACION` varchar(150) DEFAULT NULL,
  `DES_ESTACION` varchar(150) DEFAULT NULL,
  `BOLSA_ORIGEN` varchar(150) DEFAULT NULL,
  `DES_PTO_ORIGEN` varchar(150) DEFAULT NULL,
  `CM_FLUJO` varchar(150) DEFAULT NULL,
  `COD_CONTRATA` varchar(150) DEFAULT NULL,
  `DES_CONTRATA` varchar(150) DEFAULT NULL,
  `MOT_ACT` varchar(150) DEFAULT NULL,
  `DESCRIPCION` varchar(150) DEFAULT NULL,
  `FECHA_PROG_CMS` varchar(150) DEFAULT NULL,
  `IND_CUMPLIMIENTO_ESTACION` varchar(150) DEFAULT NULL,
  `IND_INCIDENCIA_SIST` varchar(150) DEFAULT NULL,
  `DES_PROBLEMA` varchar(150) DEFAULT NULL,
  `AGRUP_PTO` varchar(150) DEFAULT NULL,
  `APE_MAT_FACT` varchar(150) DEFAULT NULL,
  `BOLSA_CASUISTICA` varchar(150) DEFAULT NULL,
  `REQ_FE_SITPED` varchar(150) DEFAULT NULL,
  `EQUIPO_SIS` varchar(150) DEFAULT NULL,
  `DES_INCIDENCIA` varchar(150) DEFAULT NULL,
  `MULTI_CASUISTICA` varchar(150) DEFAULT NULL,
  `DIAS_BOLSA_N` varchar(150) DEFAULT NULL,
  `TIPO_TUP` varchar(150) DEFAULT NULL,
  `TIPO_SPEEDY` varchar(150) DEFAULT NULL,
  `TIPO_ESTANCO` varchar(150) DEFAULT NULL,
  `COC_CMS_COD_MOTIVO` varchar(150) DEFAULT NULL,
  `INDICADOR_RECLAMO` varchar(150) DEFAULT NULL,
  `DES_RECLAMO` varchar(150) DEFAULT NULL,
  `TRASLADOS_MP` varchar(150) DEFAULT NULL,
  `COD_CLIENTE_ASOCIADO` varchar(150) DEFAULT NULL,
  `CODIGO_CONTACTO_TR` varchar(150) DEFAULT NULL,
  `FECHA_ALTA_CONTACTO_TR` varchar(150) DEFAULT NULL,
  `IND_CROSS` varchar(150) DEFAULT NULL,
  `COC_CMS_COD_TIPO_REQ` varchar(150) DEFAULT NULL,
  `CODIGO_REMEDY` varchar(150) DEFAULT NULL,
  `TIPO_INCIDENCIA` varchar(150) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `req_pend_macro`
--

DROP TABLE IF EXISTS `req_pend_macro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `req_pend_macro` (
  `codofcadm` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `codreq` int(11) DEFAULT NULL,
  `codedo` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `indvip` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `indcorp` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `codcli` int(11) DEFAULT NULL,
  `nomcli` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `tipcli` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `codsrv` int(11) DEFAULT NULL,
  `codclasrv` int(11) DEFAULT NULL,
  `desclasrv` varchar(60) CHARACTER SET utf8 DEFAULT NULL,
  `codcnd` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `descnd` varchar(60) CHARACTER SET utf8 DEFAULT NULL,
  `nombre_de_la_playa` varchar(60) CHARACTER SET utf8 DEFAULT NULL,
  `alt_km` varchar(4) CHARACTER SET utf8 DEFAULT NULL,
  `codctgsrv` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `desctgsrv` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `codjef` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `codctr` int(11) DEFAULT NULL,
  `desnomctr` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
  `codcmts` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
  `descmts` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `codnod` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `nroplano` varchar(4) CHARACTER SET utf8 DEFAULT NULL,
  `codtrtrn` varchar(4) CHARACTER SET utf8 DEFAULT NULL,
  `codlex` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `codtap` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `codbor` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `desdtt` varchar(60) CHARACTER SET utf8 DEFAULT NULL,
  `destipvia` varchar(4) CHARACTER SET utf8 DEFAULT NULL,
  `desnomvia` varchar(60) CHARACTER SET utf8 DEFAULT NULL,
  `numvia` int(11) DEFAULT NULL,
  `despis` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
  `desint` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
  `desmzn` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
  `deslot` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
  `destipurb` varchar(4) CHARACTER SET utf8 DEFAULT NULL,
  `desurb` varchar(60) CHARACTER SET utf8 DEFAULT NULL,
  `telefono_1` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `telefono_2` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `fecregsrv` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `fec_regist` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `fec_est_sop` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `fec_prog` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `fec_desp` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `nrotranf` int(11) DEFAULT NULL,
  `codmotv` varchar(4) CHARACTER SET utf8 DEFAULT NULL,
  `desmotv` varchar(60) CHARACTER SET utf8 DEFAULT NULL,
  `tipreqini` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `destipreqini` varchar(60) CHARACTER SET utf8 DEFAULT NULL,
  `tipreqfin` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `destipreqfin` varchar(60) CHARACTER SET utf8 DEFAULT NULL,
  `desobsordtrab` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `demora_atcl` decimal(10,2) DEFAULT NULL,
  `demora_act_tot` decimal(10,2) DEFAULT NULL,
  `demora_act_est` decimal(10,2) DEFAULT NULL,
  `fechorpro` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `filtro` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
  `descripcion_filtro` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `area` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `indactuacion` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `indagenda` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `idcita` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `fecinicita` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `fecfincita` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `feccumplimiento` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `codedocita` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `codedogaudi` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `codedoact` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `fecenviogaudi` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `fecrecepgaudi` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `coderror` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `deserrorenvio` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `fecactedogaudi` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `fechorliq` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `fechorinf` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `fecinfcierre` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `fecfincierre` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `coderror2` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `deserrorcierre` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `fecliberror` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `codusrliberror` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `codtipoact` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `ind_autorizacion` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `usu_int_autoriza` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `nombre_usuario` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `fec_int_autoriza` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `observacion` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `tec_int_autoriz` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `nombre_tecnico` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `cod_autorizacion` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `ind_conformidad` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `motivo` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `descrip_motivo` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `contacto_cliente` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  `nombre_contacto` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `parentesco` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `doc_entidad` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `tel_cont_cct` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `tel_cont_ref_cct` varchar(1) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Sin Uso',
  `tel_cont_cc` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `tel_cont_ref_cc` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `ind_encuesta` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `contacto_enc` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  `parentesco_enc` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  `telf_enc` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  `incidencia` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  `ticket_incidencia` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  `segincidencia` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  `tipo_servicio` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `tipo_deco_ins` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `paquete` varchar(60) CHARACTER SET utf8 DEFAULT NULL,
  `numaverei` int(11) DEFAULT NULL,
  `numavedif` int(11) DEFAULT NULL,
  `indmaxad` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `numdialim` int(11) DEFAULT NULL,
  `destipprb` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `desobsprb` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `ind_duo` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
  `tiplinea` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `numtelefvoip` int(11) DEFAULT NULL,
  `codpromo` varchar(4) CHARACTER SET utf8 DEFAULT NULL,
  `despromo` varchar(60) CHARACTER SET utf8 DEFAULT NULL,
  `nodoid` int(11) DEFAULT NULL,
  `tiptecnologia` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
  `fecha_insert` datetime DEFAULT NULL,
  `fec_registro` varchar(20) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `req_pend_macro_final`
--

DROP TABLE IF EXISTS `req_pend_macro_final`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `req_pend_macro_final` (
  `codofcadm` varchar(3) DEFAULT NULL,
  `codreq` int(11) DEFAULT NULL,
  `codedo` varchar(2) DEFAULT NULL,
  `indvip` varchar(2) DEFAULT NULL,
  `indcorp` varchar(2) DEFAULT NULL,
  `codcli` int(11) DEFAULT NULL,
  `nomcli` varchar(100) DEFAULT NULL,
  `tipcli` varchar(25) DEFAULT NULL,
  `codsrv` int(11) DEFAULT NULL,
  `codclasrv` int(11) DEFAULT NULL,
  `desclasrv` varchar(60) DEFAULT NULL,
  `codcnd` varchar(3) DEFAULT NULL,
  `descnd` varchar(60) DEFAULT NULL,
  `nombre_de_la_playa` varchar(60) DEFAULT NULL,
  `alt_km` varchar(4) DEFAULT NULL,
  `codctgsrv` varchar(2) DEFAULT NULL,
  `desctgsrv` varchar(30) DEFAULT NULL,
  `codjef` varchar(3) DEFAULT NULL,
  `codctr` int(11) DEFAULT NULL,
  `desnomctr` varchar(40) DEFAULT NULL,
  `codcmts` varchar(5) DEFAULT NULL,
  `descmts` varchar(20) DEFAULT NULL,
  `codnod` varchar(2) DEFAULT NULL,
  `nroplano` varchar(4) DEFAULT NULL,
  `codtrtrn` varchar(4) DEFAULT NULL,
  `codlex` varchar(2) DEFAULT NULL,
  `codtap` varchar(2) DEFAULT NULL,
  `codbor` varchar(2) DEFAULT NULL,
  `desdtt` varchar(60) DEFAULT NULL,
  `destipvia` varchar(4) DEFAULT NULL,
  `desnomvia` varchar(60) DEFAULT NULL,
  `numvia` int(11) DEFAULT NULL,
  `despis` varchar(5) DEFAULT NULL,
  `desint` varchar(5) DEFAULT NULL,
  `desmzn` varchar(5) DEFAULT NULL,
  `deslot` varchar(5) DEFAULT NULL,
  `destipurb` varchar(4) DEFAULT NULL,
  `desurb` varchar(60) DEFAULT NULL,
  `telefono_1` varchar(20) DEFAULT NULL,
  `telefono_2` varchar(20) DEFAULT NULL,
  `fecregsrv` varchar(25) DEFAULT NULL,
  `fec_regist` varchar(25) DEFAULT NULL,
  `fec_est_sop` varchar(25) DEFAULT NULL,
  `fec_prog` varchar(25) DEFAULT NULL,
  `fec_desp` varchar(25) DEFAULT NULL,
  `nrotranf` int(11) DEFAULT NULL,
  `codmotv` varchar(4) DEFAULT NULL,
  `desmotv` varchar(60) DEFAULT NULL,
  `tipreqini` varchar(2) DEFAULT NULL,
  `destipreqini` varchar(60) DEFAULT NULL,
  `tipreqfin` varchar(2) DEFAULT NULL,
  `destipreqfin` varchar(60) DEFAULT NULL,
  `desobsordtrab` varchar(200) DEFAULT NULL,
  `demora_atcl` decimal(10,2) DEFAULT NULL,
  `demora_act_tot` decimal(10,2) DEFAULT NULL,
  `demora_act_est` decimal(10,2) DEFAULT NULL,
  `fechorpro` varchar(25) DEFAULT NULL,
  `filtro` varchar(5) DEFAULT NULL,
  `descripcion_filtro` varchar(30) DEFAULT NULL,
  `area` varchar(20) DEFAULT NULL,
  `indactuacion` varchar(2) DEFAULT NULL,
  `indagenda` varchar(2) DEFAULT NULL,
  `idcita` varchar(10) DEFAULT NULL,
  `fecinicita` varchar(25) DEFAULT NULL,
  `fecfincita` varchar(25) DEFAULT NULL,
  `feccumplimiento` varchar(25) DEFAULT NULL,
  `codedocita` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `codedogaudi` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `codedoact` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `fecenviogaudi` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `fecrecepgaudi` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `coderror` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `deserrorenvio` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `fecactedogaudi` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `fechorliq` varchar(25) DEFAULT NULL,
  `fechorinf` varchar(25) DEFAULT NULL,
  `fecinfcierre` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `fecfincierre` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `coderror2` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `deserrorcierre` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `fecliberror` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `codusrliberror` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `codtipoact` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `ind_autorizacion` varchar(2) DEFAULT NULL,
  `usu_int_autoriza` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `nombre_usuario` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `fec_int_autoriza` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `observacion` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `tec_int_autoriz` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `nombre_tecnico` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `cod_autorizacion` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `ind_conformidad` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `motivo` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `descrip_motivo` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `contacto_cliente` varchar(1) DEFAULT NULL,
  `nombre_contacto` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `parentesco` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `doc_entidad` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `tel_cont_cct` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `tel_cont_ref_cct` varchar(1) DEFAULT NULL COMMENT 'Sin Uso',
  `tel_cont_cc` varchar(20) DEFAULT NULL,
  `tel_cont_ref_cc` varchar(20) DEFAULT NULL,
  `ind_encuesta` varchar(2) DEFAULT NULL,
  `contacto_enc` varchar(1) DEFAULT NULL,
  `parentesco_enc` varchar(1) DEFAULT NULL,
  `telf_enc` varchar(1) DEFAULT NULL,
  `incidencia` varchar(1) DEFAULT NULL,
  `ticket_incidencia` varchar(1) DEFAULT NULL,
  `segincidencia` varchar(1) DEFAULT NULL,
  `tipo_servicio` varchar(15) DEFAULT NULL,
  `tipo_deco_ins` varchar(15) DEFAULT NULL,
  `paquete` varchar(60) DEFAULT NULL,
  `numaverei` int(11) DEFAULT NULL,
  `numavedif` int(11) DEFAULT NULL,
  `indmaxad` varchar(2) DEFAULT NULL,
  `numdialim` int(11) DEFAULT NULL,
  `destipprb` varchar(30) DEFAULT NULL,
  `desobsprb` varchar(30) DEFAULT NULL,
  `ind_duo` varchar(5) DEFAULT NULL,
  `tiplinea` varchar(10) DEFAULT NULL,
  `numtelefvoip` int(11) DEFAULT NULL,
  `codpromo` varchar(4) DEFAULT NULL,
  `despromo` varchar(60) DEFAULT NULL,
  `nodoid` int(11) DEFAULT NULL,
  `tiptecnologia` varchar(5) DEFAULT NULL,
  `fecha_insert` datetime DEFAULT NULL,
  `fec_registro` varchar(20) DEFAULT NULL,
  UNIQUE KEY `Idx_requerimiento` (`codreq`),
  KEY `idx_codcli_codsrv` (`codcli`,`codsrv`),
  KEY `codcli` (`codcli`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resumen_macaddress`
--

DROP TABLE IF EXISTS `resumen_macaddress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resumen_macaddress` (
  `macaddress1` varchar(30) CHARACTER SET utf8 DEFAULT '',
  `macaddress` varchar(30) DEFAULT NULL,
  `codcli` varchar(20) DEFAULT NULL,
  `servicio` varchar(20) DEFAULT NULL,
  `nodo_troba` varchar(50) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  KEY `NewIndex1` (`macaddress`),
  KEY `NewIndex2` (`codcli`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resumen_macaddress2`
--

DROP TABLE IF EXISTS `resumen_macaddress2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resumen_macaddress2` (
  `cliente` int(10) DEFAULT NULL,
  `servicio` int(10) DEFAULT NULL,
  `nombre` varchar(75) DEFAULT NULL,
  `DIREC_INST` varchar(90) DEFAULT NULL,
  `nodo_plano` varchar(9) DEFAULT NULL,
  `macaddress` varchar(20) DEFAULT NULL,
  KEY `NewIndex1` (`cliente`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resumen_macaddress3`
--

DROP TABLE IF EXISTS `resumen_macaddress3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resumen_macaddress3` (
  `cliente` int(10) DEFAULT NULL,
  `servicio` int(10) DEFAULT NULL,
  `nombre` varchar(75) DEFAULT NULL,
  `DIREC_INST` varchar(90) DEFAULT NULL,
  `nodo_plano` varchar(9) DEFAULT NULL,
  `macaddress` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resumen_planta`
--

DROP TABLE IF EXISTS `resumen_planta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resumen_planta` (
  `cliente` int(10) DEFAULT NULL,
  `servicio` text CHARACTER SET utf8,
  KEY `NewIndex1` (`cliente`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resumen_planta_direccion`
--

DROP TABLE IF EXISTS `resumen_planta_direccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resumen_planta_direccion` (
  `cliente` int(10) DEFAULT NULL,
  `direccion` text,
  KEY `NewIndex1` (`cliente`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resumen_planta_fftt`
--

DROP TABLE IF EXISTS `resumen_planta_fftt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resumen_planta_fftt` (
  `cliente` int(10) DEFAULT NULL,
  `fftt` text,
  KEY `NewIndex1` (`cliente`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resumen_planta_nombre`
--

DROP TABLE IF EXISTS `resumen_planta_nombre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resumen_planta_nombre` (
  `cliente` int(10) DEFAULT NULL,
  `nombre` text,
  KEY `NewIndex1` (`cliente`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `supervisor`
--

DROP TABLE IF EXISTS `supervisor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supervisor` (
  `supervisor` varchar(150) DEFAULT NULL,
  `supervisor1` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tempcli`
--

DROP TABLE IF EXISTS `tempcli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tempcli` (
  `codcli` int(11) DEFAULT NULL,
  KEY `NewIndex1` (`codcli`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tempcli_c`
--

DROP TABLE IF EXISTS `tempcli_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tempcli_c` (
  `codcli` int(11) DEFAULT NULL,
  KEY `NewIndex1` (`codcli`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `temporal_cambio`
--

DROP TABLE IF EXISTS `temporal_cambio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `temporal_cambio` (
  `codreq` int(11) NOT NULL,
  `contrata` int(11) DEFAULT NULL,
  `fecha` varchar(20) DEFAULT NULL,
  `hora` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`codreq`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tipreq_codmotv`
--

DROP TABLE IF EXISTS `tipreq_codmotv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipreq_codmotv` (
  `gruporeq` varchar(2) DEFAULT NULL,
  `descgruporeq` varchar(200) DEFAULT NULL,
  `tiporeq` varchar(2) DEFAULT NULL,
  `desctiporeq` varchar(200) DEFAULT NULL,
  `motivo` varchar(4) NOT NULL,
  `descmotivo` varchar(200) DEFAULT NULL,
  `estadogtm` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`motivo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trabajos_programados`
--

DROP TABLE IF EXISTS `trabajos_programados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trabajos_programados` (
  `ITEM` int(11) NOT NULL AUTO_INCREMENT,
  `NODO` varchar(2) DEFAULT NULL,
  `TROBA` varchar(4) DEFAULT NULL,
  `AMP` varchar(80) DEFAULT NULL,
  `TIPODETRABAJO` varchar(200) DEFAULT NULL,
  `SUPERVISOR` varchar(150) DEFAULT NULL,
  `FINICIO` varchar(20) DEFAULT NULL,
  `HINICIO` varchar(10) DEFAULT NULL,
  `HTERMINO` varchar(10) DEFAULT NULL,
  `HORARIO` varchar(10) DEFAULT NULL,
  `CORTESN` varchar(10) DEFAULT NULL,
  `OPERADOR` varchar(100) DEFAULT NULL,
  `FECHA` varchar(20) DEFAULT NULL,
  `HORA` varchar(10) DEFAULT NULL,
  `TRABAJO` varchar(100) DEFAULT NULL,
  `REMEDY` varchar(10) DEFAULT NULL,
  `TECNICO` varchar(100) DEFAULT NULL,
  `RPM` varchar(10) DEFAULT NULL,
  `CONTRATA` varchar(50) DEFAULT NULL,
  `HORACIERRE` varchar(10) DEFAULT NULL,
  `OBSERVACIONES` varchar(500) DEFAULT NULL,
  `ESTADO` varchar(10) DEFAULT NULL,
  `fecha_registro` varchar(20) DEFAULT NULL,
  `fecha_apertura` varchar(20) DEFAULT NULL,
  `fecha_cierre` varchar(20) DEFAULT NULL,
  `fecha_cancela` varchar(20) DEFAULT NULL,
  `usuario` varchar(20) DEFAULT NULL,
  `usuario_apertura` varchar(20) DEFAULT NULL,
  `usuario_cierre` varchar(20) DEFAULT NULL,
  `usuario_cancela` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ITEM`),
  KEY `NewIndex1` (`NODO`),
  KEY `NewIndex2` (`TROBA`),
  KEY `NewIndex3` (`FINICIO`),
  KEY `ESTADO` (`ESTADO`)
) ENGINE=MyISAM AUTO_INCREMENT=43752 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trabajos_programados_c`
--

DROP TABLE IF EXISTS `trabajos_programados_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trabajos_programados_c` (
  `ITEM` int(11) NOT NULL AUTO_INCREMENT,
  `NODO` varchar(2) NOT NULL,
  `TROBA` varchar(4) NOT NULL,
  `AMP` varchar(80) DEFAULT NULL,
  `TIPODETRABAJO` varchar(200) NOT NULL,
  `SUPERVISOR` varchar(150) DEFAULT NULL,
  `FINICIO` varchar(20) NOT NULL,
  `HINICIO` varchar(10) NOT NULL,
  `HTERMINO` varchar(10) NOT NULL,
  `HORARIO` varchar(10) NOT NULL,
  `CORTESN` varchar(10) DEFAULT NULL,
  `OPERADOR` varchar(100) DEFAULT NULL,
  `FECHA` varchar(20) DEFAULT NULL,
  `HORA` varchar(10) DEFAULT NULL,
  `TRABAJO` varchar(100) DEFAULT NULL,
  `REMEDY` varchar(10) DEFAULT NULL,
  `TECNICO` varchar(100) DEFAULT NULL,
  `RPM` varchar(10) DEFAULT NULL,
  `CONTRATA` varchar(50) DEFAULT NULL,
  `HORACIERRE` varchar(10) DEFAULT NULL,
  `OBSERVACIONES` varchar(500) DEFAULT NULL,
  `ESTADO` varchar(10) DEFAULT NULL,
  `fecha_registro` varchar(20) DEFAULT NULL,
  `fecha_apertura` varchar(20) DEFAULT NULL,
  `fecha_cierre` varchar(20) DEFAULT NULL,
  `fecha_cancela` varchar(20) DEFAULT NULL,
  `usuario` varchar(20) DEFAULT NULL,
  `usuario_apertura` varchar(20) DEFAULT NULL,
  `usuario_cierre` varchar(20) DEFAULT NULL,
  `usuario_cancela` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ITEM`,`NODO`,`TROBA`,`TIPODETRABAJO`,`FINICIO`,`HINICIO`,`HTERMINO`,`HORARIO`),
  KEY `NewIndex1` (`NODO`),
  KEY `NewIndex2` (`TROBA`),
  KEY `NewIndex3` (`FINICIO`),
  KEY `ESTADO` (`ESTADO`)
) ENGINE=InnoDB AUTO_INCREMENT=43752 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'cms'
--
/*!50003 DROP PROCEDURE IF EXISTS `sp_envio_cot` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_envio_cot`()
BEGIN
SELECT 'AUT MULTICONSULTA' AS QUIEBRE,CONCAT(nc.CODMOTV,' ',nc.DESMOTV) AS ATENCION,'CMS' AS FUENTE,'' AS CODACTU,nc.CODCLI,'' AS TIPOAVERIA,nc.NOMCLI AS CLIENTENOMBRE
,IF((IF(tcms.Telefono IS NOT NULL,tcms.Telefono, 
IF(tcms.telfono2 IS NOT NULL,tcms.telfono2,
IF(tcms.telfono3 IS NOT NULL,tcms.telfono3,
IF(tcms.telfono4 IS NOT NULL,tcms.telfono4,'')))))<>'',
IF(tcms.Telefono IS NOT NULL,tcms.Telefono, 
IF(tcms.telfono2 IS NOT NULL,tcms.telfono2,
IF(tcms.telfono3 IS NOT NULL,tcms.telfono3,
IF(tcms.telfono4 IS NOT NULL,tcms.telfono4,'')))),
IF(ta.movil1 IS NOT NULL,ta.movil1, 
IF(ta.movil2 IS NOT NULL,ta.movil2,
IF(ta.movil3 IS NOT NULL,ta.movil3,
IF(ta.movil4 IS NOT NULL,ta.movil4,
IF(ta.movil5 IS NOT NULL,ta.movil5,'')))))) AS CLIENTECELULAR,
REPLACE(REPLACE(tel_cont_cc,'1-',''),'-','') AS CLIENTETELEFONO,
'' AS CLIENTECORREO,
pc.NUMERODOC AS CLIENTEDNI,
'' AS CONTACTONOMBRE, '' AS CONTACTOCELULAR, '' AS CONTACTOTELEFONO, '' AS CONTACTOCORREO, '' AS CONTACTODNI, '' AS EMBAJADORNOMBRE, '' AS EMBAJADORCORREO, '' AS EMBAJADORCELULAR, '' AS EMBAJADORDNI,
nc.`DESOBSORDTRAB` AS COMENTARIO,
FEC_REGISTRO AS FH_REG104,FEC_REGISTRO AS FH_REG1L,NOW() AS FH_REG2L,'' AS CODMULTIGESTION,'' AS LLAMADOR,'' AS TITULAR,'' AS Direccion,'' AS Distrito,'' AS Urbanizacion,REPLACE(REPLACE(tel_cont_cc,'1-',''),'-','') AS TELF_GESTION
,REPLACE(REPLACE(tel_cont_cc,'1-',''),'-','') AS TELF_ENTRANTE,'' AS MOTIVO_CALL
FROM cms.req_pend_macro nc
LEFT JOIN catalogos.telefonos_atis ta ON nc.codcli=ta.CABLE_CLIENTE_CMS
LEFT JOIN catalogos.telefonos_cms tcms ON nc.codcli=tcms.Cliente
LEFT JOIN cms.`planta_clarita` pc ON nc.codcli = pc.`CLIENTE`
WHERE nc.CODMOTV='R414';
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-23 13:35:24
