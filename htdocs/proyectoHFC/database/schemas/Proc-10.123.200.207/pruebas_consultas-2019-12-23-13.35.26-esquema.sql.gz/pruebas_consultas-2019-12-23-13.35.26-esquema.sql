-- MySQL dump 10.15  Distrib 10.0.34-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: pruebas_consultas
-- ------------------------------------------------------
-- Server version	10.0.34-MariaDB-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `nivelesxmac_prueba`
--

DROP TABLE IF EXISTS `nivelesxmac_prueba`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nivelesxmac_prueba` (
  `macaddress` varchar(20) DEFAULT NULL,
  `RxPwrdBmv` int(11) DEFAULT NULL,
  `SNR_DN` int(11) DEFAULT NULL,
  `PWR_DN` int(11) DEFAULT NULL,
  `SNR_UP` int(11) DEFAULT NULL,
  `PWR_UP` int(11) DEFAULT NULL,
  UNIQUE KEY `macaddress` (`macaddress`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resumen_nivelesxtroba_c_prueba`
--

DROP TABLE IF EXISTS `resumen_nivelesxtroba_c_prueba`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resumen_nivelesxtroba_c_prueba` (
  `nodo` varchar(10) DEFAULT NULL,
  `troba` varchar(10) DEFAULT NULL,
  `RxPwrdBmv` varchar(20) DEFAULT NULL,
  `SNR_DN` varchar(20) DEFAULT NULL,
  `PWR_DN` varchar(20) DEFAULT NULL,
  `SNR_UP` varchar(20) DEFAULT NULL,
  `PWR_UP` varchar(20) DEFAULT NULL,
  `cant` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(30) DEFAULT NULL,
  `fecha_fin` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `tiempo` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `caida` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  UNIQUE KEY `nodo_2` (`nodo`,`troba`,`fecha_hora`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fecha_hora` (`fecha_hora`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'pruebas_consultas'
--
/*!50003 DROP PROCEDURE IF EXISTS `SP_Consulta` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`ccm1_user`@`%` PROCEDURE `SP_Consulta`()
BEGIN
    TRUNCATE TABLE prueba_consultas.`nivelesxmac_prueba`;
    TRUNCATE prueba_consultas.`resumen_nivelesxtroba_c_prueba`;
    SET @i=1;
    REPEAT 
INSERT IGNORE prueba_consultas.`nivelesxmac_prueba`
SELECT b.macaddress,
ROUND(AVG(IF(RIGHT(c.RxPwrdBmv,4)='0.00' OR LEFT(c.RxPwrdBmv,1) IN ('!','*'),RIGHT(c.RxPwrdBmv,4),c.RxPwrdBmv)),2) AS RxPwrdBmv ,
ROUND(AVG(b.DSMER_SNR),2) AS  SNR_DN,
ROUND(AVG(b.DSPwr),2) AS PWR_DN,
ROUND(AVG(b.USMER_SNR),2) AS SNR_UP,
ROUND(AVG(b.USPwr),2) AS PWR_UP
FROM  ccm1_temporal.scm_phy_f b 
INNER JOIN ccm1_temporal.scm_total_f c ON b.macaddress=c.macaddress
INNER JOIN ccm1.`cmts_ip` d ON b.cmts=d.cmts
WHERE b.DSMER_SNR NOT IN ("-----","-") AND b.usmer_snr NOT IN ('-','-----') AND d.id=@i
GROUP BY b.macaddress;
INSERT IGNORE prueba_consultas.`resumen_nivelesxtroba_c_prueba`
SELECT a.nodo,a.troba,xx.RxPwrdBmv,xx.SNR_DN,xx.PWR_DN,xx.SNR_UP,xx.PWR_UP,COUNT(*) AS cant,NOW() AS fecha_hora," " AS fecha_fin," " AS tiempo,"SI" AS caida
FROM temporal.nclientes_c a 
INNER JOIN alertasx.nivelesxmac xx ON a.mac2=xx.macaddress
INNER JOIN ccm1.cmts_ip b ON a.cmts=b.cmts
WHERE a.nodo IS NOT NULL AND a.nodo<>"" AND b.id=@i
GROUP BY a.nodo,a.troba;
SET @i=@i+1;
UNTIL @i<=6
END REPEAT;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-23 13:35:26
