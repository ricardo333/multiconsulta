-- MySQL dump 10.15  Distrib 10.0.34-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: ccm1_temporal
-- ------------------------------------------------------
-- Server version	10.0.34-MariaDB-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access_temp`
--

DROP TABLE IF EXISTS `access_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access_temp` (
  `parte1` varchar(31) DEFAULT NULL,
  `tamanio` varchar(6) DEFAULT NULL,
  `fecha` varchar(13) DEFAULT NULL,
  `carpeta` varchar(9) DEFAULT NULL,
  `archivo` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `access_tempx`
--

DROP TABLE IF EXISTS `access_tempx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access_tempx` (
  `archivo` varchar(40) DEFAULT NULL,
  `tamanio` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alarmas_caidas`
--

DROP TABLE IF EXISTS `alarmas_caidas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alarmas_caidas` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `aver` bigint(21) DEFAULT '0',
  `llamadas` bigint(21) DEFAULT '0',
  `cant` int(21) DEFAULT NULL,
  `umbral` int(12) DEFAULT NULL,
  `off` int(21) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `tiempo` time DEFAULT NULL,
  `fecha_fin` varchar(20) DEFAULT NULL,
  `codmasiva` int(16) DEFAULT NULL,
  UNIQUE KEY `NewIndex1` (`nodo`,`troba`),
  KEY `NewIndex2` (`nodo`),
  KEY `NewIndex3` (`troba`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alarmas_caidas_historico`
--

DROP TABLE IF EXISTS `alarmas_caidas_historico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alarmas_caidas_historico` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `aver` bigint(21) DEFAULT '0',
  `llamadas` bigint(21) DEFAULT '0',
  `cant` int(21) DEFAULT NULL,
  `umbral` int(12) DEFAULT NULL,
  `off` int(21) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `tiempo` time DEFAULT NULL,
  `fecha_fin` varchar(20) DEFAULT NULL,
  `codmasiva` int(11) DEFAULT NULL,
  UNIQUE KEY `NewIndex1` (`nodo`,`troba`,`fecha_hora`,`fecha_fin`),
  KEY `idxnodo` (`nodo`),
  KEY `idxtroba` (`troba`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alarmas_ims`
--

DROP TABLE IF EXISTS `alarmas_ims`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alarmas_ims` (
  `macaddress` varchar(12) DEFAULT NULL,
  `fecha_alarma` varchar(20) DEFAULT NULL,
  `fechaupload` varchar(20) DEFAULT NULL,
  `maccmts` varchar(20) DEFAULT NULL,
  KEY `NewIndex1` (`macaddress`),
  KEY `NewIndex2` (`maccmts`),
  KEY `NewIndex3` (`fecha_alarma`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alertas_signal_historico`
--

DROP TABLE IF EXISTS `alertas_signal_historico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alertas_signal_historico` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `aver` bigint(21) DEFAULT '0',
  `llamadas` bigint(21) DEFAULT '0',
  `codmasiva` int(11) DEFAULT NULL,
  `cant` int(21) DEFAULT NULL,
  `umbral` int(12) DEFAULT NULL,
  `off` int(21) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `tiempo` time DEFAULT NULL,
  `fecha_fin` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `RxPwrdBmv` double(19,2) DEFAULT NULL,
  `snr_up` double(19,2) DEFAULT NULL,
  `pwr_up` double(19,2) DEFAULT NULL,
  `snr_dn` double(19,2) DEFAULT NULL,
  `pwr_dn` double(19,2) DEFAULT NULL,
  `can` bigint(21) DEFAULT '0',
  UNIQUE KEY `NewIndex1` (`nodo`,`troba`,`fecha_hora`,`fecha_fin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `averias_catv_new_7`
--

DROP TABLE IF EXISTS `averias_catv_new_7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `averias_catv_new_7` (
  `codofcadm` varchar(3) DEFAULT NULL,
  `codreq` int(16) DEFAULT NULL,
  `codclasrv` int(16) DEFAULT NULL,
  `tipreqini` varchar(2) DEFAULT NULL,
  `destipreqini` varchar(100) DEFAULT NULL,
  `fec_mov` varchar(20) DEFAULT NULL,
  `estado` varchar(80) DEFAULT NULL,
  `codestado` int(20) DEFAULT NULL,
  `codcli` int(20) DEFAULT NULL,
  `codnod` varchar(10) DEFAULT NULL,
  `nroplano` varchar(10) DEFAULT NULL,
  `fecha_proc` varchar(20) DEFAULT NULL,
  `fecha_file` varchar(50) DEFAULT NULL,
  `id2` varchar(50) DEFAULT NULL,
  `id` int(20) DEFAULT NULL,
  `dia_mov` varchar(20) DEFAULT NULL,
  `hora_mov` int(20) DEFAULT NULL,
  `codmotv` varchar(50) DEFAULT NULL,
  `desmotv` varchar(50) DEFAULT NULL,
  `tipreqfin` varchar(50) DEFAULT NULL,
  `destipreqfin` varchar(50) DEFAULT NULL,
  `tipave` varchar(50) DEFAULT NULL,
  `des_cod_liq` varchar(50) DEFAULT NULL,
  `codprbave` varchar(50) DEFAULT NULL,
  `desc_cod_det` varchar(50) DEFAULT NULL,
  `codmotvot` varchar(50) DEFAULT NULL,
  `desmotv2` varchar(50) DEFAULT NULL,
  `codtecliq` varchar(50) DEFAULT NULL,
  `nomtec` varchar(50) DEFAULT NULL,
  `desobsordtrab` varchar(50) DEFAULT NULL,
  `desobsordtrab_2` varchar(50) DEFAULT NULL,
  `canttroba` int(11) DEFAULT NULL,
  `tipodeingreso` varchar(100) DEFAULT NULL,
  `tipodeliquidacion` varchar(100) DEFAULT NULL,
  `codctr` int(11) DEFAULT NULL,
  UNIQUE KEY `codreq` (`codreq`),
  KEY `tipreqini` (`tipreqini`),
  KEY `fec_mov` (`fec_mov`),
  KEY `estado` (`estado`),
  KEY `codcli` (`codcli`),
  KEY `estado_2` (`estado`),
  KEY `codnod` (`codnod`),
  KEY `nroplano` (`nroplano`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `averxtrob`
--

DROP TABLE IF EXISTS `averxtrob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `averxtrob` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `fec_mov` varchar(20) DEFAULT NULL,
  `aver` bigint(21) NOT NULL DEFAULT '0',
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `aver` (`fec_mov`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `cant_caidas`
--

DROP TABLE IF EXISTS `cant_caidas`;
/*!50001 DROP VIEW IF EXISTS `cant_caidas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `cant_caidas` (
  `nodo` tinyint NOT NULL,
  `troba` tinyint NOT NULL,
  `caidas` tinyint NOT NULL,
  `off` tinyint NOT NULL,
  `cantcli` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `casa_down_util`
--

DROP TABLE IF EXISTS `casa_down_util`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `casa_down_util` (
  `downstream` varchar(10) DEFAULT NULL,
  `frecuencia` varchar(20) DEFAULT NULL,
  `hz` varchar(4) DEFAULT NULL,
  `totalwb` int(11) DEFAULT NULL,
  `utilization` int(11) DEFAULT NULL,
  `modemsonline` int(11) DEFAULT NULL,
  `secondarymodems` int(11) DEFAULT NULL,
  `channeldesc` varchar(50) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  UNIQUE KEY `downstream` (`downstream`,`cmts`),
  KEY `downstream_2` (`downstream`),
  KEY `cmts` (`cmts`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `casa_down_util_c`
--

DROP TABLE IF EXISTS `casa_down_util_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `casa_down_util_c` (
  `downstream` varchar(6) DEFAULT NULL,
  `frecuencia` varchar(16) DEFAULT NULL,
  `hz` varchar(4) DEFAULT NULL,
  `totalwb` varchar(5) DEFAULT NULL,
  `utilization` varchar(4) DEFAULT NULL,
  `modemsonline` varchar(11) DEFAULT NULL,
  `secondarymodems` varchar(11) DEFAULT NULL,
  `channeldesc` varchar(50) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  UNIQUE KEY `downstream` (`downstream`,`cmts`,`frecuencia`),
  KEY `downstream_2` (`downstream`),
  KEY `cmts` (`cmts`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `casa_down_util_trab`
--

DROP TABLE IF EXISTS `casa_down_util_trab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `casa_down_util_trab` (
  `cmts` varchar(20) DEFAULT NULL,
  `down` varchar(4) DEFAULT NULL,
  `can` bigint(21) NOT NULL DEFAULT '0',
  `clientes` decimal(32,0) DEFAULT NULL,
  KEY `down` (`down`),
  KEY `cmts` (`cmts`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cmactivosdiario`
--

DROP TABLE IF EXISTS `cmactivosdiario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmactivosdiario` (
  `IDCABLEMODEM` int(11) DEFAULT NULL,
  `EMPRESA` varchar(3) DEFAULT NULL,
  `IDCLIENTECRM` double DEFAULT NULL,
  `IDEMPRESACRM` int(11) DEFAULT NULL,
  `IDSERVICIO` double DEFAULT NULL,
  `IDPRODUCTO` double DEFAULT NULL,
  `IDVENTA` double DEFAULT NULL,
  `PRODUCTNAME` varchar(100) DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `SERVICEPACKAGE` varchar(50) DEFAULT NULL,
  `SERVICEPACKAGECRMID` varchar(50) DEFAULT NULL,
  `CANTPCS` int(11) DEFAULT NULL,
  `FECHAALTA` varchar(20) DEFAULT NULL,
  `FECHAACTIVACION` varchar(20) DEFAULT NULL,
  `HUB` varchar(10) DEFAULT NULL,
  `NODO` varchar(10) DEFAULT NULL,
  `ESTADO` varchar(10) DEFAULT NULL,
  `MENSAJE` varchar(10) DEFAULT NULL,
  `SCOPESGROUP` varchar(20) DEFAULT NULL,
  `SCOPESGROUPCM` varchar(20) DEFAULT NULL,
  `SCOPESGROUPMTA` varchar(20) DEFAULT NULL,
  `MTAMAC` varchar(20) DEFAULT NULL,
  `IDSERVICIOMTA` varchar(15) DEFAULT NULL,
  `IDPRODUCTOMTA` varchar(15) DEFAULT NULL,
  `IDVENTAMTA` varchar(15) DEFAULT NULL,
  `PROFILENAME` varchar(15) DEFAULT NULL,
  `MTAMODELNAME` varchar(50) DEFAULT NULL,
  `mac2` varchar(20) DEFAULT NULL,
  `mac3` varchar(20) DEFAULT NULL,
  UNIQUE KEY `NewIndex1` (`MACADDRESS`),
  KEY `NewIndex2` (`IDCLIENTECRM`),
  KEY `NewIndex3` (`EMPRESA`),
  KEY `NewIndex4` (`mac2`),
  KEY `NewIndex5` (`mac3`),
  KEY `IDPRODUCTO` (`IDPRODUCTO`),
  KEY `IDEMPRESACRM` (`IDEMPRESACRM`),
  KEY `idventa` (`IDVENTA`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cmactivosdiario_tmp`
--

DROP TABLE IF EXISTS `cmactivosdiario_tmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmactivosdiario_tmp` (
  `EMPRESA` varchar(3) DEFAULT NULL,
  `IDCLIENTECRM` double DEFAULT NULL,
  `IDEMPRESACRM` int(11) DEFAULT NULL,
  `IDSERVICIO` double DEFAULT NULL,
  `IDPRODUCTO` double DEFAULT NULL,
  `IDVENTA` double DEFAULT NULL,
  `PRODUCTNAME` varchar(100) DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `SERVICEPACKAGE` varchar(50) DEFAULT NULL,
  `SERVICEPACKAGECRMID` varchar(50) DEFAULT NULL,
  `CANTPCS` int(11) DEFAULT NULL,
  `FECHAALTA` varchar(20) DEFAULT NULL,
  `FECHAACTIVACION` varchar(20) DEFAULT NULL,
  `HUB` varchar(10) DEFAULT NULL,
  `NODO` varchar(10) DEFAULT NULL,
  `ESTADO` varchar(10) DEFAULT NULL,
  `MENSAJE` varchar(10) DEFAULT NULL,
  `SCOPESGROUP` varchar(20) DEFAULT NULL,
  `SCOPESGROUPCM` varchar(20) DEFAULT NULL,
  `SCOPESGROUPMTA` varchar(20) DEFAULT NULL,
  `MTAMAC` varchar(20) DEFAULT NULL,
  `IDSERVICIOMTA` varchar(15) DEFAULT NULL,
  `IDPRODUCTOMTA` varchar(15) DEFAULT NULL,
  `IDVENTAMTA` varchar(15) DEFAULT NULL,
  `PROFILENAME` varchar(15) DEFAULT NULL,
  `MTAMODELNAME` varchar(50) DEFAULT NULL,
  `mac2` varchar(20) DEFAULT NULL,
  `mac3` varchar(20) DEFAULT NULL,
  UNIQUE KEY `NewIndex1` (`MACADDRESS`),
  KEY `NewIndex2` (`IDCLIENTECRM`),
  KEY `NewIndex3` (`EMPRESA`),
  KEY `NewIndex4` (`mac2`),
  KEY `NewIndex5` (`mac3`),
  KEY `IDPRODUCTO` (`IDPRODUCTO`),
  KEY `IDEMPRESACRM` (`IDEMPRESACRM`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 PAGE_CHECKSUM=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cmfuerarangodiario`
--

DROP TABLE IF EXISTS `cmfuerarangodiario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmfuerarangodiario` (
  `IDCLIENTECRM` double DEFAULT NULL,
  `CMTSID` int(11) DEFAULT NULL,
  `UBICACIONENLARED` varchar(150) DEFAULT NULL,
  `HUB` varchar(10) DEFAULT NULL,
  `NODO` varchar(10) DEFAULT NULL,
  `IPCM` varchar(20) DEFAULT NULL,
  `IDCABLEMODEM` int(25) DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `DOCSISVERSION` int(25) DEFAULT NULL,
  `CMTSCMSTATUS` varchar(25) DEFAULT NULL,
  `DSSNRSTATUS` varchar(25) DEFAULT NULL,
  `USSNRSTATUS` varchar(25) DEFAULT NULL,
  `CMRXPOWERSTATUS` varchar(25) DEFAULT NULL,
  `CMTXPOWERSTATUS` varchar(25) DEFAULT NULL,
  `DSSNR` varchar(25) DEFAULT NULL,
  `USSNR` varchar(25) DEFAULT NULL,
  `CMRXPOWER` varchar(25) DEFAULT NULL,
  `CMTSRXPOWER` varchar(25) DEFAULT NULL,
  `CMTXPOWER` varchar(25) DEFAULT NULL,
  `GOODCW` varchar(25) DEFAULT NULL,
  `CORRECTABLECW` varchar(25) DEFAULT NULL,
  `UNCORRECTABLECW` varchar(25) DEFAULT NULL,
  `UPTIME` varchar(25) DEFAULT NULL,
  `DEVICETYPE` varchar(5) DEFAULT NULL,
  UNIQUE KEY `NewIndex1` (`MACADDRESS`),
  KEY `NewIndex2` (`IDCLIENTECRM`),
  KEY `IDCABLEMODEM` (`IDCABLEMODEM`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cmts_casa_access`
--

DROP TABLE IF EXISTS `cmts_casa_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmts_casa_access` (
  `CPEIPAddress` varchar(20) DEFAULT NULL,
  `Method` varchar(5) DEFAULT NULL,
  `CPEMACAddress` varchar(20) DEFAULT NULL,
  `CMIPAddress` varchar(20) DEFAULT NULL,
  `CMMACAddress` varchar(20) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cmts_casa_down_util_sw`
--

DROP TABLE IF EXISTS `cmts_casa_down_util_sw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmts_casa_down_util_sw` (
  `sw` int(1) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cmts_casa_sum`
--

DROP TABLE IF EXISTS `cmts_casa_sum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmts_casa_sum` (
  `UpstreamInterfaceUSIF` varchar(10) DEFAULT NULL,
  `TotalModems` int(11) DEFAULT NULL,
  `ActiveModems` int(11) DEFAULT NULL,
  `RegisteredModems` int(11) DEFAULT NULL,
  `SecondaryModems` int(11) DEFAULT NULL,
  `OfflineModems` int(11) DEFAULT NULL,
  `ChannelDescripcion` varchar(80) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `consulta_cpe_casa`
--

DROP TABLE IF EXISTS `consulta_cpe_casa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_cpe_casa` (
  `CPEIPAddress` varchar(16) DEFAULT NULL,
  `Method` varchar(6) DEFAULT NULL,
  `CPEMACAddress` varchar(14) DEFAULT NULL,
  `CMIPAddress` varchar(16) DEFAULT NULL,
  `CMMACAddress` varchar(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `consulta_cpe_cisco`
--

DROP TABLE IF EXISTS `consulta_cpe_cisco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_cpe_cisco` (
  `IPAddress` varchar(16) DEFAULT NULL,
  `MACAddress` varchar(14) DEFAULT NULL,
  `DuaIP` varchar(1) DEFAULT NULL,
  `DeviceClass` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `consulta_phy_casa`
--

DROP TABLE IF EXISTS `consulta_phy_casa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_phy_casa` (
  `MACAddress` varchar(20) DEFAULT NULL,
  `USIF` varchar(10) DEFAULT NULL,
  `DSIF` varchar(10) DEFAULT NULL,
  `Sid` varchar(5) DEFAULT NULL,
  `PwrUP` varchar(6) DEFAULT NULL,
  `RxPwr` varchar(6) DEFAULT NULL,
  `USSNR` varchar(5) DEFAULT NULL,
  `TXTime_Offset` varchar(5) DEFAULT NULL,
  `MicroReflec` varchar(4) DEFAULT NULL,
  `DSPwr` varchar(6) DEFAULT NULL,
  `DSSNR` varchar(6) DEFAULT NULL,
  `Modex` varchar(6) DEFAULT NULL,
  KEY `Modex` (`Modex`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `consulta_phy_cisco`
--

DROP TABLE IF EXISTS `consulta_phy_cisco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_phy_cisco` (
  `MACAddress` varchar(20) DEFAULT NULL,
  `Interface` varchar(20) DEFAULT NULL,
  `Sid` varchar(20) DEFAULT NULL,
  `USPwr` varchar(20) DEFAULT NULL,
  `USMER_SNR` varchar(20) DEFAULT NULL,
  `Timing_Offset` varchar(20) DEFAULT NULL,
  `DSPwr` varchar(20) DEFAULT NULL,
  `DSMER_SNR` varchar(20) DEFAULT NULL,
  `Mode_` varchar(20) DEFAULT NULL,
  `DOCSIS_Prov` varchar(20) DEFAULT NULL,
  KEY `NewIndex1` (`MACAddress`),
  KEY `NewIndex2` (`Interface`),
  KEY `NewIndex3` (`Sid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `consulta_scm_casa`
--

DROP TABLE IF EXISTS `consulta_scm_casa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_scm_casa` (
  `MACAddress` varchar(20) DEFAULT NULL,
  `IPAddress` varchar(20) DEFAULT NULL,
  `USIF` varchar(10) DEFAULT NULL,
  `DSIF` varchar(10) DEFAULT NULL,
  `MACStatus` varchar(12) DEFAULT NULL,
  `PrimSid` varchar(5) DEFAULT NULL,
  `RxPwr` varchar(5) DEFAULT NULL,
  `Timing_Offset` varchar(5) DEFAULT NULL,
  `NumCpe` varchar(3) DEFAULT NULL,
  `BPI` varchar(5) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `consulta_scm_cisco`
--

DROP TABLE IF EXISTS `consulta_scm_cisco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_scm_cisco` (
  `MACAddress` varchar(20) DEFAULT NULL,
  `IPAddress` varchar(20) DEFAULT NULL,
  `Interface` varchar(20) DEFAULT NULL,
  `MACState` varchar(20) DEFAULT NULL,
  `PrimSid` varchar(20) DEFAULT NULL,
  `RxPwrdBmv` varchar(20) DEFAULT NULL,
  `TimingOFFSET` varchar(20) DEFAULT NULL,
  `NumCPE` varchar(20) DEFAULT NULL,
  `DIP` varchar(20) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `FECHA_HORA` varchar(20) DEFAULT NULL,
  `ultimo` varchar(40) DEFAULT NULL,
  `interface6` varchar(10) DEFAULT NULL,
  KEY `macaddress` (`MACAddress`),
  KEY `interface` (`Interface`),
  KEY `fecha_hora` (`FECHA_HORA`),
  KEY `cmts` (`cmts`),
  KEY `macstate` (`MACState`),
  KEY `ultimo` (`ultimo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `consulta_verbose`
--

DROP TABLE IF EXISTS `consulta_verbose`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_verbose` (
  `item` varchar(50) DEFAULT NULL,
  `detalle` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `consultasr`
--

DROP TABLE IF EXISTS `consultasr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consultasr` (
  `nodo` varchar(4) DEFAULT NULL,
  `troban` varchar(5) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  `cant` decimal(42,0) DEFAULT NULL,
  KEY `nodo` (`nodo`),
  KEY `troba` (`troban`),
  KEY `fecha` (`fechahora`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `consultasr_amplif`
--

DROP TABLE IF EXISTS `consultasr_amplif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consultasr_amplif` (
  `nodo` varchar(2) DEFAULT NULL,
  `troban` varchar(4) DEFAULT NULL,
  `amplificador` varchar(11) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  `cant` decimal(42,0) DEFAULT NULL,
  KEY `nodo` (`nodo`),
  KEY `troba` (`troban`),
  KEY `amplif` (`amplificador`),
  KEY `fechahora` (`fechahora`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `consultasr_catv`
--

DROP TABLE IF EXISTS `consultasr_catv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consultasr_catv` (
  `nodo` varchar(4) DEFAULT NULL,
  `troba` varchar(5) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  `cant` decimal(42,0) DEFAULT NULL,
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fecha` (`fechahora`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `consultasr_catv_c`
--

DROP TABLE IF EXISTS `consultasr_catv_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consultasr_catv_c` (
  `nodo` varchar(4) DEFAULT NULL,
  `troba` varchar(5) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  `cant` decimal(42,0) DEFAULT NULL,
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fecha` (`fechahora`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `consultasr_d_c`
--

DROP TABLE IF EXISTS `consultasr_d_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consultasr_d_c` (
  `dato` int(11) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  `cant` bigint(21) NOT NULL DEFAULT '0',
  KEY `dato` (`dato`),
  KEY `fechahora` (`fechahora`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `consultasr_n`
--

DROP TABLE IF EXISTS `consultasr_n`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consultasr_n` (
  `nodo` varchar(2) DEFAULT NULL,
  `troban` varchar(4) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  `cant` bigint(21) NOT NULL DEFAULT '0',
  KEY `nodo` (`nodo`),
  KEY `troba` (`troban`),
  KEY `fechahora` (`fechahora`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cortesyreconex_hfc`
--

DROP TABLE IF EXISTS `cortesyreconex_hfc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cortesyreconex_hfc` (
  `codigo_req` int(11) DEFAULT NULL,
  `codigo_del_grupo_req` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `fecha_registro` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `tipotram` int(1) NOT NULL DEFAULT '0',
  `codigo_del_servicio` int(11) DEFAULT NULL,
  `macaddress` varchar(20) DEFAULT NULL,
  `codserv` double DEFAULT NULL,
  `codcli` double DEFAULT NULL,
  `proceso` int(1) DEFAULT NULL,
  `fecha_proceso` varchar(20) DEFAULT NULL,
  UNIQUE KEY `NewIndex1` (`codigo_req`),
  KEY `macaddress` (`macaddress`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cortesyreconexiones`
--

DROP TABLE IF EXISTS `cortesyreconexiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cortesyreconexiones` (
  `codigo_req` int(11) DEFAULT NULL,
  `codigo_del_cliente` int(11) DEFAULT NULL,
  `codigo_del_servicio` int(11) DEFAULT NULL,
  `codigo_del_grupo_req` varchar(2) DEFAULT NULL,
  `fecha_registro` varchar(20) DEFAULT NULL,
  `tipotram` int(1) NOT NULL DEFAULT '0',
  `flag` varchar(1) DEFAULT NULL,
  UNIQUE KEY `NewIndex1` (`codigo_req`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `counter_temp`
--

DROP TABLE IF EXISTS `counter_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `counter_temp` (
  `parte1` varchar(31) DEFAULT NULL,
  `tamanio` varchar(6) DEFAULT NULL,
  `fecha` varchar(13) DEFAULT NULL,
  `carpeta` varchar(9) DEFAULT NULL,
  `archivo` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cpe_temp`
--

DROP TABLE IF EXISTS `cpe_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cpe_temp` (
  `macaddress` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ediftemp`
--

DROP TABLE IF EXISTS `ediftemp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ediftemp` (
  `macaddress` varchar(20) DEFAULT NULL,
  `cmts` varchar(50) DEFAULT NULL,
  KEY `macaddress` (`macaddress`),
  KEY `cmts` (`cmts`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `espacios_cgnat`
--

DROP TABLE IF EXISTS `espacios_cgnat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `espacios_cgnat` (
  `ID_Empresa` varchar(5) DEFAULT NULL,
  `Empresa` varchar(5) DEFAULT NULL,
  `ID_Cliente` double DEFAULT NULL,
  `Nombre_Cliente` varchar(150) DEFAULT NULL,
  `ID_Servicio_CM` double DEFAULT NULL,
  `ID_Producto_CM` double DEFAULT NULL,
  `ID_Venta_CM` double DEFAULT NULL,
  `Service_Package_CRMID` varchar(30) DEFAULT NULL,
  `Service_Package_Configurado` varchar(30) DEFAULT NULL,
  `Cantidad_PCs` varchar(11) DEFAULT NULL,
  `Fecha_Alta` varchar(20) DEFAULT NULL,
  `Grupo_Red_CM` varchar(20) DEFAULT NULL,
  `ID_Servicio_MTA` varchar(100) DEFAULT NULL,
  `ID_Producto_MTA` varchar(100) DEFAULT NULL,
  `ID_Venta_MTA` varchar(100) DEFAULT NULL,
  `Grupo_Red_MTA` varchar(100) DEFAULT NULL,
  `Numero_Telefono` varchar(20) DEFAULT NULL,
  UNIQUE KEY `ID_Producto_CM` (`ID_Producto_CM`,`ID_Venta_CM`),
  KEY `idx_sp` (`Service_Package_CRMID`),
  KEY `ID_Cliente` (`ID_Cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `interfaces_lb`
--

DROP TABLE IF EXISTS `interfaces_lb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `interfaces_lb` (
  `interbus` varchar(40) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `interface` varchar(20) DEFAULT NULL,
  KEY `interbus` (`interbus`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_temp`
--

DROP TABLE IF EXISTS `load_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `load_temp` (
  `parte1` varchar(31) DEFAULT NULL,
  `tamanio` varchar(6) DEFAULT NULL,
  `fecha` varchar(13) DEFAULT NULL,
  `carpeta` varchar(9) DEFAULT NULL,
  `archivo` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_tempx`
--

DROP TABLE IF EXISTS `load_tempx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `load_tempx` (
  `archivo` varchar(40) DEFAULT NULL,
  `tamanio` varchar(6) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marca_modelo`
--

DROP TABLE IF EXISTS `marca_modelo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marca_modelo` (
  `NroCliente` double DEFAULT NULL,
  `Nombre` varchar(200) DEFAULT NULL,
  `MACAddress` varchar(20) DEFAULT NULL,
  `Fechadealta` varchar(20) DEFAULT NULL,
  `Fechadeactivacion` varchar(20) DEFAULT NULL,
  `Fabricante` varchar(20) DEFAULT NULL,
  `Modelo` varchar(100) DEFAULT NULL,
  `Versioon` varchar(100) DEFAULT NULL,
  `Tipodedispositivo` varchar(100) DEFAULT NULL,
  `IPCablemodem` varchar(20) DEFAULT NULL,
  `CMTS` varchar(20) DEFAULT NULL,
  `temp` varchar(20) DEFAULT NULL,
  `fecha_upload` varchar(20) DEFAULT NULL,
  KEY `NewIndex1` (`NroCliente`),
  KEY `NewIndex3` (`CMTS`),
  KEY `NewIndex4` (`Fabricante`),
  KEY `NewIndex2` (`MACAddress`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `masivas_temp`
--

DROP TABLE IF EXISTS `masivas_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `masivas_temp` (
  `check` int(11) NOT NULL AUTO_INCREMENT,
  `numfrecave` int(11) NOT NULL,
  `tipfrecave` varchar(2) DEFAULT NULL,
  `fecreg` varchar(20) DEFAULT NULL,
  `codofcadm` varchar(3) DEFAULT NULL,
  `codcmts` varchar(1) DEFAULT NULL,
  `codnod` varchar(2) NOT NULL,
  `nroplano` varchar(4) NOT NULL,
  `codtrtrn` varchar(4) DEFAULT NULL,
  `edofrecave` varchar(1) DEFAULT NULL,
  `cantreq` int(11) DEFAULT NULL,
  `nrocant` int(11) DEFAULT NULL,
  `fecultact` varchar(20) DEFAULT NULL,
  `coddpt` varchar(3) DEFAULT NULL,
  `codpvc` varchar(3) DEFAULT NULL,
  `codreqmnt` int(11) NOT NULL,
  `codctr` int(11) DEFAULT NULL,
  `codedo` varchar(1) DEFAULT NULL,
  `fecliq` varchar(20) DEFAULT NULL,
  `indorigreq` varchar(1) DEFAULT NULL,
  `cantreqliq` int(11) DEFAULT NULL,
  `codareahbl` varchar(10) DEFAULT NULL,
  `indactuacion` varchar(10) DEFAULT NULL,
  `indseginc` int(11) DEFAULT NULL,
  `indinc` int(11) DEFAULT NULL,
  `codinc` varchar(10) DEFAULT NULL,
  `fecha_upload` varchar(20) DEFAULT NULL,
  UNIQUE KEY `NewIndex4` (`codnod`,`nroplano`),
  KEY `NewIndex1` (`codnod`),
  KEY `NewIndex2` (`nroplano`),
  KEY `NewIndex3` (`fecreg`),
  KEY `check` (`check`)
) ENGINE=InnoDB AUTO_INCREMENT=8922133 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `multi_consultas`
--

DROP TABLE IF EXISTS `multi_consultas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multi_consultas` (
  `item` int(18) NOT NULL AUTO_INCREMENT,
  `tipobusqueda` varchar(20) DEFAULT NULL,
  `dato` int(20) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  `mensaje` varchar(100) DEFAULT NULL,
  `usuario` varchar(20) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplificador` varchar(4) DEFAULT NULL,
  `MACState` varchar(20) DEFAULT NULL,
  `RxPwrdBmv` varchar(20) DEFAULT NULL,
  `MACAddress` varchar(20) DEFAULT NULL,
  `USPwr` varchar(20) DEFAULT NULL,
  `USMER_SNR` varchar(20) DEFAULT NULL,
  `DSPwr` varchar(20) DEFAULT NULL,
  `DSMER_SNR` varchar(20) DEFAULT NULL,
  `STATUS` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`item`),
  UNIQUE KEY `NewIndex3` (`tipobusqueda`,`dato`,`fechahora`),
  KEY `NewIndex1` (`tipobusqueda`),
  KEY `NewIndex2` (`fechahora`),
  KEY `NewIndex4` (`dato`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `amplificador` (`amplificador`),
  KEY `mensaje` (`mensaje`),
  KEY `MACState` (`MACState`),
  KEY `MACAddress` (`MACAddress`)
) ENGINE=MyISAM AUTO_INCREMENT=23699302 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `multi_consultas_48horas`
--

DROP TABLE IF EXISTS `multi_consultas_48horas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multi_consultas_48horas` (
  `item` int(18) NOT NULL DEFAULT '0',
  `tipobusqueda` varchar(20) DEFAULT NULL,
  `dato` bigint(21) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  `mensaje` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `multi_consultas_backup`
--

DROP TABLE IF EXISTS `multi_consultas_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multi_consultas_backup` (
  `item` int(18) NOT NULL AUTO_INCREMENT,
  `tipobusqueda` varchar(20) DEFAULT NULL,
  `dato` int(20) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  `mensaje` varchar(100) DEFAULT NULL,
  `usuario` varchar(20) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplificador` varchar(4) DEFAULT NULL,
  `MACState` varchar(20) DEFAULT NULL,
  `RxPwrdBmv` varchar(20) DEFAULT NULL,
  `MACAddress` varchar(20) DEFAULT NULL,
  `USPwr` varchar(20) DEFAULT NULL,
  `USMER_SNR` varchar(20) DEFAULT NULL,
  `DSPwr` varchar(20) DEFAULT NULL,
  `DSMER_SNR` varchar(20) DEFAULT NULL,
  `STATUS` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`item`),
  UNIQUE KEY `NewIndex3` (`tipobusqueda`,`dato`,`fechahora`),
  KEY `NewIndex1` (`tipobusqueda`),
  KEY `NewIndex2` (`fechahora`),
  KEY `NewIndex4` (`dato`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `amplificador` (`amplificador`),
  KEY `mensaje` (`mensaje`),
  KEY `MACState` (`MACState`),
  KEY `MACAddress` (`MACAddress`)
) ENGINE=InnoDB AUTO_INCREMENT=34341428 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `multi_consultas_c`
--

DROP TABLE IF EXISTS `multi_consultas_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multi_consultas_c` (
  `item` int(18) NOT NULL AUTO_INCREMENT,
  `tipobusqueda` varchar(20) DEFAULT NULL,
  `dato` int(20) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  `mensaje` varchar(100) DEFAULT NULL,
  `usuario` varchar(20) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplificador` varchar(4) DEFAULT NULL,
  `MACState` varchar(20) DEFAULT NULL,
  `RxPwrdBmv` varchar(20) DEFAULT NULL,
  `MACAddress` varchar(20) DEFAULT NULL,
  `USPwr` varchar(20) DEFAULT NULL,
  `USMER_SNR` varchar(20) DEFAULT NULL,
  `DSPwr` varchar(20) DEFAULT NULL,
  `DSMER_SNR` varchar(20) DEFAULT NULL,
  `STATUS` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`item`),
  UNIQUE KEY `NewIndex3` (`tipobusqueda`,`dato`,`fechahora`),
  KEY `NewIndex1` (`tipobusqueda`),
  KEY `NewIndex2` (`fechahora`),
  KEY `NewIndex4` (`dato`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `amplificador` (`amplificador`),
  KEY `mensaje` (`mensaje`),
  KEY `MACState` (`MACState`),
  KEY `MACAddress` (`MACAddress`)
) ENGINE=InnoDB AUTO_INCREMENT=33915570 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ncgnat`
--

DROP TABLE IF EXISTS `ncgnat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ncgnat` (
  `EMPRESA` varchar(3) DEFAULT NULL,
  `IDCLIENTECRM` double DEFAULT NULL,
  `idempresacrm` int(11) DEFAULT NULL,
  `idservicio` int(11) DEFAULT NULL,
  `idproducto` double DEFAULT NULL,
  `idventa` double DEFAULT NULL,
  `NAMECLIENT` varchar(100) DEFAULT NULL,
  `NODO` varchar(2) DEFAULT NULL,
  `TROBA` varchar(4) DEFAULT NULL,
  `amplificador` varchar(11) DEFAULT NULL,
  `tap` varchar(11) DEFAULT NULL,
  `telf1` varchar(10) DEFAULT NULL,
  `telf2` varchar(10) DEFAULT NULL,
  `f_v` varchar(20) DEFAULT NULL,
  `regver` varchar(3) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `SERVICEPACKAGECRMID` varchar(50) DEFAULT NULL,
  `SERVICEPACKAGE` varchar(50) DEFAULT NULL,
  `CANTPCS` varchar(11) DEFAULT NULL,
  `FECHAALTA` varchar(20) DEFAULT NULL,
  `FECHAACTIVACION` varchar(20) DEFAULT NULL,
  `ESTADO` varchar(10) DEFAULT NULL,
  `SCOPESGROUP` varchar(15) DEFAULT NULL,
  `SCOPESGROUPCM` varchar(15) DEFAULT NULL,
  `SCOPESGROUPMTA` varchar(15) DEFAULT NULL,
  `MTAMAC` varchar(20) DEFAULT NULL,
  `IDSERVICIOMTA` varchar(15) DEFAULT NULL,
  `IDPRODUCTOMTA` varchar(15) DEFAULT NULL,
  `IDVENTAMTA` varchar(15) DEFAULT NULL,
  `MTAMODELNAME` varchar(50) DEFAULT NULL,
  `CMTSID` varchar(11) DEFAULT NULL,
  `UBICACIONENLARED` varchar(150) DEFAULT NULL,
  `IPCM` varchar(20) DEFAULT NULL,
  `DOCSISVERSION` varchar(11) DEFAULT NULL,
  `movil1` varchar(20) DEFAULT NULL,
  `mac2` varchar(20) DEFAULT NULL,
  `mac3` varchar(20) DEFAULT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `codserv` varchar(20) DEFAULT NULL,
  `fecha_upload` datetime DEFAULT NULL,
  `naked` varchar(2) DEFAULT NULL,
  `numcoo_x` varchar(20) DEFAULT NULL,
  `numcoo_y` varchar(20) DEFAULT NULL,
  UNIQUE KEY `MACADDRESS` (`MACADDRESS`),
  KEY `IDCLIENTECRM` (`IDCLIENTECRM`),
  KEY `idservicio` (`idservicio`),
  KEY `idproducto` (`idproducto`),
  KEY `idventa` (`idventa`),
  KEY `cmts` (`cmts`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nclientes`
--

DROP TABLE IF EXISTS `nclientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nclientes` (
  `EMPRESA` varchar(3) DEFAULT NULL,
  `IDCLIENTECRM` double DEFAULT NULL,
  `idempresacrm` int(11) DEFAULT NULL,
  `idservicio` int(11) DEFAULT NULL,
  `idproducto` double DEFAULT NULL,
  `idventa` double DEFAULT NULL,
  `NAMECLIENT` varchar(100) DEFAULT NULL,
  `NODO` varchar(2) DEFAULT NULL,
  `TROBA` varchar(4) DEFAULT NULL,
  `amplificador` varchar(11) DEFAULT NULL,
  `tap` varchar(11) DEFAULT NULL,
  `telf1` varchar(10) DEFAULT NULL,
  `telf2` varchar(10) DEFAULT NULL,
  `f_v` varchar(20) DEFAULT NULL,
  `regver` varchar(3) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `SERVICEPACKAGECRMID` varchar(50) DEFAULT NULL,
  `SERVICEPACKAGE` varchar(50) DEFAULT NULL,
  `CANTPCS` varchar(11) DEFAULT NULL,
  `FECHAALTA` varchar(20) DEFAULT NULL,
  `FECHAACTIVACION` varchar(20) DEFAULT NULL,
  `ESTADO` varchar(10) DEFAULT NULL,
  `SCOPESGROUP` varchar(15) DEFAULT NULL,
  `SCOPESGROUPCM` varchar(15) DEFAULT NULL,
  `SCOPESGROUPMTA` varchar(15) DEFAULT NULL,
  `MTAMAC` varchar(20) DEFAULT NULL,
  `IDSERVICIOMTA` varchar(15) DEFAULT NULL,
  `IDPRODUCTOMTA` varchar(15) DEFAULT NULL,
  `IDVENTAMTA` varchar(15) DEFAULT NULL,
  `MTAMODELNAME` varchar(50) DEFAULT NULL,
  `CMTSID` varchar(11) DEFAULT NULL,
  `UBICACIONENLARED` varchar(150) DEFAULT NULL,
  `IPCM` varchar(20) DEFAULT NULL,
  `DOCSISVERSION` varchar(11) DEFAULT NULL,
  `movil1` varchar(20) DEFAULT NULL,
  `mac2` varchar(20) DEFAULT NULL,
  `mac3` varchar(20) DEFAULT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `codserv` int(11) DEFAULT NULL,
  `fecha_upload` datetime DEFAULT NULL,
  `naked` varchar(50) DEFAULT NULL,
  `numcoo_x` varchar(20) DEFAULT NULL,
  `numcoo_y` varchar(20) DEFAULT NULL,
  UNIQUE KEY `NewIndex3` (`MACADDRESS`),
  KEY `NewIndex1` (`IDCLIENTECRM`),
  KEY `NewIndex2` (`NAMECLIENT`),
  KEY `idxservicepackage` (`SERVICEPACKAGE`),
  KEY `idx3` (`SERVICEPACKAGECRMID`),
  KEY `idxtelef1` (`telf1`),
  KEY `idxtelef2` (`telf2`),
  KEY `idxmovil` (`movil1`),
  KEY `NewIndex4` (`mac2`),
  KEY `NewIndex5` (`mac3`),
  KEY `idx6` (`SCOPESGROUPMTA`),
  KEY `idxmtamac` (`MTAMAC`),
  KEY `idx7` (`IDSERVICIOMTA`),
  KEY `idxestado` (`ESTADO`),
  KEY `idproducto` (`idproducto`),
  KEY `idventa` (`idventa`),
  KEY `idxcodserv` (`codserv`),
  KEY `idxfv` (`f_v`),
  KEY `cmts` (`cmts`),
  KEY `NODO` (`NODO`),
  KEY `TROBA` (`TROBA`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nclientes_c`
--

DROP TABLE IF EXISTS `nclientes_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nclientes_c` (
  `EMPRESA` varchar(3) DEFAULT NULL,
  `IDCLIENTECRM` double DEFAULT NULL,
  `idempresacrm` int(11) DEFAULT NULL,
  `idservicio` int(11) DEFAULT NULL,
  `idproducto` double DEFAULT NULL,
  `idventa` double DEFAULT NULL,
  `NAMECLIENT` varchar(100) DEFAULT NULL,
  `NODO` varchar(2) DEFAULT NULL,
  `TROBA` varchar(4) DEFAULT NULL,
  `amplificador` varchar(11) DEFAULT NULL,
  `tap` varchar(11) DEFAULT NULL,
  `telf1` varchar(10) DEFAULT NULL,
  `telf2` varchar(10) DEFAULT NULL,
  `f_v` varchar(20) DEFAULT NULL,
  `regver` varchar(3) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `SERVICEPACKAGECRMID` varchar(50) DEFAULT NULL,
  `SERVICEPACKAGE` varchar(50) DEFAULT NULL,
  `CANTPCS` varchar(11) DEFAULT NULL,
  `FECHAALTA` varchar(20) DEFAULT NULL,
  `FECHAACTIVACION` varchar(20) DEFAULT NULL,
  `ESTADO` varchar(10) DEFAULT NULL,
  `SCOPESGROUP` varchar(15) DEFAULT NULL,
  `SCOPESGROUPCM` varchar(15) DEFAULT NULL,
  `SCOPESGROUPMTA` varchar(15) DEFAULT NULL,
  `MTAMAC` varchar(20) DEFAULT NULL,
  `IDSERVICIOMTA` varchar(15) DEFAULT NULL,
  `IDPRODUCTOMTA` varchar(15) DEFAULT NULL,
  `IDVENTAMTA` varchar(15) DEFAULT NULL,
  `MTAMODELNAME` varchar(50) DEFAULT NULL,
  `CMTSID` varchar(11) DEFAULT NULL,
  `UBICACIONENLARED` varchar(150) DEFAULT NULL,
  `IPCM` varchar(20) DEFAULT NULL,
  `DOCSISVERSION` varchar(11) DEFAULT NULL,
  `movil1` varchar(20) DEFAULT NULL,
  `mac2` varchar(20) DEFAULT NULL,
  `mac3` varchar(20) DEFAULT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `codserv` int(11) DEFAULT NULL,
  `fecha_upload` datetime DEFAULT NULL,
  `naked` varchar(50) DEFAULT NULL,
  `numcoo_x` varchar(20) DEFAULT NULL,
  `numcoo_y` varchar(20) DEFAULT NULL,
  UNIQUE KEY `NewIndex3` (`MACADDRESS`),
  KEY `NewIndex1` (`IDCLIENTECRM`),
  KEY `NewIndex2` (`NAMECLIENT`),
  KEY `idxservicepackage` (`SERVICEPACKAGE`),
  KEY `idx3` (`SERVICEPACKAGECRMID`),
  KEY `idxtelef1` (`telf1`),
  KEY `idxtelef2` (`telf2`),
  KEY `idxmovil` (`movil1`),
  KEY `NewIndex4` (`mac2`),
  KEY `NewIndex5` (`mac3`),
  KEY `idx6` (`SCOPESGROUPMTA`),
  KEY `idxmtamac` (`MTAMAC`),
  KEY `idx7` (`IDSERVICIOMTA`),
  KEY `idxestado` (`ESTADO`),
  KEY `idproducto` (`idproducto`),
  KEY `idventa` (`idventa`),
  KEY `idxcodserv` (`codserv`),
  KEY `idxfv` (`f_v`),
  KEY `cmts` (`cmts`),
  KEY `NODO` (`NODO`),
  KEY `TROBA` (`TROBA`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `phy_temp`
--

DROP TABLE IF EXISTS `phy_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phy_temp` (
  `parte1` varchar(31) DEFAULT NULL,
  `tamanio` varchar(6) DEFAULT NULL,
  `fecha` varchar(13) DEFAULT NULL,
  `carpeta` varchar(9) DEFAULT NULL,
  `archivo` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `phy_tempx`
--

DROP TABLE IF EXISTS `phy_tempx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phy_tempx` (
  `archivo` varchar(40) DEFAULT NULL,
  `tamanio` varchar(6) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `phy_tempx_1`
--

DROP TABLE IF EXISTS `phy_tempx_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phy_tempx_1` (
  `archivo` varchar(40) DEFAULT NULL,
  `tamanio` varchar(6) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `respuesta`
--

DROP TABLE IF EXISTS `respuesta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `respuesta` (
  `respuesta` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `scm_calls`
--

DROP TABLE IF EXISTS `scm_calls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scm_calls` (
  `macaddress` varchar(20) NOT NULL,
  `cmts` varchar(40) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`macaddress`),
  KEY `cmts` (`cmts`),
  KEY `fecha_hora` (`fecha_hora`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `scm_cpe_huawei`
--

DROP TABLE IF EXISTS `scm_cpe_huawei`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scm_cpe_huawei` (
  `indice` int(6) DEFAULT NULL,
  `cmmac` varchar(14) DEFAULT NULL,
  `cmip` varchar(20) DEFAULT NULL,
  `cpemac` varchar(14) NOT NULL,
  `cpeip` varchar(20) DEFAULT NULL,
  `devicedesc` varchar(8) DEFAULT NULL,
  `olt` varchar(30) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  KEY `cpemac` (`cpemac`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `scm_phy_f`
--

DROP TABLE IF EXISTS `scm_phy_f`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scm_phy_f` (
  `MACAddress` varchar(20) DEFAULT NULL,
  `Interface` varchar(20) DEFAULT NULL,
  `Sid` varchar(20) DEFAULT NULL,
  `USPwr` varchar(20) DEFAULT NULL,
  `USMER_SNR` varchar(20) DEFAULT NULL,
  `Timing_Offset` varchar(20) DEFAULT NULL,
  `DSPwr` varchar(20) DEFAULT NULL,
  `DSMER_SNR` varchar(20) DEFAULT NULL,
  `Mode_` varchar(20) DEFAULT NULL,
  `DOCSIS_Prov` varchar(20) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `ultimo` varchar(1) DEFAULT NULL,
  UNIQUE KEY `NewIndex1` (`MACAddress`),
  KEY `NewIndex2` (`Interface`),
  KEY `NewIndex3` (`Sid`),
  KEY `NewIndex4` (`cmts`),
  KEY `NewIndex5` (`ultimo`),
  KEY `USPwr` (`USPwr`),
  KEY `USMER_SNR` (`USMER_SNR`),
  KEY `DSPwr` (`DSPwr`),
  KEY `DSMER_SNR` (`DSMER_SNR`),
  KEY `FECHA` (`fecha_hora`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `scm_phy_t`
--

DROP TABLE IF EXISTS `scm_phy_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scm_phy_t` (
  `MACAddress` varchar(20) DEFAULT NULL,
  `Interface` varchar(20) DEFAULT NULL,
  `Sid` varchar(20) DEFAULT NULL,
  `USPwr` varchar(20) DEFAULT NULL,
  `USMER_SNR` varchar(20) DEFAULT NULL,
  `Timing_Offset` varchar(20) DEFAULT NULL,
  `DSPwr` varchar(20) DEFAULT NULL,
  `DSMER_SNR` varchar(20) DEFAULT NULL,
  `Mode_` varchar(20) DEFAULT NULL,
  `DOCSIS_Prov` varchar(20) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `ultimo` varchar(1) DEFAULT NULL,
  UNIQUE KEY `NewIndex1` (`MACAddress`),
  KEY `NewIndex2` (`Interface`),
  KEY `NewIndex3` (`Sid`),
  KEY `NewIndex4` (`cmts`),
  KEY `NewIndex5` (`ultimo`),
  KEY `USPwr` (`USPwr`),
  KEY `USMER_SNR` (`USMER_SNR`),
  KEY `DSPwr` (`DSPwr`),
  KEY `DSMER_SNR` (`DSMER_SNR`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `scm_sum`
--

DROP TABLE IF EXISTS `scm_sum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scm_sum` (
  `interface` varchar(12) DEFAULT NULL,
  `cm_tot` int(11) DEFAULT NULL,
  `cm_reg` int(11) DEFAULT NULL,
  `cm_oper` int(11) DEFAULT NULL,
  `cm_unreg` int(11) DEFAULT NULL,
  `cm_offline` int(11) DEFAULT NULL,
  `widband` int(11) DEFAULT NULL,
  `inicrc` int(11) DEFAULT NULL,
  `initd` int(11) DEFAULT NULL,
  `initio` int(11) DEFAULT NULL,
  `init0` int(11) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `ultimo` varchar(10) DEFAULT NULL,
  `Interface6` varchar(10) DEFAULT NULL,
  KEY `idxInterface` (`interface`),
  KEY `idxCmts` (`cmts`),
  KEY `idxDescrip` (`description`),
  KEY `idxInterface6` (`Interface6`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `scm_sum_huawei`
--

DROP TABLE IF EXISTS `scm_sum_huawei`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scm_sum_huawei` (
  `interface` varchar(20) DEFAULT NULL,
  `Total` varchar(20) DEFAULT NULL,
  `Online` varchar(20) DEFAULT NULL,
  `Offline` varchar(20) DEFAULT NULL,
  `Unreg` varchar(20) DEFAULT NULL,
  `DHCP` varchar(20) DEFAULT NULL,
  `DHCP_C` varchar(20) DEFAULT NULL,
  `Wide_band` varchar(20) DEFAULT NULL,
  `TFTP` varchar(20) DEFAULT NULL,
  `TFTP_C` varchar(20) DEFAULT NULL,
  `olt` varchar(50) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `scm_temp`
--

DROP TABLE IF EXISTS `scm_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scm_temp` (
  `parte1` varchar(31) DEFAULT NULL,
  `tamanio` varchar(6) DEFAULT NULL,
  `fecha` varchar(13) DEFAULT NULL,
  `carpeta` varchar(9) DEFAULT NULL,
  `archivo` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `scm_temp_counter_1`
--

DROP TABLE IF EXISTS `scm_temp_counter_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scm_temp_counter_1` (
  `archivo` varchar(40) DEFAULT NULL,
  `tamanio` varchar(6) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `scm_tempx`
--

DROP TABLE IF EXISTS `scm_tempx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scm_tempx` (
  `archivo` varchar(40) DEFAULT NULL,
  `tamanio` varchar(6) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `scm_total`
--

DROP TABLE IF EXISTS `scm_total`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scm_total` (
  `MACAddress` varchar(20) DEFAULT NULL,
  `IPAddress` varchar(20) DEFAULT NULL,
  `Interface` varchar(20) DEFAULT NULL,
  `MACState` varchar(20) DEFAULT NULL,
  `PrimSid` int(11) DEFAULT NULL,
  `RxPwrdBmv` varchar(20) DEFAULT NULL,
  `TimingOFFSET` varchar(20) DEFAULT NULL,
  `NumCPE` varchar(20) DEFAULT NULL,
  `DIP` varchar(20) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `FECHA_HORA` varchar(20) DEFAULT NULL,
  `ultimo` varchar(1) DEFAULT NULL,
  `interface6` varchar(10) DEFAULT NULL,
  UNIQUE KEY `MACAddress` (`MACAddress`),
  KEY `IPAddress` (`IPAddress`),
  KEY `Interface` (`Interface`),
  KEY `MACState` (`MACState`),
  KEY `cmts` (`cmts`),
  KEY `FECHA_HORA` (`FECHA_HORA`),
  KEY `interface6` (`interface6`),
  KEY `PrimSid` (`PrimSid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `scm_total_f`
--

DROP TABLE IF EXISTS `scm_total_f`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scm_total_f` (
  `MACAddress` varchar(20) DEFAULT NULL,
  `IPAddress` varchar(20) DEFAULT NULL,
  `Interface` varchar(20) DEFAULT NULL,
  `MACState` varchar(20) DEFAULT NULL,
  `PrimSid` int(11) DEFAULT NULL,
  `RxPwrdBmv` varchar(20) DEFAULT NULL,
  `TimingOFFSET` varchar(20) DEFAULT NULL,
  `NumCPE` varchar(20) DEFAULT NULL,
  `DIP` varchar(20) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `FECHA_HORA` varchar(20) DEFAULT NULL,
  `ultimo` varchar(1) DEFAULT NULL,
  `interface6` varchar(10) DEFAULT NULL,
  UNIQUE KEY `MACAddress` (`MACAddress`),
  KEY `IPAddress` (`IPAddress`),
  KEY `Interface` (`Interface`),
  KEY `MACState` (`MACState`),
  KEY `cmts` (`cmts`),
  KEY `FECHA_HORA` (`FECHA_HORA`),
  KEY `interface6` (`interface6`),
  KEY `PrimSid` (`PrimSid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `scmconectivity`
--

DROP TABLE IF EXISTS `scmconectivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scmconectivity` (
  `primssid` int(11) DEFAULT NULL,
  `FechaInicio` varchar(20) DEFAULT NULL,
  `TimesOnline` varchar(20) DEFAULT NULL,
  `PorcOnline` varchar(20) DEFAULT NULL,
  `OnlineMin` varchar(20) DEFAULT NULL,
  `OnlineAvg` varchar(20) DEFAULT NULL,
  `OnlineMax` varchar(20) DEFAULT NULL,
  `OfflineMin` varchar(20) DEFAULT NULL,
  `OfflineAvg` varchar(20) DEFAULT NULL,
  `OfflineMax` varchar(20) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `ultimo` varchar(1) DEFAULT NULL,
  KEY `NewIndex1` (`primssid`),
  KEY `NewIndex2` (`cmts`),
  KEY `NewIndex3` (`fecha_hora`),
  KEY `NewIndex4` (`ultimo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `scmdocsisversion`
--

DROP TABLE IF EXISTS `scmdocsisversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scmdocsisversion` (
  `MACAddress` varchar(16) DEFAULT NULL,
  `Interface` varchar(10) DEFAULT NULL,
  `MACStatus` varchar(10) DEFAULT NULL,
  `PrimSid` varchar(5) DEFAULT NULL,
  `RegVer` varchar(4) DEFAULT NULL,
  `QoSProv` varchar(4) DEFAULT NULL,
  `USPhyModel` varchar(6) DEFAULT NULL,
  `DSChlMode` varchar(5) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `ultimo` varchar(1) DEFAULT NULL,
  KEY `NewIndex1` (`MACAddress`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `show_cable_flaps`
--

DROP TABLE IF EXISTS `show_cable_flaps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `show_cable_flaps` (
  `MACAddress` varchar(14) NOT NULL,
  `IF_` varchar(10) DEFAULT NULL,
  `Ins` int(4) DEFAULT NULL,
  `Hit` int(7) DEFAULT NULL,
  `Miss` int(4) DEFAULT NULL,
  `CRC` int(3) DEFAULT NULL,
  `P_Adj` varchar(6) DEFAULT NULL,
  `Flap` int(5) DEFAULT NULL,
  `Time` varchar(20) DEFAULT NULL,
  `CMTS` varchar(20) DEFAULT NULL,
  `fecha_upload` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`MACAddress`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `status_portadoras`
--

DROP TABLE IF EXISTS `status_portadoras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `status_portadoras` (
  `cmts` varchar(20) DEFAULT NULL,
  `frecuencia` varchar(3) DEFAULT NULL,
  `primary_down` varchar(30) DEFAULT NULL,
  `interface` varchar(20) DEFAULT NULL,
  `status` varchar(8) DEFAULT NULL,
  `utilizacion` varchar(3) DEFAULT NULL,
  `cant` bigint(21) NOT NULL DEFAULT '0',
  `fechaupdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `cmts` (`cmts`),
  KEY `interface` (`interface`),
  KEY `primary_down` (`primary_down`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `status_portadoras_ant`
--

DROP TABLE IF EXISTS `status_portadoras_ant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `status_portadoras_ant` (
  `cmts` varchar(20) DEFAULT NULL,
  `frecuencia` varchar(3) DEFAULT NULL,
  `primary_down` varchar(30) DEFAULT NULL,
  `interface` varchar(20) DEFAULT NULL,
  `status` varchar(8) DEFAULT NULL,
  `utilizacion` varchar(3) DEFAULT NULL,
  `cant` bigint(21) NOT NULL DEFAULT '0',
  `fechaupdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `cmts` (`cmts`),
  KEY `interface` (`interface`),
  KEY `primary_down` (`primary_down`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sum_temp`
--

DROP TABLE IF EXISTS `sum_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sum_temp` (
  `parte1` varchar(31) DEFAULT NULL,
  `tamanio` varchar(6) DEFAULT NULL,
  `fecha` varchar(13) DEFAULT NULL,
  `carpeta` varchar(9) DEFAULT NULL,
  `archivo` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sum_tempx`
--

DROP TABLE IF EXISTS `sum_tempx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sum_tempx` (
  `archivo` varchar(40) DEFAULT NULL,
  `tamanio` varchar(6) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trabajos_programados`
--

DROP TABLE IF EXISTS `trabajos_programados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trabajos_programados` (
  `ITEM` int(11) NOT NULL AUTO_INCREMENT,
  `NODO` varchar(2) DEFAULT NULL,
  `TROBA` varchar(4) DEFAULT NULL,
  `AMP` varchar(80) DEFAULT NULL,
  `TIPODETRABAJO` varchar(200) DEFAULT NULL,
  `SUPERVISOR` varchar(150) DEFAULT NULL,
  `FINICIO` varchar(20) DEFAULT NULL,
  `HINICIO` varchar(10) DEFAULT NULL,
  `HTERMINO` varchar(10) DEFAULT NULL,
  `HORARIO` varchar(10) DEFAULT NULL,
  `CORTESN` varchar(10) DEFAULT NULL,
  `OPERADOR` varchar(100) DEFAULT NULL,
  `FECHA` varchar(20) DEFAULT NULL,
  `HORA` varchar(10) DEFAULT NULL,
  `TRABAJO` varchar(100) DEFAULT NULL,
  `REMEDY` varchar(10) DEFAULT NULL,
  `TECNICO` varchar(100) DEFAULT NULL,
  `RPM` varchar(10) DEFAULT NULL,
  `CONTRATA` varchar(50) DEFAULT NULL,
  `HORACIERRE` varchar(10) DEFAULT NULL,
  `OBSERVACIONES` varchar(500) DEFAULT NULL,
  `ESTADO` varchar(10) DEFAULT NULL,
  `fecha_registro` varchar(20) DEFAULT NULL,
  `fecha_apertura` varchar(20) DEFAULT NULL,
  `fecha_cierre` varchar(20) DEFAULT NULL,
  `fecha_cancela` varchar(20) DEFAULT NULL,
  `usuario` varchar(20) DEFAULT NULL,
  `usuario_apertura` varchar(20) DEFAULT NULL,
  `usuario_cierre` varchar(20) DEFAULT NULL,
  `usuario_cancela` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ITEM`),
  KEY `NewIndex1` (`NODO`),
  KEY `NewIndex2` (`TROBA`),
  KEY `NewIndex3` (`FINICIO`),
  KEY `ESTADO` (`ESTADO`)
) ENGINE=MyISAM AUTO_INCREMENT=43752 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trafico_iw_now`
--

DROP TABLE IF EXISTS `trafico_iw_now`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trafico_iw_now` (
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `IDCLIENTCRM` double DEFAULT NULL,
  `TRAFFICDOWN_MB` int(11) DEFAULT NULL,
  `TRAFFICUP_MB` int(11) DEFAULT NULL,
  `BRAND` varchar(20) DEFAULT NULL,
  `MODEL` varchar(20) DEFAULT NULL,
  `SERVICEPACKAGE` varchar(100) DEFAULT NULL,
  `DOCSISVERSION` int(11) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  KEY `NewIndex1` (`MACADDRESS`),
  KEY `NewIndex2` (`IDCLIENTCRM`),
  KEY `NewIndex3` (`fecha_hora`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trobasconcaidas_sms`
--

DROP TABLE IF EXISTS `trobasconcaidas_sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trobasconcaidas_sms` (
  `nodo` varchar(10) DEFAULT NULL,
  `troba` varchar(10) DEFAULT NULL,
  `fecha_hora` datetime DEFAULT NULL,
  `sms_enviado` tinyint(3) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `idxunico` (`nodo`,`troba`,`fecha_hora`),
  KEY `idxnodo` (`nodo`),
  KEY `idxtroba` (`troba`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `validatxt_x`
--

DROP TABLE IF EXISTS `validatxt_x`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `validatxt_x` (
  `acceso` varchar(10) DEFAULT NULL,
  `num` varchar(2) DEFAULT NULL,
  `usuario1` varchar(10) DEFAULT NULL,
  `usuario2` varchar(10) DEFAULT NULL,
  `peso` varchar(6) DEFAULT NULL,
  `mes` varchar(13) DEFAULT NULL,
  `dia` varchar(10) DEFAULT NULL,
  `hora` varchar(10) DEFAULT NULL,
  `fecha` varchar(20) DEFAULT NULL,
  `validacion` varchar(10) DEFAULT NULL,
  `carpeta` varchar(9) DEFAULT NULL,
  `archivo` varchar(40) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'ccm1_temporal'
--
/*!50003 DROP PROCEDURE IF EXISTS `sp_consultasCatv` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`smiranda`@`%` PROCEDURE `sp_consultasCatv`(IN file_name char(64))
BEGIN
set @myvar = concat("SELECT 
'cliente','nodo','plano','amplificador','fechahora','mensaje','usuario','codreq','codmotv','tipreqini','fecreg_aver' 
union SELECT a.dato as 
cliente,a.nodo,a.troba as plano,amplificador,a.fechahora,a.mensaje,a.usuario ,b.codreq,b.codmotv,b.tipreqini,b.fec_mov 
FROM multiconsulta.multi_consultas a left 
join ccm1_temporal.averias_catv_new_7 b on a.dato=b.codcli and timediff(b.fec_mov,a.fechahora)>='00:00:00' and datediff(b.fec_mov,a.fechahora)<=0 WHERE 
datediff(NOW(),fechahora)<=1 AND a.dato>0 GROUP BY a.dato,a.fechahora 
INTO OUTFILE '",file_name,"' FIELDS TERMINATED BY ',' lines terminated by '\r\n'");
PREPARE stmt1 FROM @myvar; 
EXECUTE stmt1; 
Deallocate prepare stmt1; 
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_data_alarm` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`rfalla`@`%` PROCEDURE `sp_data_alarm`()
BEGIN
IF (HOUR(NOW())>=4 AND HOUR(NOW())<=5) THEN
REPLACE cantroba
(SELECT nodo,troba,COUNT(*) AS cant , CONCAT(nodo,troba) AS clave FROM ccm1.nclientes
WHERE nodo IS NOT NULL
  GROUP BY 1,2);
END IF;
	#CALL catalogos.llamadasxtroba;	
		
#Inserta alertas por parametros, cada una con un color distinto	
###M1 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
TRUNCATE TABLE ccm1_temporal.consultasr;
INSERT INTO ccm1_temporal.consultasr
SELECT nodo,troba AS troban,SUBSTR(fechahora,1,16) AS fechahora,COUNT(*) AS cant FROM ccm1_temporal.multi_consultas 
WHERE macaddress<>''
GROUP BY 1,2;
TRUNCATE TABLE ccm1_temporal.consultasr_d_c;
INSERT IGNORE ccm1_temporal.consultasr_d_c
SELECT  dato,MAX(fechahora) AS fechahora,1 AS cant  FROM ccm1_temporal.multi_consultas
WHERE fechahora>=(SELECT CONCAT(SUBSTR(MIN(fecreg),7,4),'-',SUBSTR(MIN(fecreg),4,2),'-',SUBSTR(MIN(fecreg),1,2),' ',SUBSTR(MIN(fecreg),12,8)) 
FROM ccm1_temporal.masivas_temp)
GROUP BY 1;
TRUNCATE TABLE ccm1_temporal.`consultasr_n`;
INSERT INTO ccm1_temporal.`consultasr_n`
SELECT a.nodo,a.troba AS troban,b.fechahora,COUNT(*) AS cant FROM ccm1.nclientes a INNER JOIN
(SELECT SUBSTR(fechahora,1,13) AS fechahora,dato FROM ccm1_temporal.consultasr_d_c GROUP BY 1,2) b
ON a.idclientecrm=b.dato 
WHERE a.nodo IS NOT NULL
GROUP BY 1,2,3;
#####Amplif
TRUNCATE TABLE ccm1_temporal.`consultasr_amplif`;
INSERT INTO ccm1_temporal.`consultasr_amplif`
SELECT a.nodo,a.troba AS troban,a.amplificador,b.fechahora,COUNT(*) AS cant FROM ccm1.nclientes a INNER JOIN
ccm1_temporal.consultasr_d_c b
ON a.idclientecrm=b.dato 
WHERE a.nodo IS NOT NULL
GROUP BY 1,2,3,4;	
####CATV
TRUNCATE TABLE ccm1_temporal.`consultasr_catv_c`;
INSERT INTO ccm1_temporal.`consultasr_catv_c`
SELECT nodo,troba,SUBSTR(fechahora,1,16) AS fechahora,COUNT(*) AS cant FROM ccm1_temporal.multi_consultas 
GROUP BY 1,2,3;
RENAME TABLE ccm1_temporal.consultasr_catv TO ccm1_temporal.consultasr_catv_temp,
	     ccm1_temporal.consultasr_catv_c TO ccm1_temporal.consultasr_catv,
             ccm1_temporal.consultasr_catv_temp TO ccm1_temporal.consultasr_catv_c;
             
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_multi_consultas_48horas` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`smiranda`@`%` PROCEDURE `sp_multi_consultas_48horas`()
BEGIN
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
TRUNCATE TABLE ccm1_temporal.`multi_consultas_48horas`;
INSERT INTO ccm1_temporal.`multi_consultas_48horas`
SELECT item, tipobusqueda, dato*1 AS dato, fechahora, mensaje FROM ccm1_temporal.`multi_consultas` 
WHERE (TIME_TO_SEC(TIMEDIFF(NOW(), `fechahora` )) / 3600) <= 48;
DROP TABLE IF EXISTS ccm1_temporal.`multi_consultas_48horas_sinaverias`;
CREATE TABLE ccm1_temporal.`multi_consultas_48horas_sinaverias`
SELECT a.dato, COUNT(*) as total_llamadas FROM ccm1_temporal.`multi_consultas_48horas` a
LEFT JOIN ccm1_temporal.`averias_criticos_tmp_averias` b
ON a.`dato`=b.inscripcion 
WHERE b.inscripcion IS NULL GROUP BY 1 
-- HAVING COUNT(*)>3
ORDER BY 2 DESC;
commit;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `cant_caidas`
--

/*!50001 DROP TABLE IF EXISTS `cant_caidas`*/;
/*!50001 DROP VIEW IF EXISTS `cant_caidas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ccm1_user`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `cant_caidas` AS (select `alarmas_caidas_historico`.`nodo` AS `nodo`,`alarmas_caidas_historico`.`troba` AS `troba`,count(0) AS `caidas`,round(avg(`alarmas_caidas_historico`.`off`),0) AS `off`,round(avg(`alarmas_caidas_historico`.`cant`),0) AS `cantcli` from `alarmas_caidas_historico` where ((to_days(now()) - to_days(`alarmas_caidas_historico`.`fecha_hora`)) <= 7) group by `alarmas_caidas_historico`.`nodo`,`alarmas_caidas_historico`.`troba`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-23 13:35:18
