-- MySQL dump 10.15  Distrib 10.0.34-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: alertasx
-- ------------------------------------------------------
-- Server version	10.0.34-MariaDB-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alarmas_caidas_historico`
--

DROP TABLE IF EXISTS `alarmas_caidas_historico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alarmas_caidas_historico` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `aver` bigint(21) DEFAULT '0',
  `llamadas` bigint(21) DEFAULT '0',
  `cant` int(21) DEFAULT NULL,
  `umbral` int(12) DEFAULT NULL,
  `off` int(21) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `tiempo` time DEFAULT NULL,
  `fecha_fin` varchar(20) DEFAULT NULL,
  `codmasiva` int(11) DEFAULT NULL,
  UNIQUE KEY `NewIndex1` (`nodo`,`troba`,`fecha_hora`,`fecha_fin`),
  KEY `idxnodo` (`nodo`),
  KEY `idxtroba` (`troba`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alarmas_ims_view`
--

DROP TABLE IF EXISTS `alarmas_ims_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alarmas_ims_view` (
  `cmts` varchar(50) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `cant` int(11) DEFAULT NULL,
  UNIQUE KEY `cmts_2` (`cmts`,`nodo`,`troba`),
  KEY `cmts` (`cmts`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alerta_edificio_sw`
--

DROP TABLE IF EXISTS `alerta_edificio_sw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alerta_edificio_sw` (
  `sw` int(11) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  KEY `sw` (`sw`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `alerta_ips`
--

DROP TABLE IF EXISTS `alerta_ips`;
/*!50001 DROP VIEW IF EXISTS `alerta_ips`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `alerta_ips` (
  `cmts` tinyint NOT NULL,
  `scopesgroup` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `used` tinyint NOT NULL,
  `available` tinyint NOT NULL,
  `porc` tinyint NOT NULL,
  `color` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `alertas_consultas`
--

DROP TABLE IF EXISTS `alertas_consultas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alertas_consultas` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `cant` int(11) DEFAULT NULL,
  UNIQUE KEY `nodo_2` (`nodo`,`troba`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alertas_consultas_d`
--

DROP TABLE IF EXISTS `alertas_consultas_d`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alertas_consultas_d` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `cant` int(11) DEFAULT NULL,
  UNIQUE KEY `nodo_2` (`nodo`,`troba`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alertas_edificio`
--

DROP TABLE IF EXISTS `alertas_edificio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alertas_edificio` (
  `desdtt` varchar(100) DEFAULT NULL,
  `via` varchar(20) DEFAULT NULL,
  `nro` varchar(20) DEFAULT NULL,
  `cant` int(11) DEFAULT NULL,
  `fecha_hora_ini` varchar(20) DEFAULT NULL,
  `fecha_hora_fin` varchar(20) DEFAULT NULL,
  `estado` varchar(50) DEFAULT NULL,
  UNIQUE KEY `desdtt_3` (`desdtt`,`via`,`nro`),
  KEY `desdtt_2` (`desdtt`),
  KEY `via` (`via`),
  KEY `nro` (`nro`),
  KEY `desdtt` (`desdtt`,`via`,`nro`,`fecha_hora_ini`),
  KEY `fecha_hora_ini` (`fecha_hora_ini`),
  KEY `estado` (`estado`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alertas_edificio_c`
--

DROP TABLE IF EXISTS `alertas_edificio_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alertas_edificio_c` (
  `desdtt` varchar(100) DEFAULT NULL,
  `via` varchar(20) DEFAULT NULL,
  `nro` varchar(20) DEFAULT NULL,
  `cant` int(11) DEFAULT NULL,
  KEY `desdtt` (`desdtt`,`via`,`nro`),
  KEY `desdtt_2` (`desdtt`),
  KEY `via` (`via`),
  KEY `nro` (`nro`),
  KEY `desdtt_3` (`desdtt`,`via`,`nro`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alertas_reporte`
--

DROP TABLE IF EXISTS `alertas_reporte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alertas_reporte` (
  `jefatura` varchar(50) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `trabprog` varchar(200) DEFAULT NULL,
  `aver` int(11) DEFAULT NULL,
  `cancli` int(11) DEFAULT NULL,
  `umbral` int(11) DEFAULT NULL,
  `offline` int(11) DEFAULT NULL,
  `codmasiva` int(11) DEFAULT NULL,
  `consultas` int(11) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `fecha_fin` varchar(20) DEFAULT NULL,
  `critico` varchar(20) DEFAULT NULL,
  `tiempo` varchar(20) DEFAULT NULL,
  `ncaidas` int(11) DEFAULT NULL,
  `numbor` int(11) DEFAULT NULL,
  `estadomasiva` varchar(20) DEFAULT NULL,
  `alertaestado` varchar(20) DEFAULT NULL,
  `fgest` varchar(20) DEFAULT NULL,
  `observaciones` varchar(300) DEFAULT NULL,
  `user` varchar(20) DEFAULT NULL,
  `tecnico` varchar(100) DEFAULT NULL,
  UNIQUE KEY `jefatura` (`jefatura`,`nodo`,`troba`,`fecha_hora`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `averias_catv`
--

DROP TABLE IF EXISTS `averias_catv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `averias_catv` (
  `codofcadm` varchar(3) DEFAULT NULL,
  `codreq` int(16) DEFAULT NULL,
  `codclasrv` int(16) DEFAULT NULL,
  `tipreqini` varchar(2) DEFAULT NULL,
  `destipreqini` varchar(100) DEFAULT NULL,
  `fec_mov` varchar(20) DEFAULT NULL,
  `estado` varchar(80) DEFAULT NULL,
  `codestado` int(20) DEFAULT NULL,
  `codcli` int(20) DEFAULT NULL,
  `codnod` varchar(2) DEFAULT NULL,
  `nroplano` varchar(4) DEFAULT NULL,
  `fecha_proc` varchar(20) DEFAULT NULL,
  `fecha_file` varchar(50) DEFAULT NULL,
  `id2` varchar(50) DEFAULT NULL,
  `id` int(20) DEFAULT NULL,
  `dia_mov` varchar(20) DEFAULT NULL,
  `hora_mov` int(20) DEFAULT NULL,
  `codmotv` varchar(50) DEFAULT NULL,
  `desmotv` varchar(50) DEFAULT NULL,
  `tipreqfin` varchar(50) DEFAULT NULL,
  `destipreqfin` varchar(50) DEFAULT NULL,
  `tipave` varchar(50) DEFAULT NULL,
  `des_cod_liq` varchar(50) DEFAULT NULL,
  `codprbave` varchar(50) DEFAULT NULL,
  `desc_cod_det` varchar(50) DEFAULT NULL,
  `codmotvot` varchar(50) DEFAULT NULL,
  `desmotv2` varchar(50) DEFAULT NULL,
  `codtecliq` varchar(50) DEFAULT NULL,
  `nomtec` varchar(50) DEFAULT NULL,
  `desobsordtrab` varchar(50) DEFAULT NULL,
  `desobsordtrab_2` varchar(50) DEFAULT NULL,
  `canttroba` int(11) DEFAULT NULL,
  UNIQUE KEY `NewIndex4` (`codreq`),
  KEY `NewIndex1` (`codcli`),
  KEY `NewIndex2` (`codnod`),
  KEY `NewIndex3` (`nroplano`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `averias_catv_det`
--

DROP TABLE IF EXISTS `averias_catv_det`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `averias_catv_det` (
  `codofcadm` varchar(3) DEFAULT NULL,
  `codreq` int(16) DEFAULT NULL,
  `codclasrv` int(16) DEFAULT NULL,
  `fecreg` varchar(20) DEFAULT NULL,
  `estado` varchar(80) DEFAULT NULL,
  `codcli` int(20) DEFAULT NULL,
  `codnod` varchar(10) DEFAULT NULL,
  `nroplano` varchar(10) DEFAULT NULL,
  `codlex` char(0) CHARACTER SET utf8 NOT NULL,
  `codmotv` varchar(50) DEFAULT NULL,
  `desmotv` varchar(50) DEFAULT NULL,
  `tipreqfin` varchar(50) DEFAULT NULL,
  `destipreqfin` varchar(50) DEFAULT NULL,
  `desobsordtrab` varchar(50) DEFAULT NULL,
  `desobsordtrab_2` varchar(50) DEFAULT NULL,
  UNIQUE KEY `codreq` (`codreq`),
  KEY `codnod` (`codnod`),
  KEY `codcli` (`codcli`),
  KEY `nroplano` (`nroplano`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bitacora_torre`
--

DROP TABLE IF EXISTS `bitacora_torre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bitacora_torre` (
  `jefatura` varchar(50) NOT NULL,
  `nodo` varchar(2) NOT NULL,
  `troba` varchar(4) NOT NULL,
  `consultas` int(11) DEFAULT NULL,
  `averias` int(11) DEFAULT NULL,
  `ultreq` varchar(20) DEFAULT NULL,
  `codmasiva` int(11) NOT NULL,
  `trabprog` varchar(1000) NOT NULL,
  `estado` varchar(100) NOT NULL,
  `observacion` varchar(1000) NOT NULL,
  `fechahoragest` varchar(20) NOT NULL,
  `usuario` varchar(40) NOT NULL,
  `fecha_update` varchar(20) DEFAULT NULL,
  `porc_caida` varchar(20) DEFAULT NULL,
  `serv_afectado` varchar(20) DEFAULT NULL,
  KEY `jefatura_2` (`jefatura`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `usuario` (`usuario`),
  KEY `estado` (`estado`),
  KEY `nodo_2` (`nodo`,`troba`,`codmasiva`,`estado`,`observacion`(767),`usuario`,`fechahoragest`,`jefatura`,`trabprog`(767))
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bitacora_torre_d`
--

DROP TABLE IF EXISTS `bitacora_torre_d`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bitacora_torre_d` (
  `jefatura` varchar(50) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `consultas` int(11) DEFAULT NULL,
  `averias` int(11) DEFAULT NULL,
  `ultreq` varchar(20) DEFAULT NULL,
  `codmasiva` int(11) DEFAULT NULL,
  `trabprog` varchar(1000) DEFAULT NULL,
  `estado` varchar(100) DEFAULT NULL,
  `observacion` varchar(1000) DEFAULT NULL,
  `fechahoragest` varchar(20) DEFAULT NULL,
  `usuario` varchar(40) DEFAULT NULL,
  `fecha_update` varchar(20) DEFAULT NULL,
  KEY `jefatura_2` (`jefatura`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `usuario` (`usuario`),
  KEY `estado` (`estado`),
  KEY `jefatura` (`jefatura`,`nodo`,`troba`,`codmasiva`,`trabprog`(767),`estado`,`observacion`(767),`usuario`,`fechahoragest`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `caidas_c`
--

DROP TABLE IF EXISTS `caidas_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caidas_c` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `cancli` int(11) DEFAULT NULL,
  `offline` int(11) DEFAULT NULL,
  `umbral` int(11) DEFAULT NULL,
  `Caida` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `tiempo` varchar(8) DEFAULT NULL,
  `fecha_fin` varchar(20) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fecha_hora` (`fecha_hora`),
  KEY `nodo_2` (`nodo`,`troba`,`fecha_hora`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `caidas_cms`
--

DROP TABLE IF EXISTS `caidas_cms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caidas_cms` (
  `nodo` varchar(4) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `cancli` int(11) DEFAULT NULL,
  `offline` int(11) DEFAULT NULL,
  `umbral` int(11) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `tiempo` int(11) DEFAULT NULL,
  `fecha_fin` varchar(20) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `nodo_2` (`nodo`,`troba`,`fecha_hora`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `caidas_historico`
--

DROP TABLE IF EXISTS `caidas_historico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caidas_historico` (
  `jefatura` varchar(20) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `cancli` int(11) DEFAULT NULL,
  `offline` int(11) DEFAULT NULL,
  `codmasiva` int(11) DEFAULT NULL,
  `umbral` int(11) DEFAULT NULL,
  `Caida` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `tiempo` varchar(8) DEFAULT NULL,
  `ncaidas` int(11) DEFAULT NULL,
  `numbor` int(11) DEFAULT NULL,
  `fecha_fin` varchar(20) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `tc` varchar(2) DEFAULT NULL,
  UNIQUE KEY `nodo_2` (`nodo`,`troba`,`fecha_hora`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fecha_hora` (`fecha_hora`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `caidas_new`
--

DROP TABLE IF EXISTS `caidas_new`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caidas_new` (
  `jefatura` varchar(20) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplif` varchar(10) DEFAULT NULL,
  `cancli` int(11) DEFAULT NULL,
  `offline` int(11) DEFAULT NULL,
  `codmasiva` int(11) DEFAULT NULL,
  `umbral` int(11) DEFAULT NULL,
  `Caida` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `tiempo` varchar(10) DEFAULT NULL,
  `ncaidas` int(11) DEFAULT NULL,
  `numbor` int(11) DEFAULT NULL,
  `fecha_fin` varchar(20) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `tc` varchar(2) DEFAULT NULL,
  `digi` varchar(100) DEFAULT NULL,
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fecha_hora` (`fecha_hora`),
  KEY `nodo_2` (`nodo`,`troba`,`fecha_hora`),
  KEY `cancli` (`cancli`),
  KEY `Caida` (`Caida`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `caidas_new_amplif`
--

DROP TABLE IF EXISTS `caidas_new_amplif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caidas_new_amplif` (
  `jefatura` varchar(20) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplificador` varchar(3) DEFAULT NULL,
  `cancli` int(11) DEFAULT NULL,
  `offline` int(11) DEFAULT NULL,
  `codmasiva` int(11) DEFAULT NULL,
  `umbral` int(11) DEFAULT NULL,
  `Caida` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `tiempo` varchar(10) DEFAULT NULL,
  `ncaidas` int(11) DEFAULT NULL,
  `numbor` int(11) DEFAULT NULL,
  `fecha_fin` varchar(20) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `tc` varchar(2) DEFAULT NULL,
  `digi` varchar(100) DEFAULT NULL,
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fecha_hora` (`fecha_hora`),
  KEY `nodo_2` (`nodo`,`troba`,`fecha_hora`),
  KEY `cancli` (`cancli`),
  KEY `amplificador` (`amplificador`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `caidas_t`
--

DROP TABLE IF EXISTS `caidas_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caidas_t` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplif` varchar(10) DEFAULT NULL,
  `cancli` int(11) DEFAULT NULL,
  `offline` int(11) DEFAULT NULL,
  `umbral` int(11) DEFAULT NULL,
  `Caida` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `tiempo` varchar(20) DEFAULT NULL,
  `fecha_fin` varchar(20) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  UNIQUE KEY `nodo_2` (`nodo`,`troba`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fecha_hora` (`fecha_hora`),
  KEY `cancli` (`cancli`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `caidas_t_amplif`
--

DROP TABLE IF EXISTS `caidas_t_amplif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caidas_t_amplif` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplificador` varchar(3) DEFAULT NULL,
  `cancli` int(11) DEFAULT NULL,
  `offline` int(11) DEFAULT NULL,
  `umbral` int(11) DEFAULT NULL,
  `Caida` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `tiempo` varchar(20) DEFAULT NULL,
  `fecha_fin` varchar(20) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  UNIQUE KEY `nodo_2` (`nodo`,`troba`,`amplificador`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fecha_hora` (`fecha_hora`),
  KEY `amplificador` (`amplificador`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `caidastemp_c`
--

DROP TABLE IF EXISTS `caidastemp_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caidastemp_c` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplif` varchar(10) DEFAULT NULL,
  `cancli` int(11) DEFAULT NULL,
  `offline` int(11) DEFAULT NULL,
  `umbral` int(11) DEFAULT NULL,
  `Caida` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `tiempo` varchar(10) DEFAULT NULL,
  `fecha_fin` varchar(20) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fecha_hora` (`fecha_hora`),
  KEY `nodo_2` (`nodo`,`troba`,`fecha_hora`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `caidastemp_c_amplif`
--

DROP TABLE IF EXISTS `caidastemp_c_amplif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caidastemp_c_amplif` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplificador` varchar(3) DEFAULT NULL,
  `cancli` int(11) DEFAULT NULL,
  `offline` int(11) DEFAULT NULL,
  `umbral` int(11) DEFAULT NULL,
  `Caida` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `tiempo` varchar(10) DEFAULT NULL,
  `fecha_fin` varchar(20) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fecha_hora` (`fecha_hora`),
  KEY `nodo_2` (`nodo`,`troba`,`fecha_hora`),
  KEY `amplificador` (`amplificador`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `clientes_alertados`
--

DROP TABLE IF EXISTS `clientes_alertados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes_alertados` (
  `IDCLIENTECRM` double DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `tipo` varchar(40) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mactate` varchar(20) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplificador` varchar(4) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  UNIQUE KEY `MACADDRESS` (`MACADDRESS`),
  KEY `IDCLIENTECRM` (`IDCLIENTECRM`),
  KEY `tipo` (`tipo`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `amplificador` (`amplificador`),
  KEY `fecha_hora` (`fecha_hora`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `clientes_alertados_c`
--

DROP TABLE IF EXISTS `clientes_alertados_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes_alertados_c` (
  `IDCLIENTECRM` double DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `tipo` varchar(40) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mactate` varchar(20) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplificador` varchar(4) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  UNIQUE KEY `IDCLIENTECRM` (`MACADDRESS`),
  KEY `MACADDRESS` (`MACADDRESS`),
  KEY `tipo` (`tipo`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `amplificador` (`amplificador`),
  KEY `fecha_hora` (`fecha_hora`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `clientes_alertados_hist`
--

DROP TABLE IF EXISTS `clientes_alertados_hist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes_alertados_hist` (
  `IDCLIENTECRM` double DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `tipo` varchar(40) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mactate` varchar(20) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplificador` varchar(4) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  KEY `IDCLIENTECRM` (`IDCLIENTECRM`),
  KEY `MACADDRESS` (`MACADDRESS`),
  KEY `tipo` (`tipo`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `amplificador` (`amplificador`),
  KEY `fecha_hora` (`fecha_hora`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `clixamplif`
--

DROP TABLE IF EXISTS `clixamplif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clixamplif` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplificador` varchar(4) DEFAULT NULL,
  `tot` int(11) DEFAULT NULL,
  UNIQUE KEY `nodo_2` (`nodo`,`troba`,`amplificador`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `amplificador` (`amplificador`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `detalle_caidas_energia`
--

DROP TABLE IF EXISTS `detalle_caidas_energia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_caidas_energia` (
  `idclientecrm` double DEFAULT NULL,
  `nameclient` varchar(100) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `f_v` varchar(20) DEFAULT NULL,
  `macaddress` varchar(20) DEFAULT NULL,
  `macstate` varchar(20) DEFAULT NULL,
  `fecha_hora_caida` varchar(20) DEFAULT NULL,
  `estado` varchar(30) DEFAULT NULL,
  `fecha_hora_gest` varchar(20) DEFAULT NULL,
  UNIQUE KEY `idclientecrm` (`idclientecrm`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `excep_alert`
--

DROP TABLE IF EXISTS `excep_alert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `excep_alert` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  UNIQUE KEY `nodo` (`nodo`,`troba`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `excep_alert_c`
--

DROP TABLE IF EXISTS `excep_alert_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `excep_alert_c` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `geoalertas_estados`
--

DROP TABLE IF EXISTS `geoalertas_estados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geoalertas_estados` (
  `idestado` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `estado` varchar(50) DEFAULT NULL,
  `atendida` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `activo` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`idestado`)
) ENGINE=Aria AUTO_INCREMENT=58 DEFAULT CHARSET=latin1 PAGE_CHECKSUM=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gestion_alert`
--

DROP TABLE IF EXISTS `gestion_alert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gestion_alert` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  `observaciones` varchar(500) DEFAULT NULL,
  `usuario` varchar(50) DEFAULT NULL,
  `tecnico` varchar(100) DEFAULT NULL,
  `estado` varchar(30) DEFAULT NULL,
  `porc_caida` varchar(10) DEFAULT NULL,
  `serv_afectado` varchar(100) DEFAULT NULL,
  `numreq` int(11) DEFAULT NULL,
  `remedy` varchar(30) DEFAULT NULL,
  `idcausalert` int(11) DEFAULT NULL,
  `idarearesponsable` int(11) DEFAULT NULL,
  UNIQUE KEY `nodo_2` (`nodo`,`troba`,`fechahora`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fechahora` (`fechahora`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gestion_alert_backup`
--

DROP TABLE IF EXISTS `gestion_alert_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gestion_alert_backup` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  `observaciones` varchar(500) DEFAULT NULL,
  `usuario` varchar(50) DEFAULT NULL,
  `tecnico` varchar(100) DEFAULT NULL,
  `estado` varchar(30) DEFAULT NULL,
  `porc_caida` varchar(10) DEFAULT NULL,
  `serv_afectado` varchar(100) DEFAULT NULL,
  `numreq` int(11) DEFAULT NULL,
  `remedy` varchar(30) DEFAULT NULL,
  `idcausalert` int(11) DEFAULT NULL,
  `idarearesponsable` int(11) DEFAULT NULL,
  UNIQUE KEY `nodo_2` (`nodo`,`troba`,`fechahora`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fechahora` (`fechahora`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gestion_consultas`
--

DROP TABLE IF EXISTS `gestion_consultas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gestion_consultas` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  `observaciones` varchar(500) DEFAULT NULL,
  `usuario` varchar(40) DEFAULT NULL,
  `tecnico` varchar(150) DEFAULT NULL,
  `estado` varchar(40) DEFAULT NULL,
  UNIQUE KEY `nodo_2` (`nodo`,`troba`,`fechahora`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `interfaces_phy`
--

DROP TABLE IF EXISTS `interfaces_phy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `interfaces_phy` (
  `cmts` varchar(20) DEFAULT NULL,
  `interface` varchar(20) DEFAULT NULL,
  `powerup_max` double(19,2) DEFAULT NULL,
  `powerup_prom` double(19,2) DEFAULT NULL,
  `powerup_min` double(19,2) DEFAULT NULL,
  `powerds_max` double(19,2) DEFAULT NULL,
  `powerds_prom` double(19,2) DEFAULT NULL,
  `powerds_min` double(19,2) DEFAULT NULL,
  `snr_avg` double(19,2) DEFAULT NULL,
  `snr_down` double(19,2) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `fecha_hora_f` char(0) CHARACTER SET utf8 NOT NULL,
  UNIQUE KEY `cmts` (`cmts`,`interface`,`fecha_hora`),
  KEY `cmts_2` (`cmts`),
  KEY `interface` (`interface`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `llamadashfc`
--

DROP TABLE IF EXISTS `llamadashfc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `llamadashfc` (
  `idclientecrm` double DEFAULT NULL,
  `idproducto` double DEFAULT NULL,
  `codnod` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplificador` varchar(11) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `f_v` varchar(20) DEFAULT NULL,
  `De` int(11) DEFAULT NULL,
  `Day` varchar(20) DEFAULT NULL,
  `Hora` varchar(5) DEFAULT NULL,
  UNIQUE KEY `De_2` (`De`,`Day`,`Hora`),
  KEY `De` (`De`),
  KEY `idclientecrm` (`idclientecrm`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `masivas_catv`
--

DROP TABLE IF EXISTS `masivas_catv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `masivas_catv` (
  `zonal` varchar(3) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `cant` bigint(21) NOT NULL,
  `codmasiva` int(11) DEFAULT NULL,
  `fecha_hora` datetime NOT NULL,
  `trabprog` varchar(53) DEFAULT NULL,
  `tipotrab` varchar(200) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL,
  KEY `zonal` (`zonal`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `masivas_catv_c`
--

DROP TABLE IF EXISTS `masivas_catv_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `masivas_catv_c` (
  `zonal` varchar(3) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `cant` bigint(21) NOT NULL,
  `codmasiva` int(11) DEFAULT NULL,
  `fecha_hora` datetime NOT NULL,
  `trabprog` varchar(53) DEFAULT NULL,
  `tipotrab` varchar(200) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL,
  KEY `zonal` (`zonal`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `masivas_temp`
--

DROP TABLE IF EXISTS `masivas_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `masivas_temp` (
  `check` int(11) NOT NULL AUTO_INCREMENT,
  `numfrecave` int(11) NOT NULL,
  `tipfrecave` varchar(2) DEFAULT NULL,
  `fecreg` varchar(20) DEFAULT NULL,
  `codofcadm` varchar(3) DEFAULT NULL,
  `codcmts` varchar(1) DEFAULT NULL,
  `codnod` varchar(2) NOT NULL,
  `nroplano` varchar(4) NOT NULL,
  `codtrtrn` varchar(4) DEFAULT NULL,
  `edofrecave` varchar(1) DEFAULT NULL,
  `cantreq` int(11) DEFAULT NULL,
  `nrocant` int(11) DEFAULT NULL,
  `fecultact` varchar(20) DEFAULT NULL,
  `coddpt` varchar(3) DEFAULT NULL,
  `codpvc` varchar(3) DEFAULT NULL,
  `codreqmnt` int(11) NOT NULL,
  `codctr` int(11) DEFAULT NULL,
  `codedo` varchar(1) DEFAULT NULL,
  `fecliq` varchar(20) DEFAULT NULL,
  `indorigreq` varchar(1) DEFAULT NULL,
  `cantreqliq` int(11) DEFAULT NULL,
  `codareahbl` varchar(10) DEFAULT NULL,
  `indactuacion` varchar(10) DEFAULT NULL,
  `indseginc` int(11) DEFAULT NULL,
  `indinc` int(11) DEFAULT NULL,
  `codinc` varchar(10) DEFAULT NULL,
  `fecha_upload` varchar(20) DEFAULT NULL,
  UNIQUE KEY `NewIndex4` (`codnod`,`nroplano`),
  KEY `NewIndex1` (`codnod`),
  KEY `NewIndex2` (`nroplano`),
  KEY `NewIndex3` (`fecreg`),
  KEY `check` (`check`)
) ENGINE=InnoDB AUTO_INCREMENT=8922133 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `niveles_new`
--

DROP TABLE IF EXISTS `niveles_new`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `niveles_new` (
  `jefatura` varchar(50) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `tc` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `codmasiva` int(11) DEFAULT NULL,
  `RxPwrdBmv` varchar(6) DEFAULT NULL,
  `pwr_up` varchar(6) DEFAULT NULL,
  `snr_up` varchar(6) DEFAULT NULL,
  `pwr_dn` varchar(6) DEFAULT NULL,
  `snr_dn` varchar(6) DEFAULT NULL,
  `can` int(11) DEFAULT NULL,
  `ncaidas` int(11) DEFAULT NULL,
  `numbor` int(11) DEFAULT NULL,
  `fecha_fin` varchar(20) DEFAULT NULL,
  `caida` varchar(2) DEFAULT NULL,
  UNIQUE KEY `jefatura` (`nodo`,`troba`,`caida`,`fecha_hora`),
  KEY `jefatura_2` (`jefatura`),
  KEY `nodo` (`nodo`),
  KEY `caida` (`caida`),
  KEY `troba` (`troba`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `niveles_new_c`
--

DROP TABLE IF EXISTS `niveles_new_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `niveles_new_c` (
  `jefatura` varchar(50) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `tc` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `codmasiva` int(11) DEFAULT NULL,
  `RxPwrdBmv` varchar(6) DEFAULT NULL,
  `pwr_up` varchar(6) DEFAULT NULL,
  `snr_up` varchar(6) DEFAULT NULL,
  `pwr_dn` varchar(6) DEFAULT NULL,
  `snr_dn` varchar(6) DEFAULT NULL,
  `can` int(11) DEFAULT NULL,
  `ncaidas` int(11) DEFAULT NULL,
  `numbor` int(11) DEFAULT NULL,
  `fecha_fin` varchar(20) DEFAULT NULL,
  `caida` varchar(2) DEFAULT NULL,
  UNIQUE KEY `jefatura` (`nodo`,`troba`,`can`,`fecha_hora`),
  KEY `jefatura_2` (`jefatura`),
  KEY `nodo` (`nodo`),
  KEY `caida` (`caida`),
  KEY `troba` (`troba`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nivelestemp`
--

DROP TABLE IF EXISTS `nivelestemp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nivelestemp` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `RxPwrdBmv` double(19,2) DEFAULT NULL,
  `SNR_DN` double(19,2) DEFAULT NULL,
  `PWR_DN` double(19,2) DEFAULT NULL,
  `SNR_UP` double(19,2) DEFAULT NULL,
  `PWR_UP` double(19,2) DEFAULT NULL,
  `cant` bigint(21) NOT NULL,
  `fecha_hora` datetime NOT NULL,
  `fecha_fin` char(0) CHARACTER SET utf8 NOT NULL,
  `tiempo` char(0) CHARACTER SET utf8 NOT NULL,
  `caida` varchar(2) CHARACTER SET utf8 NOT NULL,
  UNIQUE KEY `nodo_2` (`nodo`,`troba`,`fecha_hora`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fecha_hora` (`fecha_hora`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nivelestemp_c`
--

DROP TABLE IF EXISTS `nivelestemp_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nivelestemp_c` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `RxPwrdBmv` double(19,2) DEFAULT NULL,
  `SNR_DN` double(19,2) DEFAULT NULL,
  `PWR_DN` double(19,2) DEFAULT NULL,
  `SNR_UP` double(19,2) DEFAULT NULL,
  `PWR_UP` double(19,2) DEFAULT NULL,
  `cant` bigint(21) NOT NULL,
  `fecha_hora` datetime NOT NULL,
  `fecha_fin` char(0) CHARACTER SET utf8 NOT NULL,
  `tiempo` char(0) CHARACTER SET utf8 NOT NULL,
  `caida` varchar(2) CHARACTER SET utf8 NOT NULL,
  UNIQUE KEY `nodo_2` (`nodo`,`troba`,`fecha_hora`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fecha_hora` (`fecha_hora`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nivelestempxamplif`
--

DROP TABLE IF EXISTS `nivelestempxamplif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nivelestempxamplif` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplificador` varchar(3) DEFAULT NULL,
  `RxPwrdBmv` double(19,2) DEFAULT NULL,
  `SNR_DN` double(19,2) DEFAULT NULL,
  `PWR_DN` double(19,2) DEFAULT NULL,
  `SNR_UP` double(19,2) DEFAULT NULL,
  `PWR_UP` double(19,2) DEFAULT NULL,
  `cant` bigint(21) NOT NULL,
  `fecha_hora` datetime NOT NULL,
  `fecha_fin` char(0) CHARACTER SET utf8 NOT NULL,
  `tiempo` char(0) CHARACTER SET utf8 NOT NULL,
  `caida` varchar(2) CHARACTER SET utf8 NOT NULL,
  UNIQUE KEY `nodo_2` (`nodo`,`troba`,`fecha_hora`,`amplificador`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fecha_hora` (`fecha_hora`),
  KEY `amplificador` (`amplificador`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nivelestempxamplif_c`
--

DROP TABLE IF EXISTS `nivelestempxamplif_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nivelestempxamplif_c` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplificador` varchar(3) DEFAULT NULL,
  `RxPwrdBmv` double(19,2) DEFAULT NULL,
  `SNR_DN` double(19,2) DEFAULT NULL,
  `PWR_DN` double(19,2) DEFAULT NULL,
  `SNR_UP` double(19,2) DEFAULT NULL,
  `PWR_UP` double(19,2) DEFAULT NULL,
  `cant` bigint(21) NOT NULL,
  `fecha_hora` datetime NOT NULL,
  `fecha_fin` char(0) CHARACTER SET utf8 NOT NULL,
  `tiempo` char(0) CHARACTER SET utf8 NOT NULL,
  `caida` varchar(2) CHARACTER SET utf8 NOT NULL,
  UNIQUE KEY `nodo_2` (`nodo`,`troba`,`fecha_hora`,`amplificador`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fecha_hora` (`fecha_hora`),
  KEY `amplificador` (`amplificador`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nivelesxmac`
--

DROP TABLE IF EXISTS `nivelesxmac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nivelesxmac` (
  `macaddress` varchar(20) DEFAULT NULL,
  `RxPwrdBmv` int(11) DEFAULT NULL,
  `SNR_DN` int(11) DEFAULT NULL,
  `PWR_DN` int(11) DEFAULT NULL,
  `SNR_UP` int(11) DEFAULT NULL,
  `PWR_UP` int(11) DEFAULT NULL,
  UNIQUE KEY `macaddress` (`macaddress`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `offline_total`
--

DROP TABLE IF EXISTS `offline_total`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offline_total` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplif` varchar(3) DEFAULT NULL,
  `cancli` int(11) DEFAULT NULL,
  `offline` int(11) DEFAULT NULL,
  `umbral` int(11) DEFAULT NULL,
  `Caida` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `tiempo` int(11) DEFAULT NULL,
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fecha_hora` (`fecha_hora`),
  KEY `nodo_2` (`nodo`,`troba`,`fecha_hora`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `offxamplif`
--

DROP TABLE IF EXISTS `offxamplif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offxamplif` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplificador` varchar(4) DEFAULT NULL,
  `cant` int(11) DEFAULT NULL,
  UNIQUE KEY `nodo_2` (`nodo`,`troba`,`amplificador`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `amplificador` (`amplificador`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `offxamplif_f`
--

DROP TABLE IF EXISTS `offxamplif_f`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offxamplif_f` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplificador` varchar(4) DEFAULT NULL,
  `offline` int(11) DEFAULT NULL,
  `tot` int(11) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `fecha_fin` varchar(20) DEFAULT NULL,
  `tiempo` varchar(20) DEFAULT NULL,
  UNIQUE KEY `nodo_2` (`nodo`,`troba`,`amplificador`,`fecha_hora`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `amplificador` (`amplificador`),
  KEY `fecha_hora` (`fecha_hora`),
  KEY `estado` (`estado`),
  KEY `fecha_fin` (`fecha_fin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `offxamplif_t`
--

DROP TABLE IF EXISTS `offxamplif_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offxamplif_t` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplificador` varchar(4) DEFAULT NULL,
  `offline` int(11) DEFAULT NULL,
  `tot` int(11) DEFAULT NULL,
  UNIQUE KEY `nodo_2` (`nodo`,`troba`,`amplificador`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `amplificador` (`amplificador`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `puertos_down_saturados`
--

DROP TABLE IF EXISTS `puertos_down_saturados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `puertos_down_saturados` (
  `cmts` varchar(50) DEFAULT NULL,
  `down` varchar(10) DEFAULT NULL,
  `cant` int(11) DEFAULT NULL,
  `fecini` varchar(20) DEFAULT NULL,
  `saturado` varchar(20) DEFAULT NULL,
  `fecfin` varchar(20) DEFAULT NULL,
  `rangosat` varchar(20) DEFAULT NULL,
  UNIQUE KEY `cmts_2` (`cmts`,`down`),
  KEY `cmts` (`cmts`),
  KEY `down` (`down`),
  KEY `fecini` (`fecini`),
  KEY `rangosat` (`rangosat`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `puertos_down_saturados_60_70`
--

DROP TABLE IF EXISTS `puertos_down_saturados_60_70`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `puertos_down_saturados_60_70` (
  `cmts` varchar(50) DEFAULT NULL,
  `down` varchar(10) DEFAULT NULL,
  `cant` int(11) DEFAULT NULL,
  `fecini` varchar(20) DEFAULT NULL,
  `saturado` varchar(20) DEFAULT NULL,
  `fecfin` varchar(20) DEFAULT NULL,
  UNIQUE KEY `cmts_2` (`cmts`,`down`,`fecini`),
  KEY `cmts` (`cmts`),
  KEY `down` (`down`),
  KEY `fecini` (`fecini`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `puertos_down_saturados_70_80`
--

DROP TABLE IF EXISTS `puertos_down_saturados_70_80`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `puertos_down_saturados_70_80` (
  `cmts` varchar(50) DEFAULT NULL,
  `down` varchar(10) DEFAULT NULL,
  `cant` int(11) DEFAULT NULL,
  `fecini` varchar(20) DEFAULT NULL,
  `saturado` varchar(20) DEFAULT NULL,
  `fecfin` varchar(20) DEFAULT NULL,
  UNIQUE KEY `cmts_2` (`cmts`,`down`,`fecini`),
  KEY `cmts` (`cmts`),
  KEY `down` (`down`),
  KEY `fecini` (`fecini`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `puertos_down_saturados_80_90`
--

DROP TABLE IF EXISTS `puertos_down_saturados_80_90`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `puertos_down_saturados_80_90` (
  `cmts` varchar(50) DEFAULT NULL,
  `down` varchar(10) DEFAULT NULL,
  `cant` int(11) DEFAULT NULL,
  `fecini` varchar(20) DEFAULT NULL,
  `saturado` varchar(20) DEFAULT NULL,
  `fecfin` varchar(20) DEFAULT NULL,
  UNIQUE KEY `cmts_2` (`cmts`,`down`,`fecini`),
  KEY `cmts` (`cmts`),
  KEY `down` (`down`),
  KEY `fecini` (`fecini`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `puertos_down_saturados_90_100`
--

DROP TABLE IF EXISTS `puertos_down_saturados_90_100`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `puertos_down_saturados_90_100` (
  `cmts` varchar(50) DEFAULT NULL,
  `down` varchar(10) DEFAULT NULL,
  `cant` int(11) DEFAULT NULL,
  `fecini` varchar(20) DEFAULT NULL,
  `saturado` varchar(20) DEFAULT NULL,
  `fecfin` varchar(20) DEFAULT NULL,
  UNIQUE KEY `cmts_2` (`cmts`,`down`,`fecini`),
  KEY `cmts` (`cmts`),
  KEY `down` (`down`),
  KEY `fecini` (`fecini`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resumen_nivelesxtroba_c`
--

DROP TABLE IF EXISTS `resumen_nivelesxtroba_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resumen_nivelesxtroba_c` (
  `nodo` varchar(10) DEFAULT NULL,
  `troba` varchar(10) DEFAULT NULL,
  `RxPwrdBmv` varchar(20) DEFAULT NULL,
  `SNR_DN` varchar(20) DEFAULT NULL,
  `PWR_DN` varchar(20) DEFAULT NULL,
  `SNR_UP` varchar(20) DEFAULT NULL,
  `PWR_UP` varchar(20) DEFAULT NULL,
  `cant` varchar(20) DEFAULT NULL,
  `fecha_hora` varchar(30) DEFAULT NULL,
  `fecha_fin` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `tiempo` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `caida` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  UNIQUE KEY `nodo_2` (`nodo`,`troba`,`fecha_hora`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fecha_hora` (`fecha_hora`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tecnicos`
--

DROP TABLE IF EXISTS `tecnicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tecnicos` (
  `item` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `empresa` varchar(30) DEFAULT NULL,
  `ruta` varchar(20) DEFAULT NULL,
  `dni` varchar(10) DEFAULT NULL,
  `nombre1` varchar(100) DEFAULT NULL,
  `rpm1` varchar(10) DEFAULT NULL,
  `nombre2` varchar(100) DEFAULT NULL,
  `rpm2` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`item`),
  KEY `NewIndex2` (`empresa`),
  KEY `NewIndex1` (`dni`),
  KEY `NewIndex3` (`nombre1`),
  KEY `NewIndex4` (`rpm1`),
  KEY `NewIndex5` (`nombre2`),
  KEY `NewIndex6` (`rpm2`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `umbral_m`
--

DROP TABLE IF EXISTS `umbral_m`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umbral_m` (
  `reg` int(11) NOT NULL,
  `porc` int(11) DEFAULT NULL,
  `dia` int(11) DEFAULT NULL,
  `dia1` int(11) DEFAULT NULL,
  `noche` int(11) DEFAULT NULL,
  `noche1` int(11) DEFAULT NULL,
  PRIMARY KEY (`reg`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `umbral_m_amplif`
--

DROP TABLE IF EXISTS `umbral_m_amplif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umbral_m_amplif` (
  `reg` int(11) NOT NULL,
  `porc` int(11) DEFAULT NULL,
  `dia` int(11) DEFAULT NULL,
  `dia1` int(11) DEFAULT NULL,
  `noche` int(11) DEFAULT NULL,
  `noche1` int(11) DEFAULT NULL,
  PRIMARY KEY (`reg`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `umbral_troba`
--

DROP TABLE IF EXISTS `umbral_troba`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umbral_troba` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `dia` int(11) DEFAULT NULL,
  `noche` int(11) DEFAULT NULL,
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `umbral_troba_amplif`
--

DROP TABLE IF EXISTS `umbral_troba_amplif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umbral_troba_amplif` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `amplificador` varchar(3) DEFAULT NULL,
  `umbral` int(11) DEFAULT NULL,
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `amplificador` (`amplificador`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'alertasx'
--
/*!50003 DROP PROCEDURE IF EXISTS `alertas_edificios` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `alertas_edificios`()
BEGIN
update alertasx.alerta_edificio_sw set sw=1,fechahora=now();
TRUNCATE TABLE trabajos.`edif_level`;
	
/*NUEVO QUERY*/
INSERT INTO trabajos.`edif_level`
	SELECT DISTINCT a.macaddress,a.`EMPRESA`,a.`IDCLIENTECRM`,a.`idempresacrm`,a.`idservicio`,a.`idproducto`,a.`idventa`,a.`NAMECLIENT`,a.`NODO`,a.`TROBA`,a.`amplificador`,a.`tap`,a.`telf1`,a.`telf2`,a.`f_v`,a.`regver`,
a.`cmts`,a.`SERVICEPACKAGECRMID`,a.`SERVICEPACKAGE`,a.`CANTPCS`,a.`FECHAALTA`,a.`FECHAACTIVACION`,a.`ESTADO`,a.`SCOPESGROUP`,a.`SCOPESGROUPCM`,a.`SCOPESGROUPMTA`,a.`MTAMAC`,a.`IDSERVICIOMTA`,a.`IDPRODUCTOMTA`,
a.`IDVENTAMTA`,a.`MTAMODELNAME`,a.`CMTSID`,a.`UBICACIONENLARED`,a.`IPCM`,a.`DOCSISVERSION`,a.`movil1`,a.`mac2`,a.`mac3`,a.`direccion`,a.`codserv`,a.`fecha_upload`,a.`naked`,a.`numcoo_x`,a.`numcoo_y`,a.`desdtt`,
a.`via`,a.`nro`,c.`USPwr`,c.`USMER_SNR`,c.`DSPwr`,c.`DSMER_SNR`,
IF((c.USPwr <=35 OR c.USPwr >=56 ) AND USPwr<>'-' ,'Niveles NO OK',
IF(c.USMER_SNR <=27 AND c.USMER_SNR >0.00 AND USPwr<>'-' ,'Niveles NO OK', 
IF((c.DSPwr <-12 OR c.DSPwr >12 ) AND USPwr<>'-','Niveles NO OK', 
IF(c.DSMER_SNR <=30 AND USPwr<>'-' ,'Niveles NO OK','OK')))) AS estado_l
FROM trabajos.`dataedif_t1` a FORCE INDEX(mac2)
INNER JOIN ccm1.scm_phy_t c FORCE INDEX(NewIndex1,DSMER_SNR)
ON a.mac2=c.`MACAddress`
WHERE c.`DSMER_SNR` NOT LIKE '--%';
	
	TRUNCATE TABLE alertasx.alertas_edificio_c;
	INSERT IGNORE alertasx.alertas_edificio_c
	(SELECT desdtt,via,nro,COUNT(*) AS cant FROM trabajos.edif_level WHERE estado_l = 'Niveles NO OK' AND nro>0 GROUP BY 1,2,3 HAVING COUNT(*)>4);
	
	
	TRUNCATE alertasx.`alertas_edificio`;
	
	INSERT IGNORE alertasx.`alertas_edificio`
	SELECT a.`desdtt`,a.`via`,a.`nro`,a.`cant`,NOW() AS `fecha_hora_ini`,'' AS `fecha_hora_fin`,'CONTINUA' AS `estado` FROM alertasx.`alertas_edificio_c` a
	GROUP BY a.desdtt,a.via,a.nro;
	
	
	UPDATE alertasx.`alertas_edificio` a FORCE INDEX(desdtt_2,via,nro) LEFT JOIN alertasx.`alertas_edificio_c` b
	ON a.desdtt=b.desdtt AND a.via=b.via AND a.nro=b.nro
	SET fecha_hora_fin = NOW(),estado='LEVANTO'
	WHERE b.desdtt IS NULL;
	
	UPDATE alertasx.`alertas_edificio` a  FORCE INDEX(desdtt_2,via,nro) LEFT JOIN alertasx.`alertas_edificio_c` b
	ON a.desdtt=b.desdtt AND a.via=b.via AND a.nro=b.nro
	SET fecha_hora_ini = NOW(),fecha_hora_fin = '',estado='CONTINUA'
	WHERE b.desdtt  IS NOT NULL AND estado='LEVANTO';
	
	UPDATE alertasx.alerta_edificio_sw SET sw=0,fechahora=NOW();
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `clientes_alertados` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`ccm1_user`@`%` PROCEDURE `clientes_alertados`()
BEGIN
	TRUNCATE TABLE `clientes_alertados_c`;
	
	INSERT IGNORE `clientes_alertados_c`
	SELECT a.`IDCLIENTECRM`,a.`MACADDRESS`,'CAIDA AMPLIF',b.macstate AS mactate,a.nodo,a.troba,c.amplificador,c.`fecha_hora` FROM ccm1.nclientes a 
	INNER JOIN alertasx.`caidas_new_amplif` c
	ON a.nodo=c.nodo AND a.troba=c.`troba` AND a.amplificador=c.amplificador  AND c.`Caida`='SI'
	LEFT JOIN ccm1.scm_total b
	ON a.`mac2`=b.`MACAddress` 
	WHERE b.macstate='offline'
	GROUP BY a.`mac2`;	
	
	INSERT IGNORE `clientes_alertados_c`
	SELECT a.`IDCLIENTECRM`,a.`MACADDRESS`,'CAIDA MASIVA',b.macstate AS mactate,a.nodo,a.troba,amplificador,c.`fecha_hora` FROM ccm1.nclientes a 
	INNER JOIN alertasx.`caidas_new` c
	ON a.nodo=c.nodo AND a.troba=c.`troba` AND c.`Caida`='SI'
	left JOIN ccm1.scm_total b
	ON a.`mac2`=b.`MACAddress` 
	WHERE b.macstate='offline'
	GROUP BY a.`mac2`;
	
	
	
	INSERT IGNORE `clientes_alertados_c`
	SELECT a.`IDCLIENTECRM`,a.`MACADDRESS`,'CAIDA SENAL','online' AS  mactate,a.nodo,a.troba,amplificador,c.`fecha_hora` FROM ccm1.nclientes a 
	INNER JOIN alertasx.`niveles_new` c
	ON a.nodo=c.nodo AND a.troba=c.`troba` 
	INNER JOIN ccm1.scm_phy_t b
	ON a.`mac2`=b.`MACAddress` 
	WHERE c.`Caida`='SI' 	
	GROUP BY a.`mac2`;
	
	INSERT IGNORE `clientes_alertados_c`
	SELECT a.`IDCLIENTECRM`,a.`MACADDRESS`,'CAIDA SENAL','online' AS  mactate,a.nodo,a.troba,amplificador,c.`fecha_hora` 
	FROM ccm1.nclientes a FORCE INDEX(NewIndex4,NODO,TROBA)
	INNER JOIN alertasx.`niveles_new` c FORCE INDEX(caida,nodo,troba)
	ON a.nodo=c.nodo AND a.troba=c.`troba` 
	INNER JOIN ccm1.scm_phy_t b FORCE INDEX(NewIndex1)
	ON a.`mac2`=b.`MACAddress` 
	WHERE a.nodo NOT LIKE '' AND a.troba NOT LIKE '' AND c.`Caida`='SI' 	
	GROUP BY a.`mac2`;
	
	rename table clientes_alertados to clientes_alertados_d,
		clientes_alertados_c to clientes_alertados,
		clientes_alertados_d to clientes_alertados_c;
	
	INSERT IGNORE `historico_nclientes`.clientes_alertados_historico 
	SELECT * FROM alertasx.`clientes_alertados` WHERE nodo IN ('LO','SI','MI');		
		
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Newalert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`rfalla`@`%` PROCEDURE `Newalert`()
BEGIN
	REPLACE catalogos.`umbral_troba`
	SELECT nodo,troba,MAX(offline*1.1),MAX(offline*1.3)
	 FROM alertasx.`alertas_reporte` 
	 WHERE estadomasiva='Clientes Apagan Mode' AND 
	 (observaciones='' OR observaciones LIKE "%descarga ok%" ) 
	 GROUP BY nodo,troba
	HAVING(COUNT(*)) > 3 ;
	
	UPDATE ccm1.nclientes a FORCE INDEX (NewIndex3)  INNER JOIN ccm1.scm_total c ON a.mac2 = c.MACAddress SET a.f_v=c.Interface,a.cmts=c.cmts WHERE a.f_v<>c.Interface;
	UPDATE ccm1.nclientes a FORCE INDEX (NewIndex3)  INNER JOIN ccm1.scm_phy_t c ON a.mac2 = c.MACAddress SET a.f_v=c.Interface,a.cmts=c.cmts WHERE a.f_v<>c.Interface AND RIGHT(a.f_v,2)='UB';
	UPDATE  ccm1.nclientes a FORCE INDEX(idxfv,cmts) INNER JOIN catalogos.etiqueta_puertos b ON a.cmts=b.cmts 
	AND a.f_v=b.interface SET a.nodo=SUBSTR(b.description,1,2),a.troba=SUBSTR(b.description,4,4) 
	WHERE  SUBSTR(b.description,1,7)<>CONCAT(a.nodo,' ',a.troba) AND ((LENGTH(TRIM(description))>=7 AND LENGTH(TRIM(description))<=9) OR RIGHT(TRIM(description),1)=')');
	
	TRUNCATE TABLE ccm1.cantroba;
	INSERT IGNORE ccm1.cantroba SELECT nodo,troba,COUNT(*) AS cant,CONCAT(nodo,troba) AS clave,now() as fechahora FROM ccm1.nclientes WHERE troba <>'' AND estado= 'Activo'  AND LENGTH(TRIM(nodo))=2 GROUP BY 1,2;
	
	TRUNCATE TABLE alertasx.caidastemp_c;
	INSERT IGNORE alertasx.caidastemp_c
	SELECT b.nodo,b.troba,'' as amplif,COUNT(*) AS cancli,SUM(IF(a.macstate='offline',1,0)) AS offline,0 AS umbral ,'' AS caida,NOW() AS fecha_hora," " AS tiempo , '' AS  fecha_fin , '' AS estado
	FROM ccm1.scm_total_f a FORCE INDEX(MACAddress)
	 INNER JOIN ccm1.nclientes b 
	ON a.macaddress=b.mac2 
	WHERE a.macaddress=b.mac2  and b.estado='Activo'
	GROUP BY 1,2;
	
	DELETE FROM `caidastemp_c` WHERE nodo='';
	
	#UPDATE alertasx.caidastemp_c a FORCE INDEX (nodo,troba) 
	#INNER JOIN ccm1.cantroba b  ON a.nodo=b.nodo AND a.troba=b.troba SET a.cancli=b.cant;	
	
	
	UPDATE alertasx.caidastemp_c a FORCE INDEX(nodo,troba) INNER JOIN alertasx.umbral_m b  ON a.cancli=b.reg
	LEFT JOIN alertasx.umbral_troba ut ON a.nodo=ut.nodo AND a.troba=ut.troba
	SET a.umbral=IF(ut.nodo IS NOT NULL,IF(SUBSTR(fecha_hora,12,2)>=22 OR SUBSTR(fecha_hora,12,2)<=8,ut.noche,ut.dia),
	IF(SUBSTR(fecha_hora,12,2)>=22 OR SUBSTR(fecha_hora,12,2)<=8,b.noche,b.dia));	
	
	
	DELETE FROM alertasx.caidastemp_c WHERE offline < umbral;
	
	UPDATE alertasx.caidastemp_c SET caida='SI' , estado='CONTINUA' WHERE offline>=umbral;
	
	UPDATE  alertasx.caidastemp_c  a INNER JOIN catalogos.umbral_troba b
	ON a.nodo=b.nodo AND a.troba=b.troba  
	SET tiempo='00:00:00',fecha_fin=fecha_hora,estado='LEVANTO',Caida='NO'
	WHERE a.offline<b.unmbral;
	
	DELETE FROM alertasx.caidastemp_c  WHERE caida<>'SI' ;
	
	DELETE FROM alertasx.caidas_t WHERE DATEDIFF(NOW(),fecha_fin)>7;
	
	UPDATE alertasx.caidas_t a FORCE INDEX (nodo,troba) LEFT JOIN alertasx.caidastemp_c b ON 
	a.nodo=b.nodo AND a.troba=b.troba 
	SET a.Caida='NO',a.fecha_fin=NOW(),a.tiempo = SUBSTR(TIMEDIFF(NOW(),a.fecha_hora),1,8),a.estado='LEVANTO'
	WHERE b.nodo IS NULL AND a.estado='CONTINUA';	
	
	
	UPDATE alertasx.caidas_t a LEFT JOIN alertasx.caidastemp_c b ON 
	a.nodo=b.nodo AND a.troba=b.troba 
	SET a.offline=b.offline,a.Caida='SI',a.fecha_fin='',a.fecha_hora=NOW(),a.tiempo = " " ,a.estado='CONTINUA'
	WHERE b.nodo IS NOT NULL AND a.estado='LEVANTO';
	
	UPDATE alertasx.caidas_t a FORCE INDEX(nodo,troba) INNER JOIN alertasx.caidastemp_c b FORCE INDEX(nodo,troba) ON 
	a.nodo=b.nodo AND a.troba=b.troba 
	SET a.offline=b.offline,a.tiempo = SUBSTR(TIMEDIFF(NOW(),a.fecha_hora),1,8) 
	WHERE a.estado='CONTINUA';
	
	INSERT IGNORE alertasx.caidas_t SELECT * FROM alertasx.caidastemp_c;	
	
	UPDATE alertasx.caidas_t a FORCE INDEX(nodo,troba) INNER JOIN ccm1.cantroba b  ON a.nodo=b.nodo AND a.troba=b.troba
	SET cancli=cant;
	UPDATE alertasx.caidas_t a FORCE INDEX (cancli) INNER JOIN alertasx.umbral_m b  ON a.cancli=b.reg
	LEFT JOIN alertasx.umbral_troba ut ON a.nodo=ut.nodo AND a.troba=ut.troba
	SET a.umbral=IF(ut.nodo IS NOT NULL,ut.noche,IF(SUBSTR(fecha_hora,12,2)>=22 OR SUBSTR(fecha_hora,12,2)<=8,b.noche,b.dia));	
	
	DELETE FROM alertasx.caidas_t WHERE offline < umbral or cancli>1600;	
	
	
	TRUNCATE TABLE alertasx.caidas_new ;
	INSERT INTO alertasx.caidas_new 
	SELECT b.jefatura ,a.nodo,a.troba,a.amplif,a.cancli,a.offline,c.codreqmnt AS codmasiva,a.umbral,Caida,
	a.fecha_hora,a.tiempo,0 AS ncaidas,d.numbor,a.fecha_fin,
	a.estado,IF(e.critica=1,'TC' ,'') AS tc,dv.MENSAJE AS digi
	FROM alertasx.caidas_t a FORCE INDEX(nodo) INNER JOIN catalogos.jefaturas b
	ON a.nodo=b.nodo
	LEFT JOIN dbpext.masivas_temp c
	ON a.nodo=c.codnod AND a.troba=c.nroplano
	LEFT JOIN catalogos.bornesxtroba d
	ON a.nodo=d.nodo AND a.troba=d.troba
	LEFT JOIN catalogos.`trobas_criticas_n` e
	ON a.nodo=e.nodo AND a.troba=e.troba
	LEFT JOIN dbpext.`digitalizacion_view` dv
	ON a.nodo=dv.nodo AND a.troba=dv.troba
	where a.cancli<1600
	GROUP BY a.nodo,a.troba
	ORDER BY estado ;
	
	#Calidas por amplificador
		
	CALL dbpext.`masivas_proc`;
	
	TRUNCATE TABLE alertasx.offline_total;
	INSERT IGNORE alertasx.offline_total 
	SELECT `nodo`,`troba`,`amplif`,`cancli`,`offline`,`umbral`,`Caida`,`fecha_hora`,`tiempo` FROM alertasx.caidas_t WHERE Caida='SI';
	
	UPDATE `alertas_reporte` SET tiempo = TIMEDIFF(fecha_fin,fecha_hora);
	
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_llamadas` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_llamadas`()
BEGIN
	#TRUNCATE TABLE alertasx.llamadashfc;
	INSERT IGNORE alertasx.llamadashfc
	SELECT b.idclientecrm,b.idproducto,b.nodo as codnod,b.troba,b.amplificador,b.cmts,b.f_v,a.`De`,a.`Day`,SUBSTR(Fecha_Inicio,12,5) AS Hora FROM catalogos.`llamadas_ivr` a FORCE INDEX(De) INNER JOIN ccm1.nclientes b FORCE INDEX(idxtelef1) 
	ON a.De =b.telf1 GROUP BY b.idclientecrm,a.De,a.Fecha_Inicio;
	INSERT IGNORE alertasx.llamadashfc
	SELECT b.idclientecrm,b.idproducto,b.nodo as codnod,b.troba,b.amplificador,b.cmts,b.f_v,a.`De`,a.`Day`,SUBSTR(Fecha_Inicio,12,5) AS Hora  FROM catalogos.`llamadas_ivr` a FORCE INDEX(De) INNER JOIN ccm1.nclientes b FORCE INDEX(idxtelef2) 
	ON a.De =b.telf2 GROUP BY b.idclientecrm,a.De,a.Fecha_Inicio;
	INSERT IGNORE alertasx.llamadashfc
	SELECT b.idclientecrm,b.idproducto,b.nodo as codnod,b.troba,b.amplificador,b.cmts,b.f_v,a.`De`,a.`Day`,SUBSTR(Fecha_Inicio,12,5) AS Hora  FROM catalogos.`llamadas_ivr` a FORCE INDEX(De) INNER JOIN ccm1.nclientes b FORCE INDEX(idxmovil) 
	ON a.De =b.movil1 GROUP BY b.idclientecrm,a.De,a.Fecha_Inicio;
	SELECT * FROM alertasx.llamadashfc a WHERE DATEDIFF(NOW(),a.Day)=0  INTO OUTFILE '/temp/llamadas_hfc.csv' FIELDS TERMINATED BY ',' LINES TERMINATED BY '\r\n';
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_NewAlertAmplif` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `SP_NewAlertAmplif`()
BEGIN
	TRUNCATE TABLE alertasx.caidastemp_c_amplif;
	INSERT IGNORE alertasx.caidastemp_c_amplif
	SELECT b.nodo,b.troba,b.amplificador,COUNT(*) AS cancli,SUM(IF(a.macstate='offline',1,0)) AS offline,0 AS umbral ,'' AS caida,NOW() AS fecha_hora," " AS tiempo , '' AS  fecha_fin , '' AS estado
	FROM ccm1.scm_total_f a INNER JOIN ccm1_temporal.nclientes b 
	ON a.macaddress=b.mac2 WHERE b.idclientecrm <>969625 AND b.idclientecrm <10000000 AND b.amplificador<>'' and b.estado ='Activo'
	GROUP BY 1,2,3
	HAVING COUNT(*)>=20;
	
	DELETE FROM `caidastemp_c_amplif` WHERE nodo='' OR offline=0;
	
	UPDATE alertasx.caidastemp_c_amplif a INNER JOIN ccm1.cantroba_amplif b  ON a.nodo=b.nodo AND a.troba=b.troba AND a.amplificador=b.amplificador 
	 SET a.cancli=b.cant;	
	
	
	UPDATE alertasx.caidastemp_c_amplif a INNER JOIN alertasx.umbral_m_amplif b  ON a.cancli=b.reg
	LEFT JOIN alertasx.umbral_troba_amplif ut ON a.nodo=ut.nodo AND a.troba=ut.troba AND a.amplificador=ut.amplificador
	SET a.umbral=IF(ut.nodo IS NOT NULL,ut.umbral,IF(SUBSTR(fecha_hora,12,2)>=22 OR SUBSTR(fecha_hora,12,2)<=8,noche,dia));	
	
	
	DELETE FROM alertasx.caidastemp_c_amplif WHERE offline < umbral OR umbral=0;
	
	UPDATE alertasx.caidastemp_c_amplif SET caida='SI' , estado='CONTINUA' WHERE offline>=umbral;
	
	DELETE FROM alertasx.caidastemp_c_amplif  WHERE caida<>'SI' ;
	
	
	
	UPDATE alertasx.caidas_t_amplif a LEFT JOIN alertasx.caidastemp_c_amplif b ON 
	a.nodo=b.nodo AND a.troba=b.troba   AND a.amplificador=b.amplificador 
	SET a.Caida='NO',a.fecha_fin=NOW(),a.tiempo = SUBSTR(TIMEDIFF(NOW(),a.fecha_hora),1,8),a.estado='LEVANTO'
	WHERE b.nodo IS NULL AND a.estado='CONTINUA';	
	
	
	UPDATE alertasx.caidas_t_amplif a LEFT JOIN alertasx.caidastemp_c_amplif b ON 
	a.nodo=b.nodo AND a.troba=b.troba AND a.amplificador=b.amplificador 
	SET a.Caida='SI',a.fecha_fin='',a.fecha_hora=NOW(),a.tiempo = " " ,a.estado='CONTINUA'
	WHERE b.nodo IS NOT NULL AND a.estado='LEVANTO';
	
	
	INSERT IGNORE alertasx.caidas_t_amplif SELECT * FROM alertasx.caidastemp_c_amplif;	
	
	UPDATE alertasx.caidas_t_amplif a INNER JOIN ccm1.cantroba_amplif b  ON a.nodo=b.nodo AND a.troba=b.troba AND  a.amplificador=b.amplificador
	SET a.cancli=b.cant;
	
	UPDATE alertasx.caidas_t_amplif a INNER JOIN alertasx.umbral_m_amplif b  ON a.cancli=b.reg
	LEFT JOIN alertasx.umbral_troba_amplif ut ON a.nodo=ut.nodo AND a.troba=ut.troba AND a.amplificador=ut.amplificador
	SET a.umbral=IF(ut.nodo IS NOT NULL,ut.umbral,IF(SUBSTR(fecha_hora,12,2)>=22 OR SUBSTR(fecha_hora,12,2)<=8,noche,dia));	
	
	DELETE FROM alertasx.caidas_t_amplif WHERE offline < umbral;	
	
	
	TRUNCATE TABLE alertasx.caidas_new_amplif ;
	INSERT INTO alertasx.caidas_new_amplif 
	SELECT CONCAT(b.jefatura,"_",b.sede) AS jefatura ,a.nodo,a.troba,a.amplificador,a.cancli,a.offline,c.codreqmnt AS codmasiva,a.umbral,a.Caida,a.fecha_hora,a.tiempo,0 AS ncaidas,d.numbor,a.fecha_fin,a.estado,IF(e.critica=1,'TC' ,'') AS tc,dv.MENSAJE AS digi
	FROM alertasx.caidas_t_amplif a INNER JOIN ccm1.zonales_nodos_eecc b
	ON a.nodo=b.nodo
	LEFT JOIN dbpext.masivas_temp c
	ON a.nodo=c.codnod AND a.troba=c.nroplano
	LEFT JOIN catalogos.bornesxtroba d
	ON a.nodo=d.nodo AND a.troba=d.troba
	LEFT JOIN catalogos.`trobas_criticas_n` e
	ON a.nodo=e.nodo AND a.troba=e.troba
	LEFT JOIN dbpext.`digitalizacion_view` dv
	ON a.nodo=dv.nodo AND a.troba=dv.troba
	LEFT JOIN alertasx.`caidas_new` cn ON  a.nodo=cn.nodo AND a.troba=cn.troba AND cn.caida='SI'
	WHERE a.cancli>=20 AND cn.nodo IS NULL
	GROUP BY a.nodo,a.troba
	ORDER BY estado ;
	
	delete from alertasx.caidas_new_amplif where concat(nodo,troba) in (select concat(nodo,troba) from alertasx.`caidas_new` group by 1);
	
	INSERT IGNORE alertasx.`caidas_new` (SELECT `jefatura`,`nodo`,`troba`,`amplificador` AS amplif,`cancli`,`offline`,`codmasiva`,`umbral`,`Caida`,`fecha_hora`,`tiempo`,`ncaidas`,`numbor`,`fecha_fin`,`estado`,`tc`,`digi` FROM `caidas_new_amplif` WHERE DATEDIFF(NOW(),fecha_hora)<=2 GROUP BY nodo,troba,amplificador );
	
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_saturados` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`ccm1_user`@`%` PROCEDURE `sp_saturados`()
BEGIN
	TRUNCATE  alertasx.puertos_down_saturados_90_100;
	
	INSERT IGNORE alertasx.puertos_down_saturados_90_100
	SELECT cmts,down,cant,fecha_hora AS fecini,'CONTINUA' AS estado,'' AS fecfin FROM reportes.`uso_portadoras`
	WHERE  uso BETWEEN 91 AND 100  AND DATEDIFF(NOW(),fecha_hora)<=7 
	GROUP BY 1,2
	HAVING COUNT(*)>15;
	
	TRUNCATE  alertasx.puertos_down_saturados_80_90;
	
	INSERT IGNORE alertasx.puertos_down_saturados_80_90
	SELECT cmts,down,cant,fecha_hora AS fecini,'CONTINUA' AS estado,'' AS fecfin FROM reportes.`uso_portadoras`
	WHERE  uso BETWEEN 81 AND 90 AND DATEDIFF(NOW(),fecha_hora)<=7 
	GROUP BY 1,2
	HAVING COUNT(*)>15;
	
	TRUNCATE  alertasx.puertos_down_saturados_70_80;
	
	INSERT IGNORE alertasx.puertos_down_saturados_70_80
	SELECT cmts,down,cant,fecha_hora AS fecini,'CONTINUA' AS estado,'' AS fecfin FROM reportes.`uso_portadoras`
	WHERE  uso BETWEEN 71 AND 80 AND DATEDIFF(NOW(),fecha_hora)<=7 
	GROUP BY 1,2
	HAVING COUNT(*)>15;
	
	TRUNCATE  alertasx.puertos_down_saturados_60_70;
	
	INSERT IGNORE alertasx.puertos_down_saturados_60_70
	SELECT cmts,down,cant,fecha_hora AS fecini,'CONTINUA' AS estado,'' AS fecfin FROM reportes.`uso_portadoras`
	WHERE   uso BETWEEN 60 AND 70    AND DATEDIFF(NOW(),`fecha_hora`)<=7 
	GROUP BY 1,2
	HAVING COUNT(*)>15;
	
	TRUNCATE TABLE alertasx.puertos_down_saturados;
	
	INSERT IGNORE alertasx.puertos_down_saturados
	SELECT a.*,'90_100' FROM alertasx.puertos_down_saturados_90_100 a GROUP BY cmts,down;
	
	INSERT IGNORE alertasx.puertos_down_saturados
	SELECT a.*,'80_90' FROM alertasx.puertos_down_saturados_80_90 a GROUP BY cmts,down;
	
	INSERT IGNORE alertasx.puertos_down_saturados
	SELECT a.*,'70-80' FROM alertasx.puertos_down_saturados_70_80 a GROUP BY cmts,down;
	
	INSERT IGNORE alertasx.puertos_down_saturados
	SELECT a.*,'60-70' FROM alertasx.puertos_down_saturados_60_70 a GROUP BY cmts,down;
	
	/*
	TRUNCATE TABLE reportes.clientes_en_puerto_saturado;
	
	INSERT IGNORE reportes.clientes_en_puerto_saturado  
	SELECT   
	a.`IDCLIENTECRM`,
	a.`nameclient`,
	a.`direccion`,
	a.`NODO`,
	a.`TROBA`,
	a.`amplificador`,
	a.`tap`,
	a.`telf1`,
	a.`telf2`,
	a.`movil1`,
	a.`MACADDRESS`,
	a.`SERVICEPACKAGE`,
	a.`SCOPESGROUP`,
	'' AS RxPwrdBmv,
	'' AS USPwr,
	'' AS USMER_SNR,
	'' AS DSPwr,
	'' AS DSMER_SNR,
	'' AS STATUS,
	a.f_v AS `INTERFACE`,
	a.`CMTS`,
	c.`down`,
	a.`fecha_upload`
	,'PUERTO DOWN SATURADO' 
	FROM ccm1.nclientes a FORCE INDEX (idxfv,cmts)
	INNER JOIN reportes.`portadorasxpuerto_tr` c FORCE INDEX(cmts,interface)
	ON a.cmts=c.cmts AND a.f_v=c.interface  
	INNER JOIN alertasx.`puertos_down_saturados` ps FORCE INDEX(cmts,rangosat)
	ON c.cmts=ps.cmts AND REPLACE(c.down,"'","")=REPLACE(ps.down,"'","")
	WHERE a.nodo<>'' and ps.rangosat IN ('70_80','90_100','80_90') AND ps.saturado='CONTINUA'
	GROUP BY a.macaddress;
	*/
	
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `alerta_ips`
--

/*!50001 DROP TABLE IF EXISTS `alerta_ips`*/;
/*!50001 DROP VIEW IF EXISTS `alerta_ips`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `alerta_ips` AS (select `a`.`cmts` AS `cmts`,`a`.`scopesgroup` AS `scopesgroup`,`a`.`total` AS `total`,`a`.`used` AS `used`,`a`.`available` AS `available`,`a`.`porc` AS `porc`,if(((`a`.`available` < 150) and (`a`.`porc` > 90)),'red',if(((`a`.`available` >= 151) and (`a`.`available` <= 250) and (`a`.`porc` > 40)),'orange',if((`a`.`porc` < 40),'green','green'))) AS `color` from `catalogos`.`redesip_n_view` `a` order by if(((`a`.`available` < 150) and (`a`.`porc` > 90)),'red',if(((`a`.`available` >= 151) and (`a`.`available` <= 250) and (`a`.`porc` > 40)),'orange',if((`a`.`porc` < 40),'green','green'))) desc,`a`.`porc` desc) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-23 13:34:51
