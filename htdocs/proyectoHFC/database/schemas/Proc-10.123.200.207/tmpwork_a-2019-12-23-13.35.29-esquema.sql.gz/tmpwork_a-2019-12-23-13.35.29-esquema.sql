-- MySQL dump 10.15  Distrib 10.0.34-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: tmpwork_a
-- ------------------------------------------------------
-- Server version	10.0.34-MariaDB-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `SP_Signal_Alert_SW`
--

DROP TABLE IF EXISTS `SP_Signal_Alert_SW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SP_Signal_Alert_SW` (
  `sw` int(11) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cmts_ip_cols_phy`
--

DROP TABLE IF EXISTS `cmts_ip_cols_phy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmts_ip_cols_phy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cmts` varchar(50) NOT NULL,
  `tipo` varchar(10) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `abrev` varchar(4) DEFAULT NULL,
  `marca` varchar(10) DEFAULT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  `zonal` varchar(3) DEFAULT NULL,
  `col1` varchar(10) DEFAULT NULL,
  `col2` varchar(10) DEFAULT NULL,
  `col3` varchar(10) DEFAULT NULL,
  `col4` varchar(10) DEFAULT NULL,
  `col5` varchar(10) DEFAULT NULL,
  `col6` varchar(10) DEFAULT NULL,
  `col7` varchar(10) DEFAULT NULL,
  `col8` varchar(10) DEFAULT NULL,
  `col9` varchar(10) DEFAULT NULL,
  `col10` varchar(10) DEFAULT NULL,
  `col11` varchar(10) DEFAULT NULL,
  `col12` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`cmts`),
  KEY `idx1` (`cmts`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=458 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cmts_ip_cols_scm`
--

DROP TABLE IF EXISTS `cmts_ip_cols_scm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmts_ip_cols_scm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cmts` varchar(50) NOT NULL,
  `tipo` varchar(10) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `abrev` varchar(4) DEFAULT NULL,
  `marca` varchar(10) DEFAULT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  `zonal` varchar(3) DEFAULT NULL,
  `col1` varchar(10) DEFAULT NULL,
  `col2` varchar(10) DEFAULT NULL,
  `col3` varchar(10) DEFAULT NULL,
  `col4` varchar(10) DEFAULT NULL,
  `col5` varchar(10) DEFAULT NULL,
  `col6` varchar(10) DEFAULT NULL,
  `col7` varchar(10) DEFAULT NULL,
  `col8` varchar(10) DEFAULT NULL,
  `col9` varchar(10) DEFAULT NULL,
  `col10` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`cmts`),
  KEY `idx1` (`cmts`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=457 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `current`
--

DROP TABLE IF EXISTS `current`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `current` (
  `scm` int(11) DEFAULT NULL,
  `horaprocscm` varchar(20) DEFAULT NULL,
  `phy` int(11) DEFAULT NULL,
  `horaprocphy` varchar(20) DEFAULT NULL,
  `pasascm` int(11) DEFAULT NULL,
  `horapasascm` varchar(20) DEFAULT NULL,
  `pasaphy` int(11) DEFAULT NULL,
  `horapasaphy` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `scm_phy_esp_sw`
--

DROP TABLE IF EXISTS `scm_phy_esp_sw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scm_phy_esp_sw` (
  `sw` int(11) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `scm_scm_esp_sw`
--

DROP TABLE IF EXISTS `scm_scm_esp_sw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scm_scm_esp_sw` (
  `sw` int(11) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'tmpwork_a'
--
/*!50003 DROP PROCEDURE IF EXISTS `SP_Signal_Alert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`ccm1_user`@`%` PROCEDURE `SP_Signal_Alert`()
BEGIN
	UPDATE tmpwork_a.SP_Signal_Alert_SW SET sw=1,fechahora=NOW();
	COMMIT;
	
	TRUNCATE TABLE alertasx.nivelesxmac;
	COMMIT;
	
	/*INSERT IGNORE alertasx.nivelesxmac 
	SELECT b.macaddress,
	ROUND(AVG(IF(c.RxPwrdBmv LIKE '%0.00' OR LEFT(c.RxPwrdBmv,1) IN ('!','*'),RIGHT(c.RxPwrdBmv,4),c.RxPwrdBmv)),2) AS RxPwrdBmv ,
	ROUND(AVG(b.DSMER_SNR),2) AS  SNR_DN,
	ROUND(AVG(b.DSPwr),2) AS PWR_DN,
	ROUND(AVG(b.USMER_SNR),2) AS SNR_UP,
	ROUND(AVG(b.USPwr),2) AS PWR_UP
	FROM  ccm1_temporal.scm_phy_f b FORCE INDEX (NewIndex1,USMER_SNR,DSMER_SNR)
	INNER JOIN ccm1_temporal.scm_total_f c FORCE INDEX (MACAddress) ON b.macaddress=c.macaddress
	WHERE b.DSMER_SNR NOT IN ("-----","-") AND b.usmer_snr NOT IN ('-','-----')  
	GROUP BY b.macaddress;*/
	INSERT IGNORE alertasx.nivelesxmac 
	SELECT b.macaddress,
	ROUND(AVG(IF(c.RxPwrdBmv LIKE '%0.00' OR LEFT(c.RxPwrdBmv,1) IN ('!','*'),RIGHT(c.RxPwrdBmv,4),c.RxPwrdBmv)),0) AS RxPwrdBmv ,
	ROUND(AVG(b.DSMER_SNR),0) AS  SNR_DN,
	ROUND(AVG(b.DSPwr),0) AS PWR_DN,
	ROUND(AVG(b.USMER_SNR),0) AS SNR_UP,
	ROUND(AVG(b.USPwr),0) AS PWR_UP
	FROM  ccm1_temporal.scm_phy_f b FORCE INDEX (NewIndex1,USMER_SNR,DSMER_SNR)
	INNER JOIN ccm1_temporal.scm_total_f c FORCE INDEX (MACAddress) ON b.macaddress=c.macaddress
	WHERE b.DSMER_SNR NOT IN ("-----","-") AND b.usmer_snr NOT IN ('-','-----')  
	GROUP BY b.macaddress
	order by b.macaddress;
	COMMIT;
	
	TRUNCATE TABLE alertasx.resumen_nivelesxtroba_c;
	COMMIT;
	
	INSERT IGNORE alertasx.resumen_nivelesxtroba_c 
	SELECT a.nodo,a.troba,xx.RxPwrdBmv,xx.SNR_DN,xx.PWR_DN,xx.SNR_UP,xx.PWR_UP,COUNT(*) AS cant,NOW() AS fecha_hora," " AS fecha_fin," " AS tiempo,"SI" AS caida 
	FROM ccm1.nclientes a FORCE INDEX (NewIndex4,NODO) INNER JOIN alertasx.nivelesxmac xx FORCE INDEX (macaddress) ON a.mac2=xx.macaddress 
	WHERE a.nodo IS NOT NULL AND a.nodo NOT LIKE '' AND a.nodo NOT LIKE 'NO%'
	GROUP BY a.nodo,a.troba;
	COMMIT;
	
	TRUNCATE TABLE alertasx.nivelestemp_c;
	COMMIT;
	
	INSERT IGNORE alertasx.nivelestemp_c
	SELECT * FROM alertasx.resumen_nivelesxtroba_c a
	WHERE
	(a.snr_up < (SELECT vmin FROM catalogos.parametros_rf WHERE parametro='snr_avg' )
	OR (a.pwr_up < (SELECT vmin FROM catalogos.parametros_rf WHERE parametro='powerup_prom' ) AND
		a.pwr_up > (SELECT vmax FROM catalogos.parametros_rf WHERE parametro='powerup_prom') )
	OR a.snr_dn <(SELECT vmin FROM catalogos.parametros_rf WHERE parametro='snr_down')
	OR (a.pwr_dn < (SELECT vmin FROM catalogos.parametros_rf WHERE parametro='powerds_prom' ) AND
		a.pwr_dn > (SELECT vmax FROM catalogos.parametros_rf WHERE parametro='powerds_prom')));
	COMMIT;
		
		
	UPDATE alertasx.nivelestemp a FORCE INDEX (nodo,troba) LEFT JOIN alertasx.nivelestemp_c b FORCE INDEX (nodo,troba)
	ON a.nodo=b.nodo AND a.troba=b.troba
	SET a.fecha_fin=NOW(),a.tiempo=TIMEDIFF(NOW(),a.fecha_hora) ,a.caida='NO'
	WHERE b.nodo IS NULL AND a.caida='SI';
	COMMIT;
	
	UPDATE alertasx.nivelestemp a FORCE INDEX (nodo,troba) INNER JOIN alertasx.nivelestemp_c b FORCE INDEX (nodo,troba)
	ON a.nodo=b.nodo AND a.troba=b.troba
	SET a.RxPwrdBmv=b.RxPwrdBmv,a.SNR_DN=b.SNR_DN,a.PWR_DN=b.PWR_DN,a.SNR_UP=b.SNR_UP,a.PWR_UP=b.PWR_UP,a.tiempo=TIMEDIFF(NOW(),a.fecha_hora)
	WHERE a.caida='SI';
	COMMIT;
	
	UPDATE alertasx.nivelestemp a FORCE INDEX (nodo_2,nodo,troba) INNER JOIN alertasx.nivelestemp_c b FORCE INDEX (nodo,troba)
	ON a.nodo=b.nodo AND a.troba=b.troba
	SET a.RxPwrdBmv=b.RxPwrdBmv,a.SNR_DN=b.SNR_DN,a.PWR_DN=b.PWR_DN,a.SNR_UP=b.SNR_UP,a.PWR_UP=b.PWR_UP,a.tiempo=TIMEDIFF(NOW(),a.fecha_hora),a.caida='SI',a.fecha_fin=''
	WHERE a.caida='NO';
	COMMIT;
	
	
	INSERT IGNORE alertasx.nivelestemp
	SELECT * FROM alertasx.nivelestemp_c FORCE INDEX(nodo,troba) WHERE CONCAT(nodo,troba) NOT IN (SELECT CONCAT(nodo,troba) FROM alertasx.nivelestemp);
	COMMIT;
	
	
	DELETE FROM alertasx.nivelestemp WHERE DATEDIFF(NOW(),fecha_hora)>2 AND caida='NO';
	COMMIT;
	
	
	TRUNCATE TABLE alertasx.niveles_new;
	COMMIT;
	
	
	INSERT INTO alertasx.niveles_new
	SELECT CONCAT(b.jefatura,'_',b.sede) AS jefatura ,a.nodo,a.troba,IF(e.critica=1,'TC' ,'') AS tc,a.fecha_hora,c.codreqmnt AS codmasiva,
	a.RxPwrdBmv,a.PWR_UP AS pwr_up,a.SNR_UP AS snr_up,a.PWR_DN AS pwr_dn,a.SNR_DN AS snr_dn,cant AS can ,
	0 AS ncaidas,d.numbor,a.fecha_fin,a.caida
	FROM alertasx.`nivelestemp` a FORCE INDEX(nodo)
	INNER JOIN ccm1.zonales_nodos_eecc b FORCE INDEX(nodo_2,nodo)
	ON a.nodo=b.nodo
	LEFT JOIN dbpext.masivas_temp c FORCE INDEX (NewIndex4,NewIndex1,NewIndex2)
	ON a.nodo=c.codnod AND a.troba=c.nroplano
	LEFT JOIN catalogos.bornesxtroba d FORCE INDEX (NewIndex1,NewIndex2)
	ON a.nodo=d.nodo AND a.troba=d.troba
	LEFT JOIN catalogos.`trobas_criticas_n` e FORCE INDEX (nodo_2,nodo,troba)
	ON a.nodo=e.nodo AND a.troba=e.troba
	GROUP BY a.nodo,a.troba;
	COMMIT;
	
	
	UPDATE tmpwork_a.SP_Signal_Alert_SW SET sw=0,fechahora=NOW();
	COMMIT;
	
	
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-23 13:35:29
