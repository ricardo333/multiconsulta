-- MySQL dump 10.16  Distrib 10.1.40-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: reportes
-- ------------------------------------------------------
-- Server version	10.1.40-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cliente_lista`
--

DROP TABLE IF EXISTS `cliente_lista`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente_lista` (
  `codcli` int(11) NOT NULL,
  PRIMARY KEY (`codcli`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `clientes_dhcp`
--

DROP TABLE IF EXISTS `clientes_dhcp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes_dhcp` (
  `codcliente` varchar(15) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `macaddress` varchar(20) DEFAULT NULL,
  `ipaddress` varchar(20) DEFAULT NULL,
  `fabricante` varchar(20) DEFAULT NULL,
  `modelo` varchar(50) DEFAULT NULL,
  `firmware` varchar(50) DEFAULT NULL,
  `macstate` varchar(15) DEFAULT NULL,
  `tipo_dhcp` varchar(20) DEFAULT NULL,
  `host_dhcp` varchar(50) DEFAULT NULL,
  `macaddress_dhcp` varchar(20) DEFAULT NULL,
  `ipaddress_dhcp` varchar(20) DEFAULT NULL,
  `nivel_dhcp` varchar(10) DEFAULT NULL,
  `fechaproceso` varchar(20) DEFAULT NULL,
  KEY `codcliente` (`codcliente`),
  KEY `macaddress` (`macaddress`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `clientes_en_puerto_saturado`
--

DROP TABLE IF EXISTS `clientes_en_puerto_saturado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes_en_puerto_saturado` (
  `IDCLIENTECRM` double DEFAULT NULL,
  `nameclient` varchar(100) DEFAULT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `NODO` varchar(2) DEFAULT NULL,
  `TROBA` varchar(4) DEFAULT NULL,
  `amplificador` varchar(11) DEFAULT NULL,
  `tap` varchar(11) DEFAULT NULL,
  `telf1` varchar(10) DEFAULT NULL,
  `telf2` varchar(10) DEFAULT NULL,
  `movil1` varchar(20) DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `SERVICEPACKAGE` varchar(50) DEFAULT NULL,
  `SCOPESGROUP` varchar(15) DEFAULT NULL,
  `RxPwrdBmv` varchar(20) DEFAULT NULL,
  `USPwr` varchar(20) DEFAULT NULL,
  `USMER_SNR` varchar(20) DEFAULT NULL,
  `DSPwr` varchar(20) DEFAULT NULL,
  `DSMER_SNR` varchar(20) DEFAULT NULL,
  `STATUS` varchar(78) DEFAULT NULL,
  `INTERFACE` varchar(20) DEFAULT NULL,
  `CMTS` varchar(20) DEFAULT NULL,
  `down` varchar(10) DEFAULT NULL,
  `fecha_upload` datetime DEFAULT NULL,
  `tipopuerto` varchar(20) DEFAULT NULL,
  UNIQUE KEY `MACADDRESS` (`MACADDRESS`),
  KEY `IDCLIENTECRM` (`IDCLIENTECRM`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `criticos`
--

DROP TABLE IF EXISTS `criticos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `criticos` (
  `EMPRESA` varchar(3) DEFAULT NULL,
  `IDCLIENTECRM` double DEFAULT NULL,
  `idempresacrm` int(11) DEFAULT NULL,
  `idservicio` int(11) DEFAULT NULL,
  `idproducto` double DEFAULT NULL,
  `idventa` double DEFAULT NULL,
  `NAMECLIENT` varchar(100) DEFAULT NULL,
  `NODO` varchar(2) DEFAULT NULL,
  `TROBA` varchar(4) DEFAULT NULL,
  `amplificador` varchar(11) DEFAULT NULL,
  `tap` varchar(11) DEFAULT NULL,
  `telf1` varchar(10) DEFAULT NULL,
  `telf2` varchar(10) DEFAULT NULL,
  `f_v` varchar(20) DEFAULT NULL,
  `regver` varchar(3) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `SERVICEPACKAGECRMID` varchar(50) DEFAULT NULL,
  `SERVICEPACKAGE` varchar(50) DEFAULT NULL,
  `CANTPCS` varchar(11) DEFAULT NULL,
  `FECHAALTA` varchar(20) DEFAULT NULL,
  `FECHAACTIVACION` varchar(20) DEFAULT NULL,
  `ESTADO` varchar(10) DEFAULT NULL,
  `SCOPESGROUP` varchar(15) DEFAULT NULL,
  `SCOPESGROUPCM` varchar(15) DEFAULT NULL,
  `SCOPESGROUPMTA` varchar(15) DEFAULT NULL,
  `MTAMAC` varchar(20) DEFAULT NULL,
  `IDSERVICIOMTA` varchar(15) DEFAULT NULL,
  `IDPRODUCTOMTA` varchar(15) DEFAULT NULL,
  `IDVENTAMTA` varchar(15) DEFAULT NULL,
  `MTAMODELNAME` varchar(50) DEFAULT NULL,
  `CMTSID` varchar(11) DEFAULT NULL,
  `UBICACIONENLARED` varchar(150) DEFAULT NULL,
  `IPCM` varchar(20) DEFAULT NULL,
  `DOCSISVERSION` varchar(11) DEFAULT NULL,
  `movil1` varchar(20) DEFAULT NULL,
  `mac2` varchar(20) DEFAULT NULL,
  `mac3` varchar(20) DEFAULT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `codserv` varchar(20) DEFAULT NULL,
  `fecha_upload` datetime DEFAULT NULL,
  `entidad` varchar(100) DEFAULT NULL,
  UNIQUE KEY `MACADDRESS` (`MACADDRESS`),
  KEY `IDCLIENTECRM` (`IDCLIENTECRM`),
  KEY `NODO` (`NODO`),
  KEY `TROBA` (`TROBA`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `criticos_view`
--

DROP TABLE IF EXISTS `criticos_view`;
/*!50001 DROP VIEW IF EXISTS `criticos_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `criticos_view` (
  `nodo` tinyint NOT NULL,
  `troba` tinyint NOT NULL,
  `ncrit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `graf_arbol_hoy`
--

DROP TABLE IF EXISTS `graf_arbol_hoy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `graf_arbol_hoy` (
  `hora` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `arbol` decimal(24,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `graf_arbol_tot`
--

DROP TABLE IF EXISTS `graf_arbol_tot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `graf_arbol_tot` (
  `hora` varchar(2) DEFAULT NULL,
  `arboltot` bigint(21) NOT NULL,
  KEY `hora` (`hora`),
  KEY `arboltot` (`arboltot`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `graf_ayer`
--

DROP TABLE IF EXISTS `graf_ayer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `graf_ayer` (
  `desdia` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `hora` varchar(2) CHARACTER SET latin1 DEFAULT NULL,
  `aver` bigint(21) NOT NULL,
  KEY `desdia` (`desdia`),
  KEY `hora` (`hora`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `graf_hoy`
--

DROP TABLE IF EXISTS `graf_hoy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `graf_hoy` (
  `desdia` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `hora` varchar(2) CHARACTER SET latin1 DEFAULT NULL,
  `aver` bigint(21) NOT NULL,
  KEY `desdia` (`desdia`),
  KEY `hora` (`hora`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `graf_liquidaciones`
--

DROP TABLE IF EXISTS `graf_liquidaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `graf_liquidaciones` (
  `Hora` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `liq` bigint(21) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `graf_llamadas`
--

DROP TABLE IF EXISTS `graf_llamadas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `graf_llamadas` (
  `horallam` varchar(2) CHARACTER SET latin1 DEFAULT NULL,
  `llamadas` bigint(21) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `graf_promedio`
--

DROP TABLE IF EXISTS `graf_promedio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `graf_promedio` (
  `dia_mov` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `desdia` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `hora` varchar(2) CHARACTER SET latin1 DEFAULT NULL,
  `aver` bigint(21) NOT NULL,
  KEY `dia_mov` (`dia_mov`),
  KEY `desdia` (`desdia`),
  KEY `hora` (`hora`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `historico_fuentes`
--

DROP TABLE IF EXISTS `historico_fuentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `historico_fuentes` (
  `macaddress` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `ipaddress` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `InputVoltagefinal` float NOT NULL,
  `OutputVoltagefinal` float NOT NULL,
  `OutputCurrentfinal` float NOT NULL,
  `TotalStringVoltagefinal` varchar(12) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `EstadoInversor` int(11) DEFAULT NULL,
  `fechahora` varchar(20) NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `macaddress` (`macaddress`),
  KEY `fechahora` (`fechahora`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `liqhoyxrubro`
--

DROP TABLE IF EXISTS `liqhoyxrubro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `liqhoyxrubro` (
  `jefatura` varchar(14) CHARACTER SET latin1 DEFAULT NULL,
  `ADMINISTRATIVA` decimal(23,0) DEFAULT NULL,
  `INEFECTIVA` decimal(23,0) DEFAULT NULL,
  `PLANTA_EXTERNA` decimal(23,0) DEFAULT NULL,
  `PLANTA_INTERNA` decimal(23,0) DEFAULT NULL,
  `RED_CLIENTE` decimal(23,0) DEFAULT NULL,
  `TRANSMISIONES` decimal(23,0) DEFAULT NULL,
  `FIBRA_OPTICA` decimal(23,0) DEFAULT NULL,
  `TOTAL` bigint(21) NOT NULL DEFAULT '0',
  KEY `jefatura` (`jefatura`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `liqhoyxrubromas24horas`
--

DROP TABLE IF EXISTS `liqhoyxrubromas24horas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `liqhoyxrubromas24horas` (
  `jefatura` varchar(14) CHARACTER SET latin1 DEFAULT NULL,
  `ADMINISTRATIVA` decimal(23,0) DEFAULT NULL,
  `INEFECTIVA` decimal(23,0) DEFAULT NULL,
  `PLANTA_EXTERNA` decimal(23,0) DEFAULT NULL,
  `PLANTA_INTERNA` decimal(23,0) DEFAULT NULL,
  `RED_CLIENTE` decimal(23,0) DEFAULT NULL,
  `TRANSMISIONES` decimal(23,0) DEFAULT NULL,
  `FIBRA_OPTICA` decimal(23,0) DEFAULT NULL,
  `TOTAL` bigint(21) NOT NULL DEFAULT '0',
  KEY `jefatura` (`jefatura`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `liqhoyxrubromenos24horas`
--

DROP TABLE IF EXISTS `liqhoyxrubromenos24horas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `liqhoyxrubromenos24horas` (
  `jefatura` varchar(14) CHARACTER SET latin1 DEFAULT NULL,
  `ADMINISTRATIVA` decimal(23,0) DEFAULT NULL,
  `INEFECTIVA` decimal(23,0) DEFAULT NULL,
  `PLANTA_EXTERNA` decimal(23,0) DEFAULT NULL,
  `PLANTA_INTERNA` decimal(23,0) DEFAULT NULL,
  `RED_CLIENTE` decimal(23,0) DEFAULT NULL,
  `TRANSMISIONES` decimal(23,0) DEFAULT NULL,
  `FIBRA_OPTICA` decimal(23,0) DEFAULT NULL,
  `TOTAL` bigint(21) NOT NULL DEFAULT '0',
  KEY `jefatura` (`jefatura`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `liqxhoramas24horas`
--

DROP TABLE IF EXISTS `liqxhoramas24horas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `liqxhoramas24horas` (
  `jefatura` varchar(14) DEFAULT NULL,
  `D00` decimal(23,0) DEFAULT NULL,
  `D01` decimal(23,0) DEFAULT NULL,
  `D02` decimal(23,0) DEFAULT NULL,
  `D03` decimal(23,0) DEFAULT NULL,
  `D04` decimal(23,0) DEFAULT NULL,
  `D05` decimal(23,0) DEFAULT NULL,
  `D06` decimal(23,0) DEFAULT NULL,
  `D07` decimal(23,0) DEFAULT NULL,
  `D08` decimal(23,0) DEFAULT NULL,
  `D09` decimal(23,0) DEFAULT NULL,
  `D10` decimal(23,0) DEFAULT NULL,
  `D11` decimal(23,0) DEFAULT NULL,
  `D12` decimal(23,0) DEFAULT NULL,
  `D13` decimal(23,0) DEFAULT NULL,
  `D14` decimal(23,0) DEFAULT NULL,
  `D15` decimal(23,0) DEFAULT NULL,
  `D16` decimal(23,0) DEFAULT NULL,
  `D17` decimal(23,0) DEFAULT NULL,
  `D18` decimal(23,0) DEFAULT NULL,
  `D19` decimal(23,0) DEFAULT NULL,
  `D20` decimal(23,0) DEFAULT NULL,
  `D21` decimal(23,0) DEFAULT NULL,
  `D22` decimal(23,0) DEFAULT NULL,
  `D23` decimal(23,0) DEFAULT NULL,
  `cant` bigint(21) NOT NULL,
  KEY `jefatura` (`jefatura`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `liqxhoramenos24horas`
--

DROP TABLE IF EXISTS `liqxhoramenos24horas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `liqxhoramenos24horas` (
  `jefatura` varchar(14) DEFAULT NULL,
  `D00` decimal(23,0) DEFAULT NULL,
  `D01` decimal(23,0) DEFAULT NULL,
  `D02` decimal(23,0) DEFAULT NULL,
  `D03` decimal(23,0) DEFAULT NULL,
  `D04` decimal(23,0) DEFAULT NULL,
  `D05` decimal(23,0) DEFAULT NULL,
  `D06` decimal(23,0) DEFAULT NULL,
  `D07` decimal(23,0) DEFAULT NULL,
  `D08` decimal(23,0) DEFAULT NULL,
  `D09` decimal(23,0) DEFAULT NULL,
  `D10` decimal(23,0) DEFAULT NULL,
  `D11` decimal(23,0) DEFAULT NULL,
  `D12` decimal(23,0) DEFAULT NULL,
  `D13` decimal(23,0) DEFAULT NULL,
  `D14` decimal(23,0) DEFAULT NULL,
  `D15` decimal(23,0) DEFAULT NULL,
  `D16` decimal(23,0) DEFAULT NULL,
  `D17` decimal(23,0) DEFAULT NULL,
  `D18` decimal(23,0) DEFAULT NULL,
  `D19` decimal(23,0) DEFAULT NULL,
  `D20` decimal(23,0) DEFAULT NULL,
  `D21` decimal(23,0) DEFAULT NULL,
  `D22` decimal(23,0) DEFAULT NULL,
  `D23` decimal(23,0) DEFAULT NULL,
  `cant` bigint(21) NOT NULL,
  KEY `jefatura` (`jefatura`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nclientes_dat`
--

DROP TABLE IF EXISTS `nclientes_dat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nclientes_dat` (
  `IDCLIENTECRM` double DEFAULT NULL,
  `NODO` varchar(2) DEFAULT NULL,
  `TROBA` varchar(4) DEFAULT NULL,
  `amplificador` varchar(11) DEFAULT NULL,
  `tap` varchar(11) DEFAULT NULL,
  `telf1` varchar(10) DEFAULT NULL,
  `telf2` varchar(10) DEFAULT NULL,
  `movil1` varchar(10) DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `codserv` int(11) DEFAULT NULL,
  `idproducto` double DEFAULT NULL,
  `idventa` double DEFAULT NULL,
  `clave` double NOT NULL,
  `naked` varchar(20) DEFAULT NULL,
  `numcoo_x` varchar(30) DEFAULT NULL,
  `numcoo_y` varchar(30) DEFAULT NULL,
  `nameclient` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`clave`),
  UNIQUE KEY `NewIndex3` (`MACADDRESS`),
  KEY `NewIndex1` (`IDCLIENTECRM`),
  KEY `idxnodo` (`NODO`),
  KEY `idxtroba` (`TROBA`),
  KEY `idxtelef1` (`telf1`),
  KEY `idxtelef2` (`telf2`),
  KEY `movil1` (`movil1`),
  KEY `idproducto` (`idproducto`),
  KEY `idventa` (`idventa`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `portadorasxpuerto_tr`
--

DROP TABLE IF EXISTS `portadorasxpuerto_tr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portadorasxpuerto_tr` (
  `cmts` varchar(50) DEFAULT NULL,
  `down` varchar(6) DEFAULT NULL,
  `can` bigint(21) NOT NULL DEFAULT '0',
  `clientes` decimal(42,0) DEFAULT NULL,
  `interface` varchar(20) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `fecha_upload` datetime DEFAULT NULL,
  `uso` varchar(10) DEFAULT NULL,
  KEY `cmts` (`cmts`),
  KEY `down` (`down`),
  KEY `interface` (`interface`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `procesos`
--

DROP TABLE IF EXISTS `procesos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `procesos` (
  `ID` bigint(4) NOT NULL DEFAULT '0',
  `USER` varchar(128) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `HOST` varchar(64) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `DB` varchar(64) CHARACTER SET utf8 DEFAULT NULL,
  `COMMAND` varchar(16) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `TIME` int(7) NOT NULL DEFAULT '0',
  `STATE` varchar(64) CHARACTER SET utf8 DEFAULT NULL,
  `INFO` longtext CHARACTER SET utf8,
  `TIME_MS` decimal(22,3) NOT NULL DEFAULT '0.000',
  `STAGE` tinyint(2) NOT NULL DEFAULT '0',
  `MAX_STAGE` tinyint(2) NOT NULL DEFAULT '0',
  `PROGRESS` decimal(7,3) NOT NULL DEFAULT '0.000',
  `MEMORY_USED` bigint(7) NOT NULL DEFAULT '0',
  `EXAMINED_ROWS` int(7) NOT NULL DEFAULT '0',
  `QUERY_ID` bigint(4) NOT NULL DEFAULT '0',
  `FECHA_HORA` varchar(20) DEFAULT NULL,
  UNIQUE KEY `ID` (`ID`,`FECHA_HORA`(10)),
  KEY `ID_2` (`ID`),
  KEY `FECHA_HORA` (`FECHA_HORA`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `procesos_analitycs`
--

DROP TABLE IF EXISTS `procesos_analitycs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `procesos_analitycs` (
  `ID` bigint(4) NOT NULL DEFAULT '0',
  `USER` varchar(128) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `HOST` varchar(64) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `DB` varchar(64) CHARACTER SET utf8 DEFAULT NULL,
  `COMMAND` varchar(16) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `TIME` int(7) NOT NULL DEFAULT '0',
  `STATE` varchar(64) CHARACTER SET utf8 DEFAULT NULL,
  `INFO` longtext CHARACTER SET utf8,
  `TIME_MS` decimal(22,3) NOT NULL DEFAULT '0.000',
  `STAGE` tinyint(2) NOT NULL DEFAULT '0',
  `MAX_STAGE` tinyint(2) NOT NULL DEFAULT '0',
  `PROGRESS` decimal(7,3) NOT NULL DEFAULT '0.000',
  `MEMORY_USED` bigint(7) NOT NULL DEFAULT '0',
  `EXAMINED_ROWS` int(7) NOT NULL DEFAULT '0',
  `QUERY_ID` bigint(4) NOT NULL DEFAULT '0',
  `FECHA_HORA` varchar(20) DEFAULT NULL,
  UNIQUE KEY `ID` (`ID`,`FECHA_HORA`(10)),
  KEY `ID_2` (`ID`),
  KEY `FECHA_HORA` (`FECHA_HORA`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resumen_tcfl`
--

DROP TABLE IF EXISTS `resumen_tcfl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resumen_tcfl` (
  `jefatura` varchar(14) CHARACTER SET latin1 DEFAULT NULL,
  `D00` int(3) DEFAULT NULL,
  `D01` int(3) DEFAULT NULL,
  `D02` int(3) DEFAULT NULL,
  `D03` int(3) DEFAULT NULL,
  `D04` int(3) DEFAULT NULL,
  `D05` int(3) DEFAULT NULL,
  `D06` int(3) DEFAULT NULL,
  `D07` int(3) DEFAULT NULL,
  `D08` int(3) DEFAULT NULL,
  `D09` int(3) DEFAULT NULL,
  `D10` int(3) DEFAULT NULL,
  `D11` int(3) DEFAULT NULL,
  `D12` int(3) DEFAULT NULL,
  `D13` int(3) DEFAULT NULL,
  `D14` int(3) DEFAULT NULL,
  `D15` int(3) DEFAULT NULL,
  `D16` int(3) DEFAULT NULL,
  `D17` int(3) DEFAULT NULL,
  `D18` int(3) DEFAULT NULL,
  `D19` int(3) DEFAULT NULL,
  `D20` int(3) DEFAULT NULL,
  `D21` int(3) DEFAULT NULL,
  `D22` int(3) DEFAULT NULL,
  `D23` int(3) DEFAULT NULL,
  `ptot` int(3) DEFAULT NULL,
  `total` int(10) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `uso_portadoras`
--

DROP TABLE IF EXISTS `uso_portadoras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uso_portadoras` (
  `cmts` varchar(20) DEFAULT NULL,
  `down` varchar(6) DEFAULT NULL,
  `uso` double(18,1) DEFAULT NULL,
  `cant` bigint(21) NOT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  UNIQUE KEY `cmts_2` (`cmts`,`down`,`fecha_hora`),
  KEY `cmts` (`cmts`),
  KEY `down` (`down`),
  KEY `fecha_hora` (`fecha_hora`),
  KEY `uso` (`uso`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'reportes'
--
/*!50003 DROP PROCEDURE IF EXISTS `historico_fuentes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`rfalla`@`%` PROCEDURE `historico_fuentes`()
BEGIN
DELETE FROM reportes.`historico_fuentes` WHERE TIMEDIFF(NOW(),fechahora)>='72:00:00.000000';
INSERT INTO reportes.`historico_fuentes`
SELECT macaddress,ipaddress,`InputVoltagefinal`,`OutputVoltagefinal`,`OutputCurrentfinal`,`TotalStringVoltagefinal`,`EstadoInversor`,NOW() FROM `alertasx`.`fuentes_view` WHERE resultadosnmp='SNMPOK';
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_grafica_averias` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`rfalla`@`%` PROCEDURE `sp_grafica_averias`()
BEGIN
	#############################################################
	TRUNCATE TABLE reportes.graf_promedio;
	INSERT INTO reportes.graf_promedio
	SELECT a.dia_mov,b.desdia,SUBSTR(fec_mov,12,2) AS hora,COUNT(*) AS aver FROM (SELECT * FROM ccm1.averias_m1_new GROUP BY codreq) a 
	INNER JOIN catalogos.dias b ON DAYOFWEEK(a.dia_mov)=b.dia 
	WHERE tipreqini IN ('R7','RA','RP') AND DATEDIFF(NOW(),dia_mov)<=30 AND DATEDIFF(NOW(),dia_mov)>=0 AND DAYOFWEEK(a.dia_mov)=DAYOFWEEK(NOW())
	GROUP BY 1,2,3;
	#############################################################
	TRUNCATE TABLE reportes.graf_ayer;
	INSERT INTO reportes.graf_ayer
	SELECT b.desdia,SUBSTR(fec_mov,12,2) AS hora,COUNT(*) AS aver FROM 
	(SELECT * FROM ccm1.averias_m1_new GROUP BY codreq) a 
	INNER JOIN catalogos.dias b ON DAYOFWEEK(a.dia_mov)=b.dia 	
	WHERE tipreqini IN ('R7','RA','RP') AND DATEDIFF(NOW(),a.dia_mov)=1 	GROUP BY 1,2;
	#############################################################
	TRUNCATE TABLE reportes.graf_hoy;
	INSERT INTO reportes.graf_hoy
	SELECT b.desdia,SUBSTR(fec_mov,12,2) AS hora,COUNT(*) AS aver FROM 
	(SELECT * FROM ccm1.averias_m1_new  GROUP BY codreq) a 
	INNER JOIN catalogos.dias b 	ON DAYOFWEEK(a.dia_mov)=b.dia 
	WHERE tipreqini in ('R7','RA','RP') and   DATEDIFF(NOW(),a.dia_mov)=0
	GROUP BY 1,2;
#	SELECT b.desdia,SUBSTR(fec_mov,12,2) AS hora,COUNT(*) AS aver FROM 
#	(SELECT * FROM ccm1.averias_m1_new GROUP BY codreq) a 
#	INNER JOIN catalogos.dias b ON DAYOFWEEK(a.dia_mov)=b.dia 
#	WHERE tipreqini IN ('R7','RA','RP') AND DATEDIFF(NOW(),a.dia_mov)=0 GROUP BY 1,2;
	#############################################################
	TRUNCATE TABLE reportes.graf_arbol_tot;
	INSERT INTO reportes.graf_arbol_tot
	SELECT SUBSTR(fechahora,12,2) AS hora ,COUNT(*) AS arboltot FROM 
	arboldecisiones.`decisiones_hoy` WHERE DATEDIFF(NOW(),fechahora)=0 GROUP BY 1;
	#############################################################
	TRUNCATE TABLE reportes.graf_arbol_hoy;
	INSERT INTO reportes.graf_arbol_hoy
	SELECT aa.hora,IF(ab.arbol IS NOT NULL ,aa.arbol+ab.arbol,aa.arbol) AS arbol FROM (SELECT SUBSTR(a.fec_registro,12,2) AS hora,COUNT(*) AS cant,SUM(IF(b.`fechahora`<>'',1,0)) AS arbol FROM cms.`req_pend_macro_final` a 
	LEFT JOIN arboldecisiones.`decisiones_hoy` b ON a.`codcli`=b.`idclientecrm` AND DATEDIFF(NOW(),a.`fec_registro`)=0 AND DATEDIFF(NOW(),b.`fechahora`)=0 WHERE DATEDIFF(NOW(),a.`fec_registro`)=0 GROUP BY 1 ) aa 
	LEFT JOIN (SELECT SUBSTR(a.fecharegistro,12,2) AS hora,SUM(IF(b.`fechahora`<>'',1,0)) AS arbol FROM cms.`aver_liq_catv_pais` a 
	LEFT JOIN arboldecisiones.`decisiones_hoy` b ON a.`codigodelcliente`=b.`idclientecrm` AND DATEDIFF(NOW(),a.`fecharegistro`)=0 AND DATEDIFF(NOW(),b.`fechahora`)=0 WHERE DATEDIFF(NOW(),a.`fecharegistro`)=0 GROUP BY 1 ) ab ON aa.hora=ab.hora ;
	#############################################################
	TRUNCATE TABLE reportes.graf_llamadas;
	INSERT INTO  reportes.graf_llamadas
	SELECT SUBSTR(a.fechahora,12,2) AS horallam,COUNT(*) AS llamadas FROM alertasx.`alertas_dmpe` a WHERE datediff(now(),fechahora)=0 GROUP BY 1;
	#############################################################
	TRUNCATE TABLE reportes.graf_liquidaciones;
	INSERT INTO reportes.graf_liquidaciones
	SELECT SUBSTR(fecha_liquidacion,12,2) Hora,COUNT(*) AS liq FROM cms.aver_liq_catv_pais a WHERE DATEDIFF(NOW(),fecha_liquidacion) =0 GROUP BY 1 ;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_TCFLxHORA` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`rfalla`@`%` PROCEDURE `SP_TCFLxHORA`()
BEGIN
	TRUNCATE TABLE reportes.liqxhoramenos24horas;
	INSERT IGNORE reportes.liqxhoramenos24horas
	SELECT CONCAT(b.jefatura,'_',b.sede) jefatura ,
	SUM(IF(HOUR(fecha_liquidacion)=0 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D00',
	SUM(IF(HOUR(fecha_liquidacion)=1 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0))  AS 'D01',
	SUM(IF(HOUR(fecha_liquidacion)=2 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D02',
	SUM(IF(HOUR(fecha_liquidacion)=3 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D03',
	SUM(IF(HOUR(fecha_liquidacion)=4 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D04',
	SUM(IF(HOUR(fecha_liquidacion)=5 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D05',
	SUM(IF(HOUR(fecha_liquidacion)=6 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D06',
	SUM(IF(HOUR(fecha_liquidacion)=7 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D07',
	SUM(IF(HOUR(fecha_liquidacion)=8 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D08',
	SUM(IF(HOUR(fecha_liquidacion)=9 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D09',
	SUM(IF(HOUR(fecha_liquidacion)=10 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D10',
	SUM(IF(HOUR(fecha_liquidacion)=11 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D11',
	SUM(IF(HOUR(fecha_liquidacion)=12 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D12',
	SUM(IF(HOUR(fecha_liquidacion)=13 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D13',
	SUM(IF(HOUR(fecha_liquidacion)=14 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D14',
	SUM(IF(HOUR(fecha_liquidacion)=15 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D15',
	SUM(IF(HOUR(fecha_liquidacion)=16 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D16',
	SUM(IF(HOUR(fecha_liquidacion)=17 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D17',
	SUM(IF(HOUR(fecha_liquidacion)=18 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D18',
	SUM(IF(HOUR(fecha_liquidacion)=19 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D19',
	SUM(IF(HOUR(fecha_liquidacion)=20 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D20',
	SUM(IF(HOUR(fecha_liquidacion)=21 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D21',
	SUM(IF(HOUR(fecha_liquidacion)=22 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D22',
	SUM(IF(HOUR(fecha_liquidacion)=23 AND TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS 'D23',
	SUM(IF(TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000',1,0)) AS cant
	FROM cms.aver_liq_catv_pais a INNER JOIN ccm1.`zonales_nodos_eecc` b
	ON a.nodo=b.nodo
	WHERE DATEDIFF(NOW(),fecha_liquidacion)=0 
	 and contrata not in (442,429,434,428)
	 and codigomotivoreq IN (
	'R001',
	'R002',
	'R038',
	'R040',
	'R041',
	'R042',
	'R101',
	'R102',
	'R103',
	'R413',
	'R414',
	'R415',
	'R416',
	'R417',
	'R418',
	'R422',
	'R423',
	'R424',
	'R425',
	'R426',
	'R427')
	AND contrata NOT IN (333,442,429,430,434,353,436,428)
	GROUP BY 1;
	
	TRUNCATE TABLE reportes.liqxhoramas24horas;
	INSERT IGNORE reportes.liqxhoramas24horas
	SELECT CONCAT(b.jefatura,'_',b.sede) jefatura ,
	SUM(IF(HOUR(fecha_liquidacion)=0 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D00',
	SUM(IF(HOUR(fecha_liquidacion)=1 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0))  AS 'D01',
	SUM(IF(HOUR(fecha_liquidacion)=2 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D02',
	SUM(IF(HOUR(fecha_liquidacion)=3 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D03',
	SUM(IF(HOUR(fecha_liquidacion)=4 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D04',
	SUM(IF(HOUR(fecha_liquidacion)=5 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D05',
	SUM(IF(HOUR(fecha_liquidacion)=6 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D06',
	SUM(IF(HOUR(fecha_liquidacion)=7 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D07',
	SUM(IF(HOUR(fecha_liquidacion)=8 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D08',
	SUM(IF(HOUR(fecha_liquidacion)=9 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D09',
	SUM(IF(HOUR(fecha_liquidacion)=10 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D10',
	SUM(IF(HOUR(fecha_liquidacion)=11 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D11',
	SUM(IF(HOUR(fecha_liquidacion)=12 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D12',
	SUM(IF(HOUR(fecha_liquidacion)=13 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D13',
	SUM(IF(HOUR(fecha_liquidacion)=14 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D14',
	SUM(IF(HOUR(fecha_liquidacion)=15 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D15',
	SUM(IF(HOUR(fecha_liquidacion)=16 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D16',
	SUM(IF(HOUR(fecha_liquidacion)=17 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D17',
	SUM(IF(HOUR(fecha_liquidacion)=18 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D18',
	SUM(IF(HOUR(fecha_liquidacion)=19 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D19',
	SUM(IF(HOUR(fecha_liquidacion)=20 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D20',
	SUM(IF(HOUR(fecha_liquidacion)=21 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D21',
	SUM(IF(HOUR(fecha_liquidacion)=22 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D22',
	SUM(IF(HOUR(fecha_liquidacion)=23 AND TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS 'D23',
	SUM(IF(TIMEDIFF(fecha_liquidacion,fecharegistro)>'24:00:00.000000',1,0)) AS cant
	FROM cms.aver_liq_catv_pais a INNER JOIN ccm1.`zonales_nodos_eecc` b
	ON a.nodo=b.nodo
	WHERE DATEDIFF(NOW(),fecha_liquidacion)=0 AND contrata NOT IN (442,429,434,428)
	 AND codigomotivoreq IN (
	'R001',
	'R002',
	'R038',
	'R040',
	'R041',
	'R042',
	'R101',
	'R102',
	'R103',
	'R413',
	'R414',
	'R415',
	'R416',
	'R417',
	'R418',
	'R422',
	'R423',
	'R424',
	'R425',
	'R426',
	'R427')
	and contrata not in (333,442,429,430,434,353,436,428)
	GROUP BY 1;
	truncate TABLE reportes.resumen_tcfl;
	insert ignore reportes.resumen_tcfl
	SELECT a.jefatura, 
	ROUND((a.D00/(a.D00+b.D00))*100,0) AS 'D00',
	ROUND((a.D01/(a.D01+b.D01))*100,0) AS 'D01',
	ROUND((a.D02/(a.D02+b.D02))*100,0) AS 'D02',
	ROUND((a.D03/(a.D03+b.D03))*100,0) AS'D03',
	ROUND((a.D04/(a.D04+b.D04))*100,0) AS'D04',
	ROUND((a.D05/(a.D05+b.D05))*100,0) AS'D05',
	ROUND((a.D06/(a.D06+b.D06))*100,0) AS'D06',
	ROUND((a.D07/(a.D07+b.D07))*100,0) AS'D07',
	ROUND((a.D08/(a.D08+b.D08))*100,0) AS'D08',
	ROUND((a.D09/(a.D09+b.D09))*100,0) AS'D09',
	ROUND((a.D10/(a.D10+b.D10))*100,0) AS'D10',
	ROUND((a.D11/(a.D11+b.D11))*100,0) AS'D11',
	ROUND((a.D12/(a.D12+b.D12))*100,0) AS'D12',
	ROUND((a.D13/(a.D13+b.D13))*100,0) AS'D13',
	ROUND((a.D14/(a.D14+b.D14))*100,0) AS'D14',
	ROUND((a.D15/(a.D15+b.D15))*100,0) AS'D15',
	ROUND((a.D16/(a.D16+b.D16))*100,0) AS'D16',
	ROUND((a.D17/(a.D17+b.D17))*100,0) AS'D17',
	ROUND((a.D18/(a.D18+b.D18))*100,0) AS'D18',
	ROUND((a.D19/(a.D19+b.D19))*100,0) AS'D19',
	ROUND((a.D20/(a.D20+b.D20))*100,0) AS'D20',
	ROUND((a.D21/(a.D21+b.D21))*100,0) AS'D21',
	ROUND((a.D22/(a.D22+b.D22))*100,0) AS'D22',
	ROUND((a.D23/(a.D23+b.D23))*100,0) AS'D23',
	ROUND((a.cant/(a.cant+b.cant))*100,0) AS ptot,
	a.cant+b.cant AS total,now() as fechahora
	FROM reportes.`liqxhoramenos24horas` a LEFT JOIN reportes.`liqxhoramas24horas` b
	ON a.`jefatura`=b.`jefatura`
	GROUP BY a.jefatura;
	
	TRUNCATE TABLE reportes.liqhoyxrubromenos24horas;
	INSERT INTO reportes.liqhoyxrubromenos24horas
	SELECT xx.jefatura,
	SUM(IF(xx.nrubro='ADMINISTRATIVA',1,0)) AS ADMINISTRATIVA,
	SUM(IF(xx.nrubro='INEFECTIVA',1,0)) AS  INEFECTIVA,
	SUM(IF(xx.nrubro='PLANTA EXTERNA',1,0)) AS  PLANTA_EXTERNA,
	SUM(IF(xx.nrubro='PLANTA INTERNA',1,0)) AS  PLANTA_INTERNA,
	SUM(IF(xx.nrubro='RED CLIENTE',1,0)) AS  RED_CLIENTE,
	SUM(IF(xx.nrubro='TRANSMISIONES',1,0)) AS  TRANSMISIONES,
	SUM(IF(xx.nrubro='FIBRA OPTICA',1,0)) AS FIBRA_OPTICA,
	COUNT(*) AS TOTAL FROM 
	(SELECT a.*,b.nrubro,CONCAT(c.jefatura,'_',c.sede) jefatura  FROM cms.`aver_liq_catv_pais` a INNER JOIN cms.`maquetacatv` b
	ON a.`codigodeliquidacion`=b.`CODLIQ`
	INNER JOIN ccm1.`zonales_nodos_eecc` c
		ON a.nodo=c.nodo
	WHERE DATEDIFF(NOW(),fecha_liquidacion)=0 AND a.contrata NOT IN (442,429,434,428) AND  a.codigomotivoreq IN ('R001','R002','R038','R040','R041','R042','R101','R102','R103','R413','R414','R415','R416','R417','R418','R422','R423','R424','R425','R426','R427')
	and TIMEDIFF(fecha_liquidacion,fecharegistro)<'24:00:00.000000'
	GROUP BY a.`codigoreq`) xx
	GROUP BY 1;
	TRUNCATE TABLE reportes.liqhoyxrubromas24horas;
	INSERT INTO reportes.liqhoyxrubromas24horas
	SELECT xx.jefatura,
	SUM(IF(xx.nrubro='ADMINISTRATIVA',1,0)) AS ADMINISTRATIVA,
	SUM(IF(xx.nrubro='INEFECTIVA',1,0)) AS  INEFECTIVA,
	SUM(IF(xx.nrubro='PLANTA EXTERNA',1,0)) AS  PLANTA_EXTERNA,
	SUM(IF(xx.nrubro='PLANTA INTERNA',1,0)) AS  PLANTA_INTERNA,
	SUM(IF(xx.nrubro='RED CLIENTE',1,0)) AS  RED_CLIENTE,
	SUM(IF(xx.nrubro='TRANSMISIONES',1,0)) AS  TRANSMISIONES,
	SUM(IF(xx.nrubro='FIBRA OPTICA',1,0)) AS FIBRA_OPTICA,
	COUNT(*) AS TOTAL FROM 
	(SELECT a.*,b.nrubro,CONCAT(c.jefatura,'_',c.sede) jefatura  FROM cms.`aver_liq_catv_pais` a INNER JOIN cms.`maquetacatv` b
	ON a.`codigodeliquidacion`=b.`CODLIQ`
	INNER JOIN ccm1.`zonales_nodos_eecc` c
		ON a.nodo=c.nodo
	WHERE DATEDIFF(NOW(),fecha_liquidacion)=0 AND a.contrata NOT IN (442,429,434,428) AND  a.codigomotivoreq IN ('R001','R002','R038','R040','R041','R042','R101','R102','R103','R413','R414','R415','R416','R417','R418','R422','R423','R424','R425','R426','R427')
	and TIMEDIFF(fecha_liquidacion,fecharegistro)>='24:00:00.000000'
	GROUP BY a.`codigoreq`) xx
	GROUP BY 1;
	
	truncate table liqhoyxrubro;
	insert into `liqhoyxrubro`
	SELECT a.jefatura,
	ROUND((a.ADMINISTRATIVA/(a.ADMINISTRATIVA+b.ADMINISTRATIVA))*100,0) AS 'ADMINISTRATIVA',
	ROUND((a.INEFECTIVA/(a.INEFECTIVA+b.INEFECTIVA))*100,0) AS 'INEFECTIVA',
	ROUND((a.PLANTA_EXTERNA/(a.PLANTA_EXTERNA+b.PLANTA_EXTERNA))*100,0) AS 'PLANTA_EXTERNA',
	ROUND((a.PLANTA_INTERNA/(a.PLANTA_INTERNA+b.PLANTA_INTERNA))*100,0) AS 'PLANTA_INTERNA',
	ROUND((a.RED_CLIENTE/(a.RED_CLIENTE+b.RED_CLIENTE))*100,0) AS 'RED_CLIENTE',
	ROUND((a.TRANSMISIONES/(a.TRANSMISIONES+b.TRANSMISIONES))*100,0) AS 'TRANSMISIONES',
	ROUND((a.FIBRA_OPTICA/(a.FIBRA_OPTICA+b.FIBRA_OPTICA))*100,0) AS 'FIBRA_OPTICA',
	ROUND((a.TOTAL/(a.TOTAL+b.TOTAL))*100,0) AS 'TOTAL'
	FROM `liqhoyxrubromenos24horas` a LEFT JOIN `liqhoyxrubromas24horas` b 
	ON a.jefatura=b.jefatura;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `criticos_view`
--

/*!50001 DROP TABLE IF EXISTS `criticos_view`*/;
/*!50001 DROP VIEW IF EXISTS `criticos_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`rfalla`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `criticos_view` AS (select `criticos`.`NODO` AS `nodo`,`criticos`.`TROBA` AS `troba`,count(0) AS `ncrit` from `criticos` where ((`criticos`.`NODO` is not null) and (`criticos`.`NODO` <> '')) group by `criticos`.`NODO`,`criticos`.`TROBA`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-23 13:00:52
