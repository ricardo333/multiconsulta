-- MySQL dump 10.16  Distrib 10.1.40-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: geoubica
-- ------------------------------------------------------
-- Server version	10.1.40-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente` (
  `codcliente` int(11) NOT NULL AUTO_INCREMENT,
  `nombreCliente` varchar(80) NOT NULL,
  `emailCliente` varchar(100) NOT NULL,
  `direccionCliente` varchar(120) NOT NULL,
  `latCliente` varchar(20) NOT NULL,
  `lngCliente` varchar(20) NOT NULL,
  PRIMARY KEY (`codcliente`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `geo_amplificador`
--

DROP TABLE IF EXISTS `geo_amplificador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geo_amplificador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zonal` varchar(4) DEFAULT NULL,
  `nodo` varchar(10) DEFAULT NULL,
  `troba` varchar(10) DEFAULT NULL,
  `amplificador` varchar(5) DEFAULT NULL,
  `coord_x` varchar(20) DEFAULT NULL,
  `coord_y` varchar(20) DEFAULT NULL,
  `orden` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_zonal` (`zonal`),
  KEY `idx_nodo` (`nodo`),
  KEY `idx_troba` (`troba`),
  KEY `idx_amplificador` (`amplificador`)
) ENGINE=MyISAM AUTO_INCREMENT=25452 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `geo_tap`
--

DROP TABLE IF EXISTS `geo_tap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geo_tap` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zonal` varchar(4) DEFAULT NULL,
  `nodo` varchar(10) DEFAULT NULL,
  `troba` varchar(10) DEFAULT NULL,
  `amplificador` varchar(10) DEFAULT NULL,
  `tap` varchar(10) DEFAULT NULL,
  `coord_x` varchar(20) DEFAULT NULL,
  `coord_y` varchar(20) DEFAULT NULL,
  `direccion` text,
  `orden` int(11) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_zonal` (`zonal`),
  KEY `idx_nodo` (`nodo`),
  KEY `idx_troba` (`troba`),
  KEY `idx_amplificador` (`amplificador`),
  KEY `idx_tap` (`tap`),
  KEY `orden` (`orden`)
) ENGINE=MyISAM AUTO_INCREMENT=143480 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `geo_troba`
--

DROP TABLE IF EXISTS `geo_troba`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geo_troba` (
  `pktrb` varchar(10) DEFAULT NULL,
  `zonal` varchar(3) DEFAULT NULL,
  `nodo` varchar(4) DEFAULT NULL,
  `troba` varchar(6) DEFAULT NULL,
  `x` double DEFAULT NULL,
  `y` double DEFAULT NULL,
  `fecha_insert` datetime DEFAULT NULL,
  `user_insert` int(11) DEFAULT NULL,
  `fecha_update` datetime DEFAULT NULL,
  `user_update` int(11) DEFAULT NULL,
  KEY `zonal` (`zonal`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `x` (`x`),
  KEY `y` (`y`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `geo_troba_poligono`
--

DROP TABLE IF EXISTS `geo_troba_poligono`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geo_troba_poligono` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zonal` varchar(5) DEFAULT NULL,
  `nodo` varchar(10) DEFAULT NULL,
  `troba` varchar(10) DEFAULT NULL,
  `coord_x` varchar(20) DEFAULT NULL,
  `coord_y` varchar(20) DEFAULT NULL,
  `orden` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_zonal` (`zonal`),
  KEY `idx_nodo` (`nodo`),
  KEY `idx_troba` (`troba`)
) ENGINE=MyISAM AUTO_INCREMENT=150975 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'geoubica'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-23 13:00:52
