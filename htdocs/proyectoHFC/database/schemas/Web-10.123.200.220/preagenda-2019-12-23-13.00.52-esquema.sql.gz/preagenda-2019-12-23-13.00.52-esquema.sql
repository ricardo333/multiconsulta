-- MySQL dump 10.16  Distrib 10.1.40-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: preagenda
-- ------------------------------------------------------
-- Server version	10.1.40-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agendas_mov`
--

DROP TABLE IF EXISTS `agendas_mov`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agendas_mov` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idagenda` int(11) DEFAULT NULL,
  `estado` varchar(80) DEFAULT NULL,
  `quiebre` varchar(80) DEFAULT NULL,
  `comentario` varchar(500) DEFAULT NULL,
  `fechamov` varchar(20) DEFAULT NULL,
  `usuario` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idagenda` (`idagenda`)
) ENGINE=MyISAM AUTO_INCREMENT=7973 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cuposxnodo`
--

DROP TABLE IF EXISTS `cuposxnodo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cuposxnodo` (
  `cupoxturno` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dia`
--

DROP TABLE IF EXISTS `dia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dia` (
  `fecha` varchar(10) NOT NULL,
  `dia` varchar(20) NOT NULL,
  PRIMARY KEY (`fecha`,`dia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `estados`
--

DROP TABLE IF EXISTS `estados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `estado` char(80) DEFAULT NULL,
  `sw` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nodocupos`
--

DROP TABLE IF EXISTS `nodocupos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nodocupos` (
  `nodo` varchar(2) DEFAULT NULL,
  `fecha` varchar(10) DEFAULT NULL,
  `turno` varchar(8) DEFAULT NULL,
  `cupo` int(11) DEFAULT NULL,
  UNIQUE KEY `nodo` (`nodo`,`fecha`,`turno`),
  KEY `nodo_2` (`nodo`),
  KEY `fecha` (`fecha`),
  KEY `turno` (`turno`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preagenda`
--

DROP TABLE IF EXISTS `preagenda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preagenda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codcli` int(11) DEFAULT NULL,
  `codserv` int(11) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `telefono1` int(10) DEFAULT NULL,
  `telefono2` int(10) DEFAULT NULL,
  `nameclient` varchar(150) DEFAULT NULL,
  `codreq` int(11) DEFAULT NULL,
  `comentario` varchar(500) DEFAULT NULL,
  `fecha` varchar(10) DEFAULT NULL,
  `rangohorario` varchar(10) DEFAULT NULL,
  `tipoagenda` varchar(2) DEFAULT NULL,
  `estado` varchar(80) DEFAULT NULL,
  `quiebre` varchar(80) DEFAULT NULL,
  `fecharegistroagenda` varchar(20) DEFAULT NULL,
  `tipocliagenda` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `codcli` (`codcli`),
  KEY `nodo` (`nodo`),
  KEY `telefono1` (`telefono1`),
  KEY `telefono2` (`telefono2`),
  KEY `codreq` (`codreq`)
) ENGINE=MyISAM AUTO_INCREMENT=8113 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `quiebre`
--

DROP TABLE IF EXISTS `quiebre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiebre` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quiebre` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `rangohorario`
--

DROP TABLE IF EXISTS `rangohorario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rangohorario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idturno` int(11) NOT NULL,
  `turno` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`,`idturno`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tipoturno`
--

DROP TABLE IF EXISTS `tipoturno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipoturno` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipoturno` varchar(30) DEFAULT NULL,
  `idrangohorario` int(11) NOT NULL,
  `tipoagenda` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`,`idrangohorario`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'preagenda'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-23 13:00:52
