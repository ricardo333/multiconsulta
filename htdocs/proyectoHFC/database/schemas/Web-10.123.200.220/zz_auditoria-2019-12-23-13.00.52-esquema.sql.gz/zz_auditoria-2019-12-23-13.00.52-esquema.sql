-- MySQL dump 10.16  Distrib 10.1.40-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: zz_auditoria
-- ------------------------------------------------------
-- Server version	10.1.40-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `log_acceso`
--

DROP TABLE IF EXISTS `log_acceso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_acceso` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `acceso_exitoso` char(2) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4331 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_actividad`
--

DROP TABLE IF EXISTS `log_actividad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_actividad` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `accion` varchar(15) NOT NULL,
  `user` varchar(50) DEFAULT NULL,
  `empresa` varchar(50) DEFAULT NULL,
  `rol` varchar(50) DEFAULT NULL,
  `new_empresa` varchar(50) DEFAULT NULL,
  `new_rol` varchar(50) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `estacion_trabajo` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_cm_activacion`
--

DROP TABLE IF EXISTS `log_cm_activacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_cm_activacion` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) DEFAULT NULL,
  `idcliente` varchar(50) DEFAULT NULL,
  `macAddress` varchar(17) DEFAULT NULL,
  `estado` varchar(50) DEFAULT NULL,
  `velocidad` varchar(50) DEFAULT NULL,
  `nuevoEstado` varchar(50) DEFAULT NULL,
  `motivo` text,
  `fecha` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_cm_reset_itw`
--

DROP TABLE IF EXISTS `log_cm_reset_itw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_cm_reset_itw` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) DEFAULT NULL,
  `codCliente` varchar(50) DEFAULT NULL,
  `servicio` varchar(50) DEFAULT NULL,
  `producto` varchar(50) DEFAULT NULL,
  `venta` varchar(50) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_cm_scopesgroup`
--

DROP TABLE IF EXISTS `log_cm_scopesgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_cm_scopesgroup` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) DEFAULT NULL,
  `idcliente` varchar(50) DEFAULT NULL,
  `macAddress` varchar(17) DEFAULT NULL,
  `scopeGroup` varchar(50) DEFAULT NULL,
  `nuevoScopeGroup` varchar(50) DEFAULT NULL,
  `motivo` text,
  `fecha` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_cm_velocidades`
--

DROP TABLE IF EXISTS `log_cm_velocidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_cm_velocidades` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) DEFAULT NULL,
  `idcliente` varchar(50) DEFAULT NULL,
  `macAddress` varchar(17) DEFAULT NULL,
  `velocidad` varchar(50) DEFAULT NULL,
  `nueva_velocidad` varchar(50) DEFAULT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `motivo` text,
  `fechaAccion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_modem_dhcp`
--

DROP TABLE IF EXISTS `log_modem_dhcp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_modem_dhcp` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `codCliente` varchar(50) NOT NULL,
  `macaddress` varchar(17) NOT NULL,
  `fabricante` varchar(30) NOT NULL,
  `modelo` varchar(30) DEFAULT NULL,
  `firmware` varchar(50) DEFAULT NULL,
  `dhcp_host` varchar(50) DEFAULT NULL,
  `dhcp_interface` varchar(50) DEFAULT NULL,
  `dhcp_mac` varchar(20) DEFAULT NULL,
  `dhcp_ip` varchar(20) DEFAULT NULL,
  `dhcp_nivel` varchar(10) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_modem_maping`
--

DROP TABLE IF EXISTS `log_modem_maping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_modem_maping` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `codCliente` varchar(50) NOT NULL,
  `macaddress` varchar(17) DEFAULT NULL,
  `fabricante` varchar(30) DEFAULT NULL,
  `modelo` varchar(30) DEFAULT NULL,
  `firmware` varchar(50) DEFAULT NULL,
  `operacion` varchar(20) DEFAULT NULL,
  `service` varchar(30) DEFAULT NULL,
  `ipLan` varchar(20) DEFAULT NULL,
  `protocolo` varchar(20) DEFAULT NULL,
  `privatePort` varchar(20) DEFAULT NULL,
  `publicPort` varchar(20) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_modem_status`
--

DROP TABLE IF EXISTS `log_modem_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_modem_status` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `codCliente` varchar(50) NOT NULL,
  `macaddress` varchar(17) NOT NULL,
  `fabricante` varchar(30) NOT NULL,
  `modelo` varchar(30) DEFAULT NULL,
  `firmware` varchar(50) DEFAULT NULL,
  `frecuencia_up1` varchar(12) DEFAULT NULL,
  `power_up1` varchar(5) DEFAULT NULL,
  `frecuencua_up2` varchar(12) DEFAULT NULL,
  `power_up2` varchar(5) DEFAULT NULL,
  `frecuencia_down1` varchar(12) DEFAULT NULL,
  `snr_down1` varchar(5) DEFAULT NULL,
  `power_down1` varchar(5) DEFAULT NULL,
  `frecuencia_down2` varchar(12) DEFAULT NULL,
  `snr_down2` varchar(5) DEFAULT NULL,
  `power_down2` varchar(5) DEFAULT NULL,
  `frecuencia_down3` varchar(12) DEFAULT NULL,
  `snr_down3` varchar(5) DEFAULT NULL,
  `power_down3` varchar(5) DEFAULT NULL,
  `frecuencia_down4` varchar(12) DEFAULT NULL,
  `snr_down4` varchar(5) DEFAULT NULL,
  `power_down4` varchar(5) DEFAULT NULL,
  `frecuencia_down5` varchar(12) DEFAULT NULL,
  `snr_down5` varchar(5) DEFAULT NULL,
  `power_down5` varchar(5) DEFAULT NULL,
  `frecuencia_down6` varchar(12) DEFAULT NULL,
  `snr_down6` varchar(5) DEFAULT NULL,
  `power_down6` varchar(5) DEFAULT NULL,
  `frecuencia_down7` varchar(12) DEFAULT NULL,
  `snr_down7` varchar(5) DEFAULT NULL,
  `power_down7` varchar(5) DEFAULT NULL,
  `frecuencia_down8` varchar(12) DEFAULT NULL,
  `snr_down8` varchar(5) DEFAULT NULL,
  `power_down8` varchar(5) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=194 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_modem_wifi`
--

DROP TABLE IF EXISTS `log_modem_wifi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_modem_wifi` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) DEFAULT NULL,
  `codCliente` varchar(50) DEFAULT NULL,
  `macaddress` varchar(17) DEFAULT NULL,
  `fabricante` varchar(30) DEFAULT NULL,
  `modelo` varchar(30) DEFAULT NULL,
  `firmware` varchar(50) DEFAULT NULL,
  `ssid` varchar(30) DEFAULT NULL,
  `interface` varchar(30) DEFAULT NULL,
  `channel` varchar(5) DEFAULT NULL,
  `bandwidth` varchar(12) DEFAULT NULL,
  `power` varchar(10) DEFAULT NULL,
  `secutiry1` varchar(50) DEFAULT NULL,
  `security2` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `ssid5G` varchar(30) DEFAULT NULL,
  `interface5G` varchar(30) DEFAULT NULL,
  `channel5G` varchar(5) DEFAULT NULL,
  `bandwidth5G` varchar(12) DEFAULT NULL,
  `power5G` varchar(10) DEFAULT NULL,
  `security5G` varchar(50) DEFAULT NULL,
  `password5G` varchar(50) DEFAULT NULL,
  `ssid_nuevo` varchar(30) DEFAULT NULL,
  `interface_nuevo` varchar(30) DEFAULT NULL,
  `channel_nuevo` varchar(5) DEFAULT NULL,
  `bandwidth_nuevo` varchar(12) DEFAULT NULL,
  `power_nuevo` varchar(10) DEFAULT NULL,
  `secutiry1_nuevo` varchar(50) DEFAULT NULL,
  `security2_nuevo` varchar(50) DEFAULT NULL,
  `password_nuevo` varchar(50) DEFAULT NULL,
  `ssid5G_nuevo` varchar(30) DEFAULT NULL,
  `interface5G_nuevo` varchar(30) DEFAULT NULL,
  `channel5G_nuevo` varchar(5) DEFAULT NULL,
  `bandwidth5G_nuevo` varchar(12) DEFAULT NULL,
  `power5G_nuevo` varchar(10) DEFAULT NULL,
  `security5G_nuevo` varchar(50) DEFAULT NULL,
  `password5G_nuevo` varchar(50) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_opciones_criticas`
--

DROP TABLE IF EXISTS `log_opciones_criticas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_opciones_criticas` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `empresa` varchar(50) DEFAULT NULL,
  `rol` varchar(50) DEFAULT NULL,
  `estado` char(1) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `direccion_ip` varchar(15) DEFAULT NULL,
  `estacion_trabajo` varchar(50) DEFAULT NULL,
  `sistema_operativo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_password`
--

DROP TABLE IF EXISTS `log_password`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_password` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) DEFAULT NULL,
  `pass_old` varchar(100) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=150 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'zz_auditoria'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-23 13:00:52
