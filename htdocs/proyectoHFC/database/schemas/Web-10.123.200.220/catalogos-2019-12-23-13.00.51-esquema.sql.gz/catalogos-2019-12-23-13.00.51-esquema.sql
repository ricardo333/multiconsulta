-- MySQL dump 10.16  Distrib 10.1.40-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: catalogos
-- ------------------------------------------------------
-- Server version	10.1.40-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activo_movistar1`
--

DROP TABLE IF EXISTS `activo_movistar1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activo_movistar1` (
  `codcliente` int(11) DEFAULT NULL,
  `codsrv` int(11) DEFAULT NULL,
  `codoficadm` char(3) DEFAULT NULL,
  `condclite` char(3) DEFAULT NULL,
  `desccondcl` char(10) DEFAULT NULL,
  `condides` char(3) DEFAULT NULL,
  `descconsrv` char(10) DEFAULT NULL,
  `casid` char(20) DEFAULT NULL,
  `serie` char(20) DEFAULT NULL,
  `edocompxsr` char(1) DEFAULT NULL,
  `codelemsrv` char(3) DEFAULT NULL,
  `apepater` char(20) DEFAULT NULL,
  `apemat` char(20) DEFAULT NULL,
  `nombclt` char(20) DEFAULT NULL,
  `ultcodreq` char(10) DEFAULT NULL,
  `tiporeqate` char(3) DEFAULT NULL,
  `tipoadqui` char(1) DEFAULT NULL,
  `codcta` char(2) DEFAULT NULL,
  `codreqsrv` char(10) DEFAULT NULL,
  `tipocobr` char(50) DEFAULT NULL,
  `coddoc` char(10) DEFAULT NULL,
  `tipomontob` char(10) DEFAULT NULL,
  `nrocuota` char(10) DEFAULT NULL,
  `importetot` char(10) DEFAULT NULL,
  `importesal` char(10) DEFAULT NULL,
  `imporpagar` char(10) DEFAULT NULL,
  `codigotari` char(10) DEFAULT NULL,
  `descrtarif` char(10) DEFAULT NULL,
  `importota` char(10) DEFAULT NULL,
  `importtari` char(10) DEFAULT NULL,
  `codigesta` char(10) DEFAULT NULL,
  `codestareq` char(2) DEFAULT NULL,
  `estareqate` char(15) DEFAULT NULL,
  `secuencia` char(5) DEFAULT NULL,
  `claseserv` char(5) DEFAULT NULL,
  `descrclase` char(15) DEFAULT NULL,
  `motivo` char(5) DEFAULT NULL,
  `desmotivo` char(20) DEFAULT NULL,
  `codmat` char(50) DEFAULT NULL,
  `idbb` char(50) DEFAULT NULL,
  `descbb` char(50) DEFAULT NULL,
  `velocmode` char(50) DEFAULT NULL,
  `fecha_ini` char(20) DEFAULT NULL,
  `elementarj` char(5) DEFAULT NULL,
  `serietarj` char(15) DEFAULT NULL,
  `secutarj` char(3) DEFAULT NULL,
  `estatarj` char(2) DEFAULT NULL,
  `des_bk` char(50) DEFAULT NULL,
  `idproducto` int(20) DEFAULT NULL,
  `fecha_carga` char(10) DEFAULT NULL,
  `fecha_ini_date` date DEFAULT NULL,
  `otro` char(20) DEFAULT NULL,
  KEY `codcliente` (`codcliente`),
  KEY `codsrv` (`codsrv`),
  KEY `serie` (`serie`),
  KEY `idproducto` (`idproducto`),
  KEY `condclite` (`condclite`),
  KEY `condides` (`condides`),
  KEY `edocompxsr` (`edocompxsr`),
  KEY `desccondcl` (`desccondcl`),
  KEY `descconsrv` (`descconsrv`),
  KEY `index_codelemsrv` (`codelemsrv`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `amplifxpuerto`
--

DROP TABLE IF EXISTS `amplifxpuerto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `amplifxpuerto` (
  `cmts` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `f_v` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `nodo` varchar(2) CHARACTER SET latin1 DEFAULT NULL,
  `troba` varchar(4) CHARACTER SET latin1 DEFAULT NULL,
  `amplificador` varchar(11) CHARACTER SET latin1 DEFAULT NULL,
  UNIQUE KEY `cmts` (`cmts`,`f_v`,`nodo`,`troba`,`amplificador`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `amplificador` (`amplificador`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `analgesico`
--

DROP TABLE IF EXISTS `analgesico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `analgesico` (
  `ClienteCms` int(11) DEFAULT NULL,
  `mensaje` varchar(200) DEFAULT NULL,
  UNIQUE KEY `codcli` (`ClienteCms`),
  KEY `mensaje` (`mensaje`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `analgesico_c`
--

DROP TABLE IF EXISTS `analgesico_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `analgesico_c` (
  `ClienteCms` int(11) DEFAULT NULL,
  `mensaje` varchar(200) DEFAULT NULL,
  UNIQUE KEY `codcli` (`ClienteCms`),
  KEY `mensaje` (`mensaje`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `analgesico_test_a`
--

DROP TABLE IF EXISTS `analgesico_test_a`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `analgesico_test_a` (
  `ClienteCms` int(11) DEFAULT NULL,
  `mensaje` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `analgesico_test_b`
--

DROP TABLE IF EXISTS `analgesico_test_b`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `analgesico_test_b` (
  `ClienteCms` int(11) DEFAULT NULL,
  `mensaje` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `arboldecisiones`
--

DROP TABLE IF EXISTS `arboldecisiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `arboldecisiones` (
  `item1` int(11) DEFAULT NULL,
  `datos1` varchar(100) DEFAULT NULL,
  `item2` int(11) DEFAULT NULL,
  `datos2` varchar(100) DEFAULT NULL,
  `item3` int(11) DEFAULT NULL,
  `datos3` varchar(100) DEFAULT NULL,
  `item4` int(11) DEFAULT NULL,
  `datos4` varchar(100) DEFAULT NULL,
  `item5` int(11) DEFAULT NULL,
  `datos5` varchar(100) DEFAULT NULL,
  `item6` int(11) DEFAULT NULL,
  `datos6` varchar(100) DEFAULT NULL,
  UNIQUE KEY `item1` (`item1`,`item2`,`item3`,`item4`,`item5`,`item6`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `area_responsable`
--

DROP TABLE IF EXISTS `area_responsable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_responsable` (
  `idarea` int(11) NOT NULL AUTO_INCREMENT,
  `area` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`idarea`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `averias_resum`
--

DROP TABLE IF EXISTS `averias_resum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `averias_resum` (
  `nodo` varchar(10) DEFAULT NULL,
  `troba` varchar(10) DEFAULT NULL,
  `dia` varchar(13) DEFAULT NULL,
  `aver` bigint(21) NOT NULL,
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `dia` (`dia`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `averias_resum_c`
--

DROP TABLE IF EXISTS `averias_resum_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `averias_resum_c` (
  `nodo` varchar(10) DEFAULT NULL,
  `troba` varchar(10) DEFAULT NULL,
  `dia` varchar(13) DEFAULT NULL,
  `aver` bigint(21) NOT NULL,
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `dia` (`dia`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bandejaex`
--

DROP TABLE IF EXISTS `bandejaex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bandejaex` (
  `codctr` int(11) DEFAULT NULL,
  `detalle` varchar(50) DEFAULT NULL,
  `tipave` varchar(1) DEFAULT NULL,
  KEY `codctr` (`codctr`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bornesxtroba`
--

DROP TABLE IF EXISTS `bornesxtroba`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bornesxtroba` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `numbor` int(11) DEFAULT NULL,
  `tipo` varchar(20) DEFAULT NULL,
  KEY `NewIndex1` (`nodo`),
  KEY `NewIndex2` (`troba`),
  KEY `NewIndex3` (`tipo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cablemodem_glciexp054_decos`
--

DROP TABLE IF EXISTS `cablemodem_glciexp054_decos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cablemodem_glciexp054_decos` (
  `codcliente` int(11) DEFAULT NULL,
  `codsrv` int(11) DEFAULT NULL,
  `codoficadm` char(3) DEFAULT NULL,
  `condclite` char(3) DEFAULT NULL,
  `desccondcl` char(10) DEFAULT NULL,
  `condides` char(3) DEFAULT NULL,
  `descconsrv` char(10) DEFAULT NULL,
  `casid` char(20) DEFAULT NULL,
  `serie` char(20) DEFAULT NULL,
  `edocompxsr` char(1) DEFAULT NULL,
  `codelemsrv` char(3) DEFAULT NULL,
  `apepater` char(20) DEFAULT NULL,
  `apemat` char(20) DEFAULT NULL,
  `nombclt` char(20) DEFAULT NULL,
  `ultcodreq` char(10) DEFAULT NULL,
  `tiporeqate` char(3) DEFAULT NULL,
  `tipoadqui` char(1) DEFAULT NULL,
  `codcta` char(2) DEFAULT NULL,
  `codreqsrv` char(10) DEFAULT NULL,
  `tipocobr` char(50) DEFAULT NULL,
  `coddoc` char(10) DEFAULT NULL,
  `tipomontob` char(10) DEFAULT NULL,
  `nrocuota` char(10) DEFAULT NULL,
  `importetot` char(10) DEFAULT NULL,
  `importesal` char(10) DEFAULT NULL,
  `imporpagar` char(10) DEFAULT NULL,
  `codigotari` char(10) DEFAULT NULL,
  `descrtarif` char(10) DEFAULT NULL,
  `importota` char(10) DEFAULT NULL,
  `importtari` char(10) DEFAULT NULL,
  `codigesta` char(10) DEFAULT NULL,
  `codestareq` char(2) DEFAULT NULL,
  `estareqate` char(15) DEFAULT NULL,
  `secuencia` char(5) DEFAULT NULL,
  `claseserv` char(5) DEFAULT NULL,
  `descrclase` char(15) DEFAULT NULL,
  `motivo` char(5) DEFAULT NULL,
  `desmotivo` char(20) DEFAULT NULL,
  `codmat` char(50) DEFAULT NULL,
  `idbb` char(50) DEFAULT NULL,
  `descbb` char(50) DEFAULT NULL,
  `velocmode` char(50) DEFAULT NULL,
  `fecha_ini` char(20) DEFAULT NULL,
  `elementarj` char(5) DEFAULT NULL,
  `serietarj` char(15) DEFAULT NULL,
  `secutarj` char(3) DEFAULT NULL,
  `estatarj` char(2) DEFAULT NULL,
  `des_bk` char(50) DEFAULT NULL,
  `idproducto` varchar(20) DEFAULT NULL,
  `fecha_carga` char(10) DEFAULT NULL,
  `fecha_ini_date` date DEFAULT NULL,
  `otro` char(20) DEFAULT NULL,
  KEY `codcliente` (`codcliente`),
  KEY `codsrv` (`codsrv`),
  KEY `serie` (`serie`),
  KEY `idproducto` (`idproducto`),
  KEY `edocompxsr` (`edocompxsr`),
  KEY `casid` (`casid`),
  KEY `serietarj` (`serietarj`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cablemodem_glciexp054_decos_c`
--

DROP TABLE IF EXISTS `cablemodem_glciexp054_decos_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cablemodem_glciexp054_decos_c` (
  `codcliente` int(11) DEFAULT NULL,
  `codsrv` int(11) DEFAULT NULL,
  `codoficadm` char(3) DEFAULT NULL,
  `condclite` char(3) DEFAULT NULL,
  `desccondcl` char(10) DEFAULT NULL,
  `condides` char(3) DEFAULT NULL,
  `descconsrv` char(10) DEFAULT NULL,
  `casid` char(20) DEFAULT NULL,
  `serie` char(20) DEFAULT NULL,
  `edocompxsr` char(1) DEFAULT NULL,
  `codelemsrv` char(3) DEFAULT NULL,
  `apepater` char(20) DEFAULT NULL,
  `apemat` char(20) DEFAULT NULL,
  `nombclt` char(20) DEFAULT NULL,
  `ultcodreq` char(10) DEFAULT NULL,
  `tiporeqate` char(3) DEFAULT NULL,
  `tipoadqui` char(1) DEFAULT NULL,
  `codcta` char(2) DEFAULT NULL,
  `codreqsrv` char(10) DEFAULT NULL,
  `tipocobr` char(50) DEFAULT NULL,
  `coddoc` char(10) DEFAULT NULL,
  `tipomontob` char(10) DEFAULT NULL,
  `nrocuota` char(10) DEFAULT NULL,
  `importetot` char(10) DEFAULT NULL,
  `importesal` char(10) DEFAULT NULL,
  `imporpagar` char(10) DEFAULT NULL,
  `codigotari` char(10) DEFAULT NULL,
  `descrtarif` char(10) DEFAULT NULL,
  `importota` char(10) DEFAULT NULL,
  `importtari` char(10) DEFAULT NULL,
  `codigesta` char(10) DEFAULT NULL,
  `codestareq` char(2) DEFAULT NULL,
  `estareqate` char(15) DEFAULT NULL,
  `secuencia` char(5) DEFAULT NULL,
  `claseserv` char(5) DEFAULT NULL,
  `descrclase` char(15) DEFAULT NULL,
  `motivo` char(5) DEFAULT NULL,
  `desmotivo` char(20) DEFAULT NULL,
  `codmat` char(50) DEFAULT NULL,
  `idbb` char(50) DEFAULT NULL,
  `descbb` char(50) DEFAULT NULL,
  `velocmode` char(50) DEFAULT NULL,
  `fecha_ini` char(20) DEFAULT NULL,
  `elementarj` char(5) DEFAULT NULL,
  `serietarj` char(15) DEFAULT NULL,
  `secutarj` char(3) DEFAULT NULL,
  `estatarj` char(2) DEFAULT NULL,
  `des_bk` char(50) DEFAULT NULL,
  `idproducto` varchar(20) DEFAULT NULL,
  `fecha_carga` char(10) DEFAULT NULL,
  `fecha_ini_date` date DEFAULT NULL,
  `otro` char(20) DEFAULT NULL,
  KEY `codcliente` (`codcliente`),
  KEY `codsrv` (`codsrv`),
  KEY `serie` (`serie`),
  KEY `idproducto` (`idproducto`),
  KEY `edocompxsr` (`edocompxsr`),
  KEY `casid` (`casid`),
  KEY `serietarj` (`serietarj`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `causaalert`
--

DROP TABLE IF EXISTS `causaalert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `causaalert` (
  `idcausa` int(11) NOT NULL AUTO_INCREMENT,
  `causa` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`idcausa`)
) ENGINE=MyISAM AUTO_INCREMENT=296 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `clientesxpuerto`
--

DROP TABLE IF EXISTS `clientesxpuerto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientesxpuerto` (
  `cmts` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `interface` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `cantcli` bigint(21) NOT NULL,
  UNIQUE KEY `cmts_2` (`cmts`,`interface`),
  KEY `cmts` (`cmts`),
  KEY `interface` (`interface`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `codcontrata`
--

DROP TABLE IF EXISTS `codcontrata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `codcontrata` (
  `codctr_rdc` int(11) NOT NULL,
  `codctr_pext` int(11) NOT NULL,
  `description` varchar(100) NOT NULL,
  `area_mant` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`codctr_rdc`,`codctr_pext`,`description`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `codcontrata_c`
--

DROP TABLE IF EXISTS `codcontrata_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `codcontrata_c` (
  `codctr_rdc` int(11) NOT NULL,
  `codctr_pext` int(11) NOT NULL,
  `description` varchar(100) NOT NULL,
  `area_mant` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`codctr_rdc`,`codctr_pext`,`description`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `codctr`
--

DROP TABLE IF EXISTS `codctr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `codctr` (
  `codctr` int(11) NOT NULL,
  `tipo` varchar(30) DEFAULT NULL,
  `desctr` varchar(100) DEFAULT NULL,
  `tiposeg` varchar(10) DEFAULT NULL,
  `tipoplta` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`codctr`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `colexcel`
--

DROP TABLE IF EXISTS `colexcel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `colexcel` (
  `item` int(11) NOT NULL AUTO_INCREMENT,
  `col` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`item`)
) ENGINE=MyISAM AUTO_INCREMENT=703 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contrata`
--

DROP TABLE IF EXISTS `contrata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contrata` (
  `contrata` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `convergente`
--

DROP TABLE IF EXISTS `convergente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `convergente` (
  `TELEFONO` int(11) DEFAULT NULL,
  `DOCUMENTO` int(11) DEFAULT NULL,
  `codigo` int(11) NOT NULL,
  `COD_CUENTA` int(11) DEFAULT NULL,
  `INSCRIPCION` int(11) DEFAULT NULL,
  `SEGMENTACION_FIJA` varchar(100) DEFAULT NULL,
  `TENENCIA` varchar(100) DEFAULT NULL,
  `CELULAR` int(11) DEFAULT NULL,
  `MOVIL_SEGMENTACION` varchar(10) DEFAULT NULL,
  `MOVIL_COD_CLIENTE` int(11) DEFAULT NULL,
  `MOVIL_ANEXO` int(11) DEFAULT NULL,
  `MOVIL_DOCUMENTO` int(11) DEFAULT NULL,
  `FuenteCD` varchar(100) DEFAULT NULL,
  `DISTRITO` varchar(100) DEFAULT NULL,
  `FILTRO_TMP` varchar(100) DEFAULT NULL,
  `FLAG_CONTEO` int(11) DEFAULT NULL,
  `ENVIADO_KAREN` int(11) DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `db_fuentes`
--

DROP TABLE IF EXISTS `db_fuentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_fuentes` (
  `nodo` varchar(2) CHARACTER SET latin1 DEFAULT NULL,
  `troba` varchar(4) CHARACTER SET latin1 DEFAULT NULL,
  `mac` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `mac3` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `mac4` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `zonal` varchar(10) DEFAULT NULL,
  `distrito` varchar(80) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `latitudx` varchar(20) DEFAULT NULL,
  `longitudy` varchar(20) DEFAULT NULL,
  `marcatroba` varchar(30) DEFAULT NULL,
  `respaldo` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `descricion` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `tienebateria` varchar(1) CHARACTER SET latin1 DEFAULT NULL,
  `clave` varchar(6) CHARACTER SET latin1 DEFAULT NULL,
  `segundafuente` varchar(1) DEFAULT NULL,
  `version` int(1) DEFAULT NULL,
  UNIQUE KEY `mac` (`mac`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `clave` (`clave`),
  KEY `zonal` (`zonal`),
  KEY `distrito` (`distrito`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dias`
--

DROP TABLE IF EXISTS `dias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dias` (
  `dia` int(11) NOT NULL AUTO_INCREMENT,
  `desdia` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`dia`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dirfuentes`
--

DROP TABLE IF EXISTS `dirfuentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dirfuentes` (
  `item` int(11) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `macaddress` varchar(20) DEFAULT NULL,
  `distrito` varchar(100) DEFAULT NULL,
  `direccion` varchar(1000) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `dmpe_view`
--

DROP TABLE IF EXISTS `dmpe_view`;
/*!50001 DROP VIEW IF EXISTS `dmpe_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `dmpe_view` (
  `fecha` tinyint NOT NULL,
  `hora` tinyint NOT NULL,
  `resultado` tinyint NOT NULL,
  `Cant` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `enlacexmarca`
--

DROP TABLE IF EXISTS `enlacexmarca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enlacexmarca` (
  `fabricante` varchar(20) DEFAULT NULL,
  `link` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `espacios_vacios_iw`
--

DROP TABLE IF EXISTS `espacios_vacios_iw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `espacios_vacios_iw` (
  `ID_Empresa` varchar(5) DEFAULT NULL,
  `Empresa` varchar(5) DEFAULT NULL,
  `ID_Cliente` double DEFAULT NULL,
  `Nombre_Cliente` varchar(150) DEFAULT NULL,
  `ID_Servicio_CM` double DEFAULT NULL,
  `ID_Producto_CM` double DEFAULT NULL,
  `ID_Venta_CM` double DEFAULT NULL,
  `Service_Package_CRMID` varchar(30) DEFAULT NULL,
  `Service_Package_Configurado` varchar(30) DEFAULT NULL,
  `Cantidad_PCs` varchar(11) DEFAULT NULL,
  `Fecha_Alta` varchar(20) DEFAULT NULL,
  `Grupo_Red_CM` varchar(20) DEFAULT NULL,
  `ID_Servicio_MTA` varchar(100) DEFAULT NULL,
  `ID_Producto_MTA` varchar(100) DEFAULT NULL,
  `ID_Venta_MTA` varchar(100) DEFAULT NULL,
  `Grupo_Red_MTA` varchar(100) DEFAULT NULL,
  `Numero_Telefono` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `etiqueta_puertos`
--

DROP TABLE IF EXISTS `etiqueta_puertos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etiqueta_puertos` (
  `cmts` varchar(20) DEFAULT NULL,
  `interface` varchar(20) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  UNIQUE KEY `cmts_2` (`cmts`,`interface`),
  KEY `cmts` (`cmts`),
  KEY `interface` (`interface`),
  KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `etiqueta_puertos_20191213`
--

DROP TABLE IF EXISTS `etiqueta_puertos_20191213`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etiqueta_puertos_20191213` (
  `cmts` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `interface` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `description` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `fecha_hora` varchar(20) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `etiqueta_puertos_20191214`
--

DROP TABLE IF EXISTS `etiqueta_puertos_20191214`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etiqueta_puertos_20191214` (
  `cmts` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `interface` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `description` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `fecha_hora` varchar(20) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `etiqueta_puertos_20191215`
--

DROP TABLE IF EXISTS `etiqueta_puertos_20191215`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etiqueta_puertos_20191215` (
  `cmts` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `interface` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `description` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `fecha_hora` varchar(20) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `etiqueta_puertos_20191216`
--

DROP TABLE IF EXISTS `etiqueta_puertos_20191216`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etiqueta_puertos_20191216` (
  `cmts` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `interface` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `description` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `fecha_hora` varchar(20) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `etiqueta_puertos_20191217`
--

DROP TABLE IF EXISTS `etiqueta_puertos_20191217`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etiqueta_puertos_20191217` (
  `cmts` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `interface` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `description` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `fecha_hora` varchar(20) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `etiqueta_puertos_20191218`
--

DROP TABLE IF EXISTS `etiqueta_puertos_20191218`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etiqueta_puertos_20191218` (
  `cmts` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `interface` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `description` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `fecha_hora` varchar(20) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `etiqueta_puertos_20191219`
--

DROP TABLE IF EXISTS `etiqueta_puertos_20191219`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etiqueta_puertos_20191219` (
  `cmts` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `interface` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `description` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `fecha_hora` varchar(20) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `etiqueta_puertos_20191220`
--

DROP TABLE IF EXISTS `etiqueta_puertos_20191220`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etiqueta_puertos_20191220` (
  `cmts` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `interface` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `description` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `fecha_hora` varchar(20) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `etiqueta_puertos_20191221`
--

DROP TABLE IF EXISTS `etiqueta_puertos_20191221`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etiqueta_puertos_20191221` (
  `cmts` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `interface` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `description` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `fecha_hora` varchar(20) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `etiqueta_puertos_20191222`
--

DROP TABLE IF EXISTS `etiqueta_puertos_20191222`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etiqueta_puertos_20191222` (
  `cmts` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `interface` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `description` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `fecha_hora` varchar(20) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `etiqueta_puertos_20191223`
--

DROP TABLE IF EXISTS `etiqueta_puertos_20191223`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etiqueta_puertos_20191223` (
  `cmts` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `interface` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `description` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `fecha_hora` varchar(20) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `etiqueta_puertos_c`
--

DROP TABLE IF EXISTS `etiqueta_puertos_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etiqueta_puertos_c` (
  `cmts` varchar(20) DEFAULT NULL,
  `interface` varchar(20) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `fecha_hora` varchar(20) DEFAULT NULL,
  UNIQUE KEY `cmts_2` (`cmts`,`interface`),
  KEY `cmts` (`cmts`),
  KEY `interface` (`interface`),
  KEY `description` (`description`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `etiqueta_puertos_new`
--

DROP TABLE IF EXISTS `etiqueta_puertos_new`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etiqueta_puertos_new` (
  `cmts` varchar(60) DEFAULT NULL,
  `interface` varchar(20) DEFAULT NULL,
  `troba` varchar(20) DEFAULT NULL,
  `equipo_origen` varchar(60) DEFAULT NULL,
  UNIQUE KEY `cmts` (`cmts`,`interface`),
  KEY `cmts_2` (`cmts`),
  KEY `interface` (`interface`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `excepciones`
--

DROP TABLE IF EXISTS `excepciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `excepciones` (
  `EMPRESA` varchar(3) DEFAULT NULL,
  `IDCLIENTECRM` double DEFAULT NULL,
  `idempresacrm` int(11) DEFAULT NULL,
  `idservicio` int(11) DEFAULT NULL,
  `idproducto` double DEFAULT NULL,
  `idventa` double DEFAULT NULL,
  `NAMECLIENT` varchar(100) DEFAULT NULL,
  `NODO` varchar(2) DEFAULT NULL,
  `TROBA` varchar(4) DEFAULT NULL,
  `amplificador` varchar(11) DEFAULT NULL,
  `tap` varchar(11) DEFAULT NULL,
  `telf1` varchar(10) DEFAULT NULL,
  `telf2` varchar(10) DEFAULT NULL,
  `f_v` varchar(20) DEFAULT NULL,
  `regver` varchar(3) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `SERVICEPACKAGECRMID` varchar(50) DEFAULT NULL,
  `SERVICEPACKAGE` varchar(50) DEFAULT NULL,
  `CANTPCS` varchar(11) DEFAULT NULL,
  `FECHAALTA` varchar(20) DEFAULT NULL,
  `FECHAACTIVACION` varchar(20) DEFAULT NULL,
  `ESTADO` varchar(10) DEFAULT NULL,
  `SCOPESGROUP` varchar(15) DEFAULT NULL,
  `SCOPESGROUPCM` varchar(15) DEFAULT NULL,
  `SCOPESGROUPMTA` varchar(15) DEFAULT NULL,
  `MTAMAC` varchar(20) DEFAULT NULL,
  `IDSERVICIOMTA` varchar(15) DEFAULT NULL,
  `IDPRODUCTOMTA` varchar(15) DEFAULT NULL,
  `IDVENTAMTA` varchar(15) DEFAULT NULL,
  `MTAMODELNAME` varchar(50) DEFAULT NULL,
  `CMTSID` varchar(11) DEFAULT NULL,
  `UBICACIONENLARED` varchar(150) DEFAULT NULL,
  `IPCM` varchar(20) DEFAULT NULL,
  `DOCSISVERSION` varchar(11) DEFAULT NULL,
  `movil1` varchar(20) DEFAULT NULL,
  `mac2` varchar(20) DEFAULT NULL,
  `mac3` varchar(20) DEFAULT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `codserv` varchar(20) DEFAULT NULL,
  `fecha_upload` datetime DEFAULT NULL,
  `naked` varchar(2) DEFAULT NULL,
  `numcoo_x` varchar(20) DEFAULT NULL,
  `numcoo_y` varchar(20) DEFAULT NULL,
  `fecha_inic` varchar(20) DEFAULT NULL,
  `fecha_fin` varchar(20) DEFAULT NULL,
  `devuelto` varchar(1) DEFAULT NULL,
  `nvel` varchar(20) DEFAULT NULL,
  `subido` varchar(1) DEFAULT NULL,
  `usuario` varchar(50) DEFAULT NULL,
  `fechacambio` varchar(20) DEFAULT NULL,
  UNIQUE KEY `IDCLIENTECRM` (`IDCLIENTECRM`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `expertowifi`
--

DROP TABLE IF EXISTS `expertowifi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expertowifi` (
  `nodotroba` varchar(6) NOT NULL,
  `microzona` varchar(30) DEFAULT NULL,
  `grupo_microzona` varchar(30) DEFAULT NULL,
  `identifica` varchar(30) DEFAULT NULL,
  `cant` int(11) DEFAULT NULL,
  `marca` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`nodotroba`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fechas`
--

DROP TABLE IF EXISTS `fechas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fechas` (
  `fecha` varchar(10) NOT NULL,
  PRIMARY KEY (`fecha`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `frecuencia85`
--

DROP TABLE IF EXISTS `frecuencia85`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `frecuencia85` (
  `docsis` varchar(7) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `Empresa` varchar(3) CHARACTER SET latin1 DEFAULT NULL,
  `NroCliente` double DEFAULT NULL,
  `Nombre` varchar(200) CHARACTER SET latin1 DEFAULT NULL,
  `MACAddress` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `Fechadealta` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `Fechadeactivacion` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `Fabricante` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `Modelo` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `hwversion` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `Versioon` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `Tipodedispositivo` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `IPCablemodem` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `CMTS` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `temp` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `fecha_upload` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fuentes_compartidas`
--

DROP TABLE IF EXISTS `fuentes_compartidas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fuentes_compartidas` (
  `hija` varchar(6) NOT NULL,
  `madre` varchar(6) DEFAULT NULL,
  `cant` int(11) DEFAULT NULL,
  PRIMARY KEY (`hija`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `horas`
--

DROP TABLE IF EXISTS `horas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `horas` (
  `HORAS` varchar(5) NOT NULL DEFAULT '',
  PRIMARY KEY (`HORAS`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inf_hfc_dmpe`
--

DROP TABLE IF EXISTS `inf_hfc_dmpe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inf_hfc_dmpe` (
  `fecha` varchar(20) DEFAULT NULL,
  `origen` varchar(50) DEFAULT NULL,
  `eventid` int(11) DEFAULT NULL,
  `area` int(11) DEFAULT NULL,
  `telefono` int(25) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL,
  `nodo` varchar(100) DEFAULT NULL,
  `troba` varchar(200) DEFAULT NULL,
  `cliente` int(11) DEFAULT NULL,
  `agente` varchar(200) DEFAULT NULL,
  `seleccion` varchar(500) DEFAULT NULL,
  `usuario` varchar(50) DEFAULT NULL,
  `fechaticket` varchar(20) DEFAULT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  UNIQUE KEY `fecha_2` (`fecha`,`eventid`,`telefono`,`cliente`),
  KEY `fecha` (`fecha`),
  KEY `origen` (`origen`),
  KEY `eventid` (`eventid`),
  KEY `area` (`area`),
  KEY `telefono` (`telefono`),
  KEY `estado` (`estado`),
  KEY `cliente` (`cliente`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inf_hfc_dmpe_c`
--

DROP TABLE IF EXISTS `inf_hfc_dmpe_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inf_hfc_dmpe_c` (
  `fecha` varchar(20) DEFAULT NULL,
  `origen` varchar(50) DEFAULT NULL,
  `eventid` int(20) DEFAULT NULL,
  `area` int(11) DEFAULT NULL,
  `telefono` int(25) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL,
  `nodo` varchar(100) DEFAULT NULL,
  `troba` varchar(200) DEFAULT NULL,
  `cliente` int(11) DEFAULT NULL,
  `agente` varchar(200) DEFAULT NULL,
  `seleccion` varchar(500) DEFAULT NULL,
  `usuario` varchar(50) DEFAULT NULL,
  `fechaticket` varchar(20) DEFAULT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  `telf_comp` int(11) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  UNIQUE KEY `fecha_2` (`fecha`,`eventid`,`telefono`,`cliente`),
  KEY `fecha` (`fecha`),
  KEY `origen` (`origen`),
  KEY `eventid` (`eventid`),
  KEY `area` (`area`),
  KEY `telefono` (`telefono`),
  KEY `estado` (`estado`),
  KEY `telf_comp` (`telf_comp`),
  KEY `fechahora` (`fechahora`),
  KEY `cliente` (`cliente`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inf_hfc_dmpe_d`
--

DROP TABLE IF EXISTS `inf_hfc_dmpe_d`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inf_hfc_dmpe_d` (
  `fecha` varchar(20) DEFAULT NULL,
  `origen` varchar(50) DEFAULT NULL,
  `eventid` int(11) DEFAULT NULL,
  `area` int(11) DEFAULT NULL,
  `telefono` int(25) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL,
  `nodo` varchar(100) DEFAULT NULL,
  `troba` varchar(200) DEFAULT NULL,
  `cliente` int(11) DEFAULT NULL,
  `agente` varchar(200) DEFAULT NULL,
  `seleccion` varchar(500) DEFAULT NULL,
  `fechaticket` varchar(20) DEFAULT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  UNIQUE KEY `fecha_2` (`fecha`,`eventid`,`telefono`,`cliente`),
  KEY `fecha` (`fecha`),
  KEY `origen` (`origen`),
  KEY `eventid` (`eventid`),
  KEY `area` (`area`),
  KEY `telefono` (`telefono`),
  KEY `estado` (`estado`),
  KEY `cliente` (`cliente`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `internostdp_nclientes`
--

DROP TABLE IF EXISTS `internostdp_nclientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `internostdp_nclientes` (
  `EMPRESA` varchar(3) DEFAULT NULL,
  `IDCLIENTECRM` double DEFAULT NULL,
  `idempresacrm` int(11) DEFAULT NULL,
  `idservicio` int(11) DEFAULT NULL,
  `idproducto` double DEFAULT NULL,
  `idventa` double DEFAULT NULL,
  `NAMECLIENT` varchar(100) DEFAULT NULL,
  `NODO` varchar(2) DEFAULT NULL,
  `TROBA` varchar(4) DEFAULT NULL,
  `amplificador` int(11) DEFAULT NULL,
  `tap` int(11) DEFAULT NULL,
  `telf1` varchar(10) DEFAULT NULL,
  `telf2` varchar(10) DEFAULT NULL,
  `f_v` varchar(20) DEFAULT NULL,
  `regver` varchar(3) DEFAULT NULL,
  `cmts` varchar(20) DEFAULT NULL,
  `MACADDRESS` varchar(20) DEFAULT NULL,
  `SERVICEPACKAGECRMID` varchar(50) DEFAULT NULL,
  `SERVICEPACKAGE` varchar(50) DEFAULT NULL,
  `CANTPCS` int(11) DEFAULT NULL,
  `FECHAALTA` varchar(20) DEFAULT NULL,
  `FECHAACTIVACION` varchar(20) DEFAULT NULL,
  `ESTADO` varchar(10) DEFAULT NULL,
  `SCOPESGROUP` varchar(15) DEFAULT NULL,
  `SCOPESGROUPCM` varchar(15) DEFAULT NULL,
  `SCOPESGROUPMTA` varchar(15) DEFAULT NULL,
  `MTAMAC` varchar(20) DEFAULT NULL,
  `IDSERVICIOMTA` varchar(15) DEFAULT NULL,
  `IDPRODUCTOMTA` varchar(15) DEFAULT NULL,
  `IDVENTAMTA` varchar(15) DEFAULT NULL,
  `MTAMODELNAME` varchar(50) DEFAULT NULL,
  `CMTSID` int(11) DEFAULT NULL,
  `UBICACIONENLARED` varchar(150) DEFAULT NULL,
  `IPCM` varchar(20) DEFAULT NULL,
  `DOCSISVERSION` int(11) DEFAULT NULL,
  `movil1` int(20) DEFAULT NULL,
  `mac2` varchar(20) DEFAULT NULL,
  `mac3` varchar(20) DEFAULT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `codserv` varchar(20) DEFAULT NULL,
  `fecha_upload` varchar(20) DEFAULT NULL,
  `naked` varchar(2) DEFAULT NULL,
  `numcoo_x` varchar(20) DEFAULT NULL,
  `numcoo_y` varchar(20) DEFAULT NULL,
  UNIQUE KEY `NewIndex1` (`MACADDRESS`),
  KEY `NewIndex2` (`IDCLIENTECRM`),
  KEY `idproducto` (`idproducto`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jefaturas`
--

DROP TABLE IF EXISTS `jefaturas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jefaturas` (
  `dpto` varchar(80) DEFAULT NULL,
  `provincia` varchar(100) DEFAULT NULL,
  `distrito` varchar(100) DEFAULT NULL,
  `nodo` varchar(5) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `tipo` varchar(10) DEFAULT NULL,
  `region` varchar(20) DEFAULT NULL,
  `jef_cmr` varchar(10) DEFAULT NULL,
  `det_region` varchar(20) DEFAULT NULL,
  `sede` varchar(20) DEFAULT NULL,
  `xprem_mas` varchar(20) DEFAULT NULL,
  `eecc` varchar(20) DEFAULT NULL,
  `supervisor` varchar(100) DEFAULT NULL,
  `entrenador` varchar(100) DEFAULT NULL,
  `zona` varchar(20) DEFAULT NULL,
  `zon_region` varchar(20) DEFAULT NULL,
  `playas` int(11) DEFAULT NULL,
  `jefa_nuevo` varchar(10) DEFAULT NULL,
  `jefa_tac` varchar(10) DEFAULT NULL,
  `bono` varchar(10) DEFAULT NULL,
  `terreno` varchar(20) DEFAULT NULL,
  `mplayas` varchar(20) DEFAULT NULL,
  `codctr` varchar(20) DEFAULT NULL,
  `jefatura` varchar(20) DEFAULT NULL,
  `jefatura_torre` varchar(20) DEFAULT NULL,
  KEY `nodo` (`nodo`),
  KEY `jefatura_torre` (`jefatura_torre`),
  KEY `jefatura` (`jefatura`),
  KEY `codctr` (`codctr`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jefaturas_d`
--

DROP TABLE IF EXISTS `jefaturas_d`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jefaturas_d` (
  `dpto` varchar(80) DEFAULT NULL,
  `provincia` varchar(100) DEFAULT NULL,
  `distrito` varchar(100) DEFAULT NULL,
  `nodo` varchar(5) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `tipo` varchar(10) DEFAULT NULL,
  `region` varchar(20) DEFAULT NULL,
  `jef_cmr` varchar(10) DEFAULT NULL,
  `det_region` varchar(20) DEFAULT NULL,
  `sede` varchar(20) DEFAULT NULL,
  `xprem_mas` varchar(20) DEFAULT NULL,
  `eecc` varchar(20) DEFAULT NULL,
  `supervisor` varchar(100) DEFAULT NULL,
  `entrenador` varchar(100) DEFAULT NULL,
  `zona` varchar(20) DEFAULT NULL,
  `zon_region` varchar(20) DEFAULT NULL,
  `playas` int(11) DEFAULT NULL,
  `jefa_nuevo` varchar(10) DEFAULT NULL,
  `jefa_tac` varchar(10) DEFAULT NULL,
  `bono` varchar(10) DEFAULT NULL,
  `terreno` varchar(20) DEFAULT NULL,
  `mplayas` varchar(20) DEFAULT NULL,
  `codctr` varchar(20) DEFAULT NULL,
  `jefatura` varchar(20) DEFAULT NULL,
  KEY `nodo` (`nodo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jefaturas_x`
--

DROP TABLE IF EXISTS `jefaturas_x`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jefaturas_x` (
  `dpto` varchar(80) DEFAULT NULL,
  `provincia` varchar(100) DEFAULT NULL,
  `distrito` varchar(100) DEFAULT NULL,
  `nodo` varchar(5) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `tipo` varchar(10) DEFAULT NULL,
  `region` varchar(20) DEFAULT NULL,
  `jef_cmr` varchar(10) DEFAULT NULL,
  `det_region` varchar(20) DEFAULT NULL,
  `sede` varchar(20) DEFAULT NULL,
  `xprem_mas` varchar(20) DEFAULT NULL,
  `eecc` varchar(20) DEFAULT NULL,
  `supervisor` varchar(100) DEFAULT NULL,
  `entrenador` varchar(100) DEFAULT NULL,
  `zona` varchar(20) DEFAULT NULL,
  `zon_region` varchar(20) DEFAULT NULL,
  `playas` int(11) DEFAULT NULL,
  `jefa_nuevo` varchar(10) DEFAULT NULL,
  `jefa_tac` varchar(10) DEFAULT NULL,
  `bono` varchar(10) DEFAULT NULL,
  `terreno` varchar(20) DEFAULT NULL,
  `mplayas` varchar(20) DEFAULT NULL,
  `jefatura` varchar(20) DEFAULT NULL,
  KEY `nodo` (`nodo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `llamadasxtroba`
--

DROP TABLE IF EXISTS `llamadasxtroba`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `llamadasxtroba` (
  `nodo` varchar(2) DEFAULT NULL,
  `troban` varchar(4) DEFAULT NULL,
  `llamadas` bigint(21) NOT NULL DEFAULT '0',
  KEY `NewIndex1` (`nodo`),
  KEY `NewIndex2` (`troban`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `macstate`
--

DROP TABLE IF EXISTS `macstate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `macstate` (
  `macstate` varchar(20) NOT NULL,
  `estado` varchar(20) CHARACTER SET utf8 NOT NULL,
  UNIQUE KEY `macstate` (`macstate`),
  KEY `estado` (`estado`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marca_modelo`
--

DROP TABLE IF EXISTS `marca_modelo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marca_modelo` (
  `fabricante` varchar(100) DEFAULT NULL,
  `marca` varbinary(100) DEFAULT NULL,
  `modelo` varchar(40) DEFAULT NULL,
  KEY `fabricante` (`fabricante`),
  KEY `modelo` (`modelo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matriz_jerarquias_cmts`
--

DROP TABLE IF EXISTS `matriz_jerarquias_cmts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matriz_jerarquias_cmts` (
  `equipo` varchar(20) DEFAULT NULL,
  `localidad` varchar(40) DEFAULT NULL,
  `cmts_core` varchar(30) DEFAULT NULL,
  `ipcore` varchar(20) DEFAULT NULL,
  `interface1core` varchar(20) DEFAULT NULL,
  `hostnamecore` varchar(60) DEFAULT NULL,
  `interface2core` varchar(20) DEFAULT NULL,
  `nombre_ccm1` varchar(20) DEFAULT NULL,
  `nombre_iw` varchar(20) DEFAULT NULL,
  KEY `equipo` (`equipo`),
  KEY `localidad` (`localidad`),
  KEY `cmts_core` (`cmts_core`),
  KEY `interface1core` (`interface1core`),
  KEY `hostnamecore` (`hostnamecore`),
  KEY `interface2core` (`interface2core`),
  KEY `nombre_ccm1` (`nombre_ccm1`),
  KEY `ipcore` (`ipcore`),
  KEY `nombre_iw` (`nombre_iw`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matriz_jerarquias_olt`
--

DROP TABLE IF EXISTS `matriz_jerarquias_olt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matriz_jerarquias_olt` (
  `dcmtsolt` varchar(40) DEFAULT NULL,
  `anillometro` varchar(40) DEFAULT NULL,
  `puertoolt` varchar(10) DEFAULT NULL,
  `porttipoolt` varchar(10) DEFAULT NULL,
  `puertoorigen` varchar(10) DEFAULT NULL,
  `porttipo` varchar(10) DEFAULT NULL,
  `equipometroorigen` varchar(40) DEFAULT NULL,
  `puertodestino1` varchar(20) DEFAULT NULL,
  `equipometrodestino` varchar(60) DEFAULT NULL,
  `puertodestino2` varchar(10) DEFAULT NULL,
  `equipometrodestinovoz` varchar(60) DEFAULT NULL,
  `vlandatos` varchar(10) DEFAULT NULL,
  `redwandatosddcap` varchar(20) DEFAULT NULL,
  `vlanvoz` varchar(10) DEFAULT NULL,
  `redwanvozddcap` varchar(20) DEFAULT NULL,
  `vlanprov` varchar(10) DEFAULT NULL,
  `redwanprovisionddcap` varchar(20) DEFAULT NULL,
  `vlancgnat` varchar(10) DEFAULT NULL,
  `redwancgnatddcap` varchar(20) DEFAULT NULL,
  `puertocore` varchar(10) DEFAULT NULL,
  `equipocore` varchar(60) DEFAULT NULL,
  `puertoran` varchar(10) DEFAULT NULL,
  `equiporan` varchar(20) DEFAULT NULL,
  `observaciones` varchar(100) DEFAULT NULL,
  `modeloolt` varchar(20) DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `nombreccm1` varchar(40) DEFAULT NULL,
  `nombreiw` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `microzona_premium`
--

DROP TABLE IF EXISTS `microzona_premium`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `microzona_premium` (
  `nodotroba` varchar(10) NOT NULL DEFAULT '',
  `microzona` varchar(15) NOT NULL DEFAULT '',
  `distrito` varchar(40) NOT NULL DEFAULT '',
  `arpu` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `valortroba` varchar(15) NOT NULL DEFAULT '',
  `grupo` varchar(15) NOT NULL DEFAULT '',
  `fecha` varchar(20) NOT NULL DEFAULT '',
  `area_` varchar(15) NOT NULL DEFAULT '',
  `grupo_dist` varchar(30) NOT NULL DEFAULT '',
  KEY `nodotroba` (`nodotroba`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `microzonas`
--

DROP TABLE IF EXISTS `microzonas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `microzonas` (
  `item` int(11) NOT NULL AUTO_INCREMENT,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `microzona` varchar(20) DEFAULT NULL,
  `eecc` char(20) DEFAULT NULL,
  `nodotroba` varchar(50) DEFAULT NULL,
  `flag` int(1) DEFAULT NULL,
  PRIMARY KEY (`item`),
  UNIQUE KEY `nodo_2` (`nodo`,`troba`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `microzona` (`microzona`),
  KEY `eecc` (`eecc`),
  KEY `nodotroba` (`nodotroba`)
) ENGINE=MyISAM AUTO_INCREMENT=443 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migraciones`
--

DROP TABLE IF EXISTS `migraciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migraciones` (
  `nodo_hfc` varchar(2) NOT NULL,
  `troba_hfc` varchar(4) NOT NULL,
  `nodo_cms` varchar(4) NOT NULL,
  `troba_cms` varchar(5) NOT NULL,
  `count(*)` bigint(21) NOT NULL,
  PRIMARY KEY (`nodo_hfc`,`troba_hfc`,`nodo_cms`,`troba_cms`),
  KEY `nodo_hfc` (`nodo_hfc`),
  KEY `trobahfc` (`troba_hfc`),
  KEY `nodo_cms` (`nodo_cms`),
  KEY `troba_cms` (`troba_cms`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `movistar_total`
--

DROP TABLE IF EXISTS `movistar_total`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movistar_total` (
  `serviciocms` int(11) DEFAULT NULL,
  `clientecms` int(11) DEFAULT NULL,
  `productoFijo` varchar(150) DEFAULT NULL,
  `telefono` int(11) DEFAULT NULL,
  `fechaaltaAtis` varchar(20) DEFAULT NULL,
  `documento` int(11) DEFAULT NULL,
  `telf1` int(11) DEFAULT NULL,
  `telf2` int(11) DEFAULT NULL,
  `telf3` int(11) DEFAULT NULL,
  `telf4` int(11) DEFAULT NULL,
  `fechaalta` varchar(20) DEFAULT NULL,
  UNIQUE KEY `serviciocms` (`serviciocms`,`clientecms`),
  KEY `clientecms` (`clientecms`),
  KEY `telefono` (`telefono`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `movistar_total_c`
--

DROP TABLE IF EXISTS `movistar_total_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movistar_total_c` (
  `serviciocms` int(11) DEFAULT NULL,
  `clientecms` int(11) DEFAULT NULL,
  `productoFijo` varchar(150) DEFAULT NULL,
  `telefono` int(11) DEFAULT NULL,
  `fechaaltaAtis` varchar(20) DEFAULT NULL,
  `documento` int(11) DEFAULT NULL,
  `telf1` int(11) DEFAULT NULL,
  `telf2` int(11) DEFAULT NULL,
  `telf3` int(11) DEFAULT NULL,
  `telf4` int(11) DEFAULT NULL,
  `fechaalta` varchar(20) DEFAULT NULL,
  UNIQUE KEY `serviciocms` (`serviciocms`,`clientecms`),
  KEY `clientecms` (`clientecms`),
  KEY `telefono` (`telefono`),
  KEY `fechaalta` (`fechaalta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `movistar_total_temp`
--

DROP TABLE IF EXISTS `movistar_total_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movistar_total_temp` (
  `serviciocms` int(11) DEFAULT NULL,
  `clientecms` int(11) DEFAULT NULL,
  `productoFijo` varchar(150) DEFAULT NULL,
  `telefono` int(11) DEFAULT NULL,
  `fechaaltaAtis` varchar(20) DEFAULT NULL,
  `documento` int(11) DEFAULT NULL,
  `telf1` int(11) DEFAULT NULL,
  `telf2` int(11) DEFAULT NULL,
  `telf3` int(11) DEFAULT NULL,
  `telf4` int(11) DEFAULT NULL,
  `fechaalta` varchar(20) DEFAULT NULL,
  UNIQUE KEY `serviciocms` (`serviciocms`,`clientecms`),
  KEY `clientecms` (`clientecms`),
  KEY `telefono` (`telefono`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `operador`
--

DROP TABLE IF EXISTS `operador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operador` (
  `OPERADOR` varchar(80) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oui_fuentes`
--

DROP TABLE IF EXISTS `oui_fuentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oui_fuentes` (
  `oui_fuentes` varchar(6) DEFAULT NULL,
  `marca` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `InputVoltage` varchar(50) DEFAULT NULL,
  `OutputVoltage` varchar(50) DEFAULT NULL,
  `OutputCurrent` varchar(50) DEFAULT NULL,
  `TotalStringVoltage` varchar(50) DEFAULT NULL,
  KEY `oui_fuentes` (`oui_fuentes`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pago_fractalia`
--

DROP TABLE IF EXISTS `pago_fractalia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pago_fractalia` (
  `nodo` varchar(2) CHARACTER SET latin1 DEFAULT NULL,
  `troba` varchar(4) CHARACTER SET latin1 DEFAULT NULL,
  `cant` int(21) DEFAULT NULL,
  `off` int(21) DEFAULT NULL,
  `fecha_hora` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `fecha_fin` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `tiempo` time DEFAULT NULL,
  `codmasiva` int(11) DEFAULT NULL,
  `tipo` varchar(217) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `parametros_rf`
--

DROP TABLE IF EXISTS `parametros_rf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parametros_rf` (
  `parametro` varchar(15) NOT NULL,
  `vmin` int(10) DEFAULT NULL,
  `vmax` int(10) DEFAULT NULL,
  `estado` int(1) DEFAULT NULL,
  `nrf` varchar(15) NOT NULL,
  `min` varchar(4) DEFAULT NULL,
  `max` varchar(4) DEFAULT NULL,
  PRIMARY KEY (`parametro`),
  KEY `nrf` (`nrf`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `parametros_rf_c`
--

DROP TABLE IF EXISTS `parametros_rf_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parametros_rf_c` (
  `parametro` varchar(15) DEFAULT NULL,
  `vmin` int(10) DEFAULT NULL,
  `vmax` int(10) DEFAULT NULL,
  `estado` int(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pendientes_nodo_troba`
--

DROP TABLE IF EXISTS `pendientes_nodo_troba`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pendientes_nodo_troba` (
  `nodotroba` varchar(6) NOT NULL,
  `mensaje` varchar(200) NOT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `fechahora` varchar(20) NOT NULL,
  UNIQUE KEY `nodo` (`nodotroba`),
  KEY `fechahora` (`fechahora`),
  KEY `nodo_2` (`nodo`),
  KEY `troba` (`troba`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `piloto_edificios`
--

DROP TABLE IF EXISTS `piloto_edificios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `piloto_edificios` (
  `telefono` int(11) DEFAULT NULL,
  `cliente` int(11) DEFAULT NULL,
  `servicio` int(11) DEFAULT NULL,
  `departamen` varchar(100) DEFAULT NULL,
  `provincia` varchar(100) DEFAULT NULL,
  `distrito` varchar(100) DEFAULT NULL,
  `desurb` varchar(100) DEFAULT NULL,
  `desref` varchar(100) DEFAULT NULL,
  `codofeprod` varchar(100) DEFAULT NULL,
  `tipdoc` varchar(100) DEFAULT NULL,
  `numdocidt` int(11) DEFAULT NULL,
  UNIQUE KEY `cliente` (`cliente`),
  KEY `telefono` (`telefono`),
  KEY `servicio` (`servicio`),
  KEY `numdocidt` (`numdocidt`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `planos`
--

DROP TABLE IF EXISTS `planos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `planos` (
  `clave` varchar(20) NOT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  PRIMARY KEY (`clave`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `planta_cms_ivr`
--

DROP TABLE IF EXISTS `planta_cms_ivr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `planta_cms_ivr` (
  `telefono` int(11) DEFAULT NULL,
  `cliente` int(11) DEFAULT NULL,
  `servicio` int(11) DEFAULT NULL,
  `desdpt` varchar(150) DEFAULT NULL,
  `despvc` varchar(150) DEFAULT NULL,
  `desdtt` varchar(150) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `plano` varchar(4) DEFAULT NULL,
  `tipoperu8k` varchar(100) DEFAULT NULL,
  `numeroruc` varchar(25) DEFAULT NULL,
  `numerodoc` varchar(11) DEFAULT NULL,
  `ind_duo` varchar(20) DEFAULT NULL,
  `tipo_linea` varchar(20) DEFAULT NULL,
  `identifica` varchar(20) DEFAULT NULL,
  KEY `telefono` (`telefono`),
  KEY `cliente` (`cliente`),
  KEY `servicio` (`servicio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `planta_telef_cms_new`
--

DROP TABLE IF EXISTS `planta_telef_cms_new`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `planta_telef_cms_new` (
  `cliente` int(10) DEFAULT NULL,
  `servicio` varchar(20) CHARACTER SET latin1 NOT NULL,
  `NODO` varchar(4) CHARACTER SET latin1 DEFAULT NULL,
  `troba` varchar(5) CHARACTER SET latin1 DEFAULT NULL,
  `apmlificador` varchar(10) CHARACTER SET latin1 DEFAULT NULL,
  `NUMERODOC` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `NUMERORUC` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `telf1` int(11) DEFAULT NULL,
  `telf2` int(11) DEFAULT NULL,
  `telf3` int(11) DEFAULT NULL,
  `telf4` int(11) DEFAULT NULL,
  `telf5` int(11) DEFAULT NULL,
  `telf6` int(11) DEFAULT NULL,
  `telf7` int(11) DEFAULT NULL,
  `telf8` int(11) DEFAULT NULL,
  `telf9` int(11) DEFAULT NULL,
  `telf10` int(11) DEFAULT NULL,
  `telfono2` int(11) DEFAULT NULL,
  `telf11` int(11) DEFAULT NULL,
  `telf12` int(11) DEFAULT NULL,
  `tiptec` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  UNIQUE KEY `cliente` (`cliente`,`servicio`),
  KEY `servicio` (`servicio`),
  KEY `NUMERODOC` (`NUMERODOC`),
  KEY `NUMERORUC` (`NUMERORUC`),
  KEY `telf1` (`telf1`),
  KEY `telf2` (`telf2`),
  KEY `telf3` (`telf3`),
  KEY `telf4` (`telf4`),
  KEY `telf5` (`telf5`),
  KEY `telf6` (`telf6`),
  KEY `telf7` (`telf7`),
  KEY `telf8` (`telf8`),
  KEY `telf9` (`telf9`),
  KEY `telf10` (`telf10`),
  KEY `telfono2` (`telfono2`),
  KEY `telf11` (`telf11`),
  KEY `telf12` (`telf12`),
  KEY `NODO` (`NODO`),
  KEY `troba` (`troba`),
  KEY `apmlificador` (`apmlificador`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `planta_total`
--

DROP TABLE IF EXISTS `planta_total`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `planta_total` (
  `nodo` varchar(4) CHARACTER SET latin1 DEFAULT NULL,
  `plano` varchar(5) CHARACTER SET latin1 DEFAULT NULL,
  `cant` bigint(21) NOT NULL DEFAULT '0',
  `clave` varchar(10) DEFAULT NULL,
  KEY `nodo` (`nodo`),
  KEY `plano` (`plano`),
  KEY `clave` (`clave`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `premium`
--

DROP TABLE IF EXISTS `premium`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `premium` (
  `troba` varchar(6) NOT NULL,
  PRIMARY KEY (`troba`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `premium_fases`
--

DROP TABLE IF EXISTS `premium_fases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `premium_fases` (
  `troba` varchar(6) DEFAULT NULL,
  `cms` varchar(2) DEFAULT NULL,
  `tecnologia` varchar(20) DEFAULT NULL,
  `fecactplus` varchar(20) DEFAULT NULL,
  `region` varchar(30) DEFAULT NULL,
  `jefComercial` varchar(20) DEFAULT NULL,
  `grupo` varchar(20) DEFAULT NULL,
  `microzona` varchar(20) DEFAULT NULL,
  `grupo_microzona` varchar(20) DEFAULT NULL,
  `sw` int(1) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `trobaf` varchar(4) DEFAULT NULL,
  UNIQUE KEY `troba` (`troba`),
  KEY `grupo_microzona` (`grupo_microzona`),
  KEY `jefComercial` (`jefComercial`),
  KEY `region` (`region`),
  KEY `grupo` (`grupo`),
  KEY `trobaf` (`trobaf`),
  KEY `nodo` (`nodo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `query`
--

DROP TABLE IF EXISTS `query`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `query` (
  `detalle` varchar(200) DEFAULT NULL,
  `query` longtext
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `redesip_n`
--

DROP TABLE IF EXISTS `redesip_n`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `redesip_n` (
  `cmts` varchar(30) DEFAULT NULL,
  `subnet` varchar(20) DEFAULT NULL,
  `netmask` varchar(20) DEFAULT NULL,
  `gateway` varchar(20) DEFAULT NULL,
  `rangefrom` varchar(20) DEFAULT NULL,
  `rangeto` varchar(20) DEFAULT NULL,
  `subnetid` varchar(20) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `used` int(11) DEFAULT NULL,
  `available` int(11) DEFAULT NULL,
  `scopesgroup` varchar(20) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  UNIQUE KEY `cmts` (`cmts`,`subnet`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `redesip_view`
--

DROP TABLE IF EXISTS `redesip_view`;
/*!50001 DROP VIEW IF EXISTS `redesip_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `redesip_view` (
  `cmts` tinyint NOT NULL,
  `scopesgroup` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `used` tinyint NOT NULL,
  `available` tinyint NOT NULL,
  `porc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `reiteradas7dias`
--

DROP TABLE IF EXISTS `reiteradas7dias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reiteradas7dias` (
  `codcli` int(11) DEFAULT NULL,
  `codaveria` int(11) DEFAULT NULL,
  `nodotroba` varchar(6) DEFAULT NULL,
  `fe_liqu` varchar(20) DEFAULT NULL,
  `s1` int(11) DEFAULT NULL,
  `s2` int(11) DEFAULT NULL,
  `s3` int(11) DEFAULT NULL,
  `s4` int(11) DEFAULT NULL,
  `s5` int(11) DEFAULT NULL,
  `s6` int(11) DEFAULT NULL,
  `s7` int(11) DEFAULT NULL,
  `dmogen` varchar(60) DEFAULT NULL,
  `ti_cdliq` varchar(100) DEFAULT NULL,
  `ti_cdes` varchar(100) DEFAULT NULL,
  `rubro_maq` varchar(50) DEFAULT NULL,
  `re_ddetliq` varchar(100) DEFAULT NULL,
  `re_descliq` varchar(100) DEFAULT NULL,
  `mensaje` varchar(50) DEFAULT NULL,
  UNIQUE KEY `codclicms` (`codcli`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `robot_codctr`
--

DROP TABLE IF EXISTS `robot_codctr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `robot_codctr` (
  `codctr` int(11) DEFAULT NULL,
  `desctr` varchar(30) DEFAULT NULL,
  KEY `codctr` (`codctr`),
  KEY `desctr` (`desctr`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `robot_codctr_nodo`
--

DROP TABLE IF EXISTS `robot_codctr_nodo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `robot_codctr_nodo` (
  `nodo` varchar(2) DEFAULT NULL,
  `codctr` int(11) DEFAULT NULL,
  `desctr` varchar(30) DEFAULT NULL,
  KEY `nodo` (`nodo`),
  KEY `codctr` (`codctr`),
  KEY `desctr` (`desctr`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `saturaciones_olt`
--

DROP TABLE IF EXISTS `saturaciones_olt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saturaciones_olt` (
  `Puerto` varchar(6) DEFAULT NULL,
  `Vendor` varchar(10) DEFAULT NULL,
  `Tipo` varchar(10) DEFAULT NULL,
  `Portadoras` int(11) DEFAULT NULL,
  `Clientes` int(11) DEFAULT NULL,
  `Semana35` varchar(20) DEFAULT NULL,
  `Semana36` varchar(20) DEFAULT NULL,
  KEY `Puerto` (`Puerto`),
  KEY `Vendor` (`Vendor`),
  KEY `Tipo` (`Tipo`),
  KEY `Semana35` (`Semana35`),
  KEY `Semana36` (`Semana36`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `segmentos_view`
--

DROP TABLE IF EXISTS `segmentos_view`;
/*!50001 DROP VIEW IF EXISTS `segmentos_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `segmentos_view` (
  `nodo` tinyint NOT NULL,
  `troba` tinyint NOT NULL,
  `segmento` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `sonaverias`
--

DROP TABLE IF EXISTS `sonaverias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sonaverias` (
  `motivo` varchar(4) DEFAULT NULL,
  `descripcion` varchar(200) DEFAULT NULL,
  `servicio` varchar(50) DEFAULT NULL,
  `observacion` varchar(200) DEFAULT NULL,
  `tipave` varchar(2) DEFAULT NULL,
  KEY `motivo` (`motivo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tecnico`
--

DROP TABLE IF EXISTS `tecnico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tecnico` (
  `TECNICO` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `telcontacto_msj`
--

DROP TABLE IF EXISTS `telcontacto_msj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telcontacto_msj` (
  `nombre` varchar(40) DEFAULT NULL,
  `celular` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `telef_multi`
--

DROP TABLE IF EXISTS `telef_multi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telef_multi` (
  `codcli` int(11) NOT NULL,
  `telef1` int(11) DEFAULT NULL,
  `telef2` int(11) DEFAULT NULL,
  `telef3` int(11) DEFAULT NULL,
  PRIMARY KEY (`codcli`),
  KEY `telef1` (`telef1`),
  KEY `telef2` (`telef2`),
  KEY `telef3` (`telef3`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `telefonos_atis`
--

DROP TABLE IF EXISTS `telefonos_atis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telefonos_atis` (
  `Cliente` int(11) DEFAULT NULL,
  `Cuenta` int(11) DEFAULT NULL,
  `Inscripcion` int(11) DEFAULT NULL,
  `Telefono` int(11) DEFAULT NULL,
  `CABLE_CLIENTE_CMS` int(11) DEFAULT NULL,
  `TIPO_DOCUMENTO_CTE` varchar(3) DEFAULT NULL,
  `DOCUMENTO_CLIENTE` varchar(10) DEFAULT NULL,
  `NOMBRE_CLIENTE` varchar(100) DEFAULT NULL,
  `DIRECCION_PC` varchar(200) DEFAULT NULL,
  `SUNAT_RUC` int(11) DEFAULT NULL,
  `CLUSTER_` varchar(20) DEFAULT NULL,
  `PAQUETE_TIPO` varchar(20) DEFAULT NULL,
  `Macrosegmento` varchar(20) DEFAULT NULL,
  `MACROSEGMENTO_TOP` varchar(20) DEFAULT NULL,
  `RENTA_TOTAL_2` varchar(6) DEFAULT NULL,
  `correo1` varchar(80) DEFAULT NULL,
  `correo2` varchar(80) DEFAULT NULL,
  `movil1` int(11) DEFAULT NULL,
  `probabilidad_movil1` int(11) DEFAULT NULL,
  `OPERADOR_MOVIL1` varchar(20) DEFAULT NULL,
  `TIPODOC_MOVIL1` varchar(20) DEFAULT NULL,
  `DOC_MOVIL1` int(11) DEFAULT NULL,
  `movil2` int(11) DEFAULT NULL,
  `probabilidad_movil2` int(11) DEFAULT NULL,
  `OPERADOR_MOVIL2` varchar(20) DEFAULT NULL,
  `TIPODOC_MOVIL2` varchar(20) DEFAULT NULL,
  `DOC_MOVIL2` int(11) DEFAULT NULL,
  `movil3` int(11) DEFAULT NULL,
  `probabilidad_movil3` int(11) DEFAULT NULL,
  `OPERADOR_MOVIL3` int(11) DEFAULT NULL,
  `TIPODOC_MOVIL3` varchar(20) DEFAULT NULL,
  `DOC_MOVIL3` int(11) DEFAULT NULL,
  `movil4` int(11) DEFAULT NULL,
  `probabilidad_movil4` int(11) DEFAULT NULL,
  `OPERADOR_MOVIL4` varchar(20) DEFAULT NULL,
  `TIPODOC_MOVIL4` varchar(20) DEFAULT NULL,
  `DOC_MOVIL4` int(11) DEFAULT NULL,
  `movil5` int(11) DEFAULT NULL,
  `probabilidad_movil5` int(11) DEFAULT NULL,
  `OPERADOR_MOVIL5` varchar(20) DEFAULT NULL,
  `TIPODOC_MOVIL5` varchar(20) DEFAULT NULL,
  `DOC_MOVIL5` int(11) DEFAULT NULL,
  `DEPARTAMENTO` varchar(20) DEFAULT NULL,
  `DISTRITO` varchar(20) DEFAULT NULL,
  `FE_ALTA_PC` varchar(20) DEFAULT NULL,
  `FLAG_ALTO_VALOR` varchar(20) DEFAULT NULL,
  `Ciclo` int(11) DEFAULT NULL,
  KEY `Cliente` (`Cliente`),
  KEY `Telefono` (`Telefono`),
  KEY `Inscripcion` (`Inscripcion`),
  KEY `TIPODOC_MOVIL2` (`TIPODOC_MOVIL2`),
  KEY `DOCUMENTO_CLIENTE` (`DOCUMENTO_CLIENTE`),
  KEY `movil1` (`movil1`),
  KEY `movil2` (`movil2`),
  KEY `movil3` (`movil3`),
  KEY `Cliente_2` (`Cliente`,`movil4`),
  KEY `CABLE_CLIENTE_CMS` (`CABLE_CLIENTE_CMS`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `telefonos_cms`
--

DROP TABLE IF EXISTS `telefonos_cms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telefonos_cms` (
  `Cliente` int(11) DEFAULT NULL,
  `Cuenta` int(11) DEFAULT NULL,
  `servicio` int(11) DEFAULT NULL,
  `segmento` varchar(20) DEFAULT NULL,
  `TECNOLOGIA` varchar(6) DEFAULT NULL,
  `NOMBRE_CLIENTE` varchar(100) DEFAULT NULL,
  `TIPDOC` varchar(3) DEFAULT NULL,
  `NUMDOC` int(11) DEFAULT NULL,
  `NUMRUC` varchar(20) DEFAULT NULL,
  `Departamento` varchar(40) DEFAULT NULL,
  `Provincia` varchar(40) DEFAULT NULL,
  `Distrito` varchar(40) DEFAULT NULL,
  `DIRECCION_INSTALACION` varchar(200) DEFAULT NULL,
  `TELEFONO_VOIP` int(11) DEFAULT NULL,
  `FE_ALTA` varchar(20) DEFAULT NULL,
  `tipo` varchar(20) DEFAULT NULL,
  `tipodoc1` varchar(20) DEFAULT NULL,
  `numdoc1` int(11) DEFAULT NULL,
  `Telefono` int(11) DEFAULT NULL,
  `Fuente_Contacto` varchar(20) DEFAULT NULL,
  `Tipo_Producto` varchar(20) DEFAULT NULL,
  `Operador` varchar(20) DEFAULT NULL,
  `Flg_trafico` varchar(20) DEFAULT NULL,
  `PRIORIDAD` int(11) DEFAULT NULL,
  `tipodoc2` varchar(20) DEFAULT NULL,
  `numdoc2` int(11) DEFAULT NULL,
  `telfono2` int(11) DEFAULT NULL,
  `fuente_contacto2` varchar(20) DEFAULT NULL,
  `tipo_producto_2` varchar(20) DEFAULT NULL,
  `operador_2` varchar(20) DEFAULT NULL,
  `flg_trafico2` varchar(20) DEFAULT NULL,
  `prioridad_2` int(11) DEFAULT NULL,
  `tipodoc3` varchar(20) DEFAULT NULL,
  `numdoc3` int(11) DEFAULT NULL,
  `telfono3` int(11) DEFAULT NULL,
  `fuente_contacto3` varchar(20) DEFAULT NULL,
  `tipo_producto_3` varchar(20) DEFAULT NULL,
  `operador_3` varchar(20) DEFAULT NULL,
  `flg_trafico3` varchar(20) DEFAULT NULL,
  `prioridad_3` int(11) DEFAULT NULL,
  `tipodoc4` varchar(10) DEFAULT NULL,
  `numdoc4` varchar(20) DEFAULT NULL,
  `telfono4` int(11) DEFAULT NULL,
  `fuente_contacto4` varchar(50) DEFAULT NULL,
  `tipo_producto_4` varchar(50) DEFAULT NULL,
  `operador_4` varchar(50) DEFAULT NULL,
  `flg_trafico4` varchar(50) DEFAULT NULL,
  `prioridad_4` varchar(50) DEFAULT NULL,
  `CORREO_1` varchar(50) DEFAULT NULL,
  `CORREO_2` varchar(50) DEFAULT NULL,
  KEY `Cliente` (`Cliente`),
  KEY `NUMDOC` (`NUMDOC`),
  KEY `NUMRUC` (`NUMRUC`),
  KEY `TELEFONO_VOIP` (`TELEFONO_VOIP`),
  KEY `Telefono` (`Telefono`),
  KEY `numdoc2` (`numdoc2`),
  KEY `telfono2` (`telfono2`),
  KEY `numdoc3` (`numdoc3`),
  KEY `telfono3` (`telfono3`),
  KEY `numdoc4` (`numdoc4`),
  KEY `telfono4` (`telfono4`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `telefonoshfc`
--

DROP TABLE IF EXISTS `telefonoshfc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telefonoshfc` (
  `empresa` varchar(3) DEFAULT NULL,
  `idcliente` double DEFAULT NULL,
  `idcablemodem` int(11) DEFAULT NULL,
  `idseserv` varchar(30) DEFAULT NULL,
  `idprov` varchar(30) DEFAULT NULL,
  `idvent` varchar(30) DEFAULT NULL,
  `usuario` varchar(30) DEFAULT NULL,
  `ddn` varchar(14) DEFAULT NULL,
  `telefono` int(14) DEFAULT NULL,
  `producto` varchar(20) DEFAULT NULL,
  `macaddress` varchar(20) DEFAULT NULL,
  `cantidadpcs` varchar(10) DEFAULT NULL,
  `fechaalta` varchar(20) DEFAULT NULL,
  `activacion` varchar(20) DEFAULT NULL,
  `hub` varchar(10) DEFAULT NULL,
  `nodo` varchar(10) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `servicepack` varchar(50) DEFAULT NULL,
  `gropoderedescm` varchar(10) DEFAULT NULL,
  `gropoderedescpe` varchar(10) DEFAULT NULL,
  `gropoderedesmta` varchar(10) DEFAULT NULL,
  `telefonohfc` int(14) DEFAULT NULL,
  KEY `NewIndex2` (`idcliente`),
  KEY `NewIndex3` (`macaddress`),
  KEY `NewIndex1` (`telefonohfc`),
  KEY `NewIndex4` (`ddn`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tickets_dmpe`
--

DROP TABLE IF EXISTS `tickets_dmpe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets_dmpe` (
  `eventid` int(11) DEFAULT NULL,
  `estado` varchar(30) DEFAULT NULL,
  `fecha_inicio` varchar(20) DEFAULT NULL,
  `fecha_termino` varchar(20) DEFAULT NULL,
  `usuario_origen` varchar(30) DEFAULT NULL,
  `usuario_termino` varchar(30) DEFAULT NULL,
  `agente` varchar(50) DEFAULT NULL,
  UNIQUE KEY `eventid` (`eventid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tickets_dmpe_c`
--

DROP TABLE IF EXISTS `tickets_dmpe_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets_dmpe_c` (
  `eventid` int(11) DEFAULT NULL,
  `estado` varchar(30) DEFAULT NULL,
  `fecha_inicio` varchar(20) DEFAULT NULL,
  `fecha_termino` varchar(20) DEFAULT NULL,
  `usuario_origen` varchar(30) DEFAULT NULL,
  `usuario_termino` varchar(30) DEFAULT NULL,
  `agente` varchar(50) DEFAULT NULL,
  UNIQUE KEY `eventid` (`eventid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `top100200`
--

DROP TABLE IF EXISTS `top100200`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `top100200` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `top` int(11) DEFAULT NULL,
  `clave` varchar(6) NOT NULL,
  PRIMARY KEY (`clave`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `top` (`top`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `top_trobas`
--

DROP TABLE IF EXISTS `top_trobas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `top_trobas` (
  `nodotroba` varchar(15) NOT NULL DEFAULT '',
  `estatus` varchar(40) NOT NULL DEFAULT '',
  KEY `nodotroba` (`nodotroba`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `torreshfc`
--

DROP TABLE IF EXISTS `torreshfc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `torreshfc` (
  `oui` varchar(8) NOT NULL,
  PRIMARY KEY (`oui`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trabajo`
--

DROP TABLE IF EXISTS `trabajo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trabajo` (
  `trabajo` varchar(100) DEFAULT NULL,
  KEY `NewIndex1` (`trabajo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trabajos_programados`
--

DROP TABLE IF EXISTS `trabajos_programados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trabajos_programados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipodetrabajo` varchar(200) NOT NULL DEFAULT '',
  `tipodetrabajo1` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `NewIndex1` (`tipodetrabajo1`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trabajos_programados_d`
--

DROP TABLE IF EXISTS `trabajos_programados_d`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trabajos_programados_d` (
  `tipodetrabajo` varchar(200) NOT NULL DEFAULT '',
  `tipodetrabajo1` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`tipodetrabajo`),
  KEY `NewIndex1` (`tipodetrabajo1`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `troba_tiptec`
--

DROP TABLE IF EXISTS `troba_tiptec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `troba_tiptec` (
  `nodo` varchar(4) CHARACTER SET latin1 DEFAULT NULL,
  `troba` varchar(5) CHARACTER SET latin1 DEFAULT NULL,
  `TIPTEC` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `HFC` decimal(23,0) DEFAULT NULL,
  `CATV` decimal(23,0) DEFAULT NULL,
  `GPON` decimal(23,0) DEFAULT NULL,
  `TOTAL` bigint(21) NOT NULL,
  UNIQUE KEY `nodo` (`nodo`,`troba`),
  KEY `TIPTEC` (`TIPTEC`),
  KEY `nodo_2` (`nodo`),
  KEY `troba` (`troba`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trobas_criticas_n`
--

DROP TABLE IF EXISTS `trobas_criticas_n`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trobas_criticas_n` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `critica` int(1) NOT NULL DEFAULT '0',
  `noalerta` int(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `nodo_2` (`nodo`,`troba`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `critica` (`critica`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `trobas_digi_view`
--

DROP TABLE IF EXISTS `trobas_digi_view`;
/*!50001 DROP VIEW IF EXISTS `trobas_digi_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `trobas_digi_view` (
  `nodo` tinyint NOT NULL,
  `troba` tinyint NOT NULL,
  `fecha` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `trobas_digitalizadas`
--

DROP TABLE IF EXISTS `trobas_digitalizadas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trobas_digitalizadas` (
  `item` int(11) NOT NULL AUTO_INCREMENT,
  `zona` varchar(10) NOT NULL,
  `nodo` varchar(10) DEFAULT NULL,
  `troba` varchar(10) DEFAULT NULL,
  `nodotroba` varchar(10) NOT NULL DEFAULT '',
  `amplif` varchar(10) DEFAULT NULL,
  `eecc` varchar(20) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `fecha` varchar(10) DEFAULT NULL,
  `fechan` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`item`),
  UNIQUE KEY `NewIndex3` (`nodotroba`),
  KEY `idxNodo` (`nodo`),
  KEY `idxTroba` (`troba`)
) ENGINE=InnoDB AUTO_INCREMENT=947632 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trobas_olt`
--

DROP TABLE IF EXISTS `trobas_olt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trobas_olt` (
  `cmts` varchar(50) DEFAULT NULL,
  `interface` varchar(20) DEFAULT NULL,
  `troba` varchar(11) DEFAULT NULL,
  `descriporig` varchar(20) DEFAULT NULL,
  UNIQUE KEY `cmts` (`cmts`,`interface`),
  KEY `cmts_2` (`cmts`),
  KEY `interface` (`interface`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trobascriticas`
--

DROP TABLE IF EXISTS `trobascriticas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trobascriticas` (
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  UNIQUE KEY `NewIndex1` (`nodo`,`troba`),
  KEY `NewIndex2` (`nodo`),
  KEY `NewIndex3` (`troba`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trobaxinterface`
--

DROP TABLE IF EXISTS `trobaxinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trobaxinterface` (
  `cmts` varchar(20) DEFAULT NULL,
  `f_v` varchar(20) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `can` bigint(21) NOT NULL DEFAULT '0',
  KEY `cmts` (`cmts`),
  KEY `f_v` (`f_v`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `velocidades_cambios`
--

DROP TABLE IF EXISTS `velocidades_cambios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `velocidades_cambios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SERVICEPACKAGECRMID` varchar(50) DEFAULT NULL,
  `SERVICEPACKAGE` varchar(50) DEFAULT NULL,
  `velocidad_final` varchar(30) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `conversion` varchar(2) DEFAULT NULL,
  `cgnat` varchar(10) DEFAULT NULL,
  `veloc_comercial` int(10) DEFAULT NULL,
  `flag_cambio_masivo` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx1` (`SERVICEPACKAGE`),
  KEY `NewIndex1` (`veloc_comercial`)
) ENGINE=MyISAM AUTO_INCREMENT=81 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `velocidades_concilia`
--

DROP TABLE IF EXISTS `velocidades_concilia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `velocidades_concilia` (
  `SERVICEPACKAGECRMID` varchar(50) DEFAULT NULL,
  `SERVICEPACKAGE` varchar(50) DEFAULT NULL,
  `velocidad_final` varchar(30) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `conversion` varchar(2) DEFAULT NULL,
  `cgnat` varchar(10) DEFAULT NULL,
  `veloc_comercial` int(10) DEFAULT NULL,
  KEY `idx1` (`SERVICEPACKAGE`),
  KEY `NewIndex1` (`veloc_comercial`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `velocidades_m`
--

DROP TABLE IF EXISTS `velocidades_m`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `velocidades_m` (
  `SERVICEPACKAGECRMID` varchar(50) DEFAULT NULL,
  `SERVICEPACKAGE` varchar(50) DEFAULT NULL,
  `velocidad_final` varchar(30) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `conversion` varchar(2) DEFAULT NULL,
  `cgnat` varchar(10) DEFAULT NULL,
  `veloc_comercial` int(10) DEFAULT NULL,
  KEY `idx1` (`SERVICEPACKAGE`),
  KEY `NewIndex1` (`veloc_comercial`),
  KEY `velocidad_final` (`velocidad_final`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `zonales_catv_view`
--

DROP TABLE IF EXISTS `zonales_catv_view`;
/*!50001 DROP VIEW IF EXISTS `zonales_catv_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `zonales_catv_view` (
  `nodo` tinyint NOT NULL,
  `jefatura` tinyint NOT NULL,
  `eecc` tinyint NOT NULL,
  `entrenador` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `zonasxy`
--

DROP TABLE IF EXISTS `zonasxy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zonasxy` (
  `jefatura` varchar(20) NOT NULL,
  `latitud` varchar(20) CHARACTER SET utf8 NOT NULL,
  `longitud` varchar(29) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`jefatura`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `zonificacion`
--

DROP TABLE IF EXISTS `zonificacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zonificacion` (
  `dpto` varchar(50) DEFAULT NULL,
  `provincia` varchar(50) DEFAULT NULL,
  `distrito` varchar(50) DEFAULT NULL,
  `mdf` varchar(10) DEFAULT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `xunion` varchar(50) DEFAULT NULL,
  `tipo` varchar(10) DEFAULT NULL,
  `region` varchar(40) DEFAULT NULL,
  `jef_cmr` varchar(50) DEFAULT NULL,
  `xxllavemar` varchar(50) DEFAULT NULL,
  `det_region` varchar(50) DEFAULT NULL,
  `sede` varchar(20) DEFAULT NULL,
  `jefatura` varchar(40) DEFAULT NULL,
  `prem_mas` varchar(40) DEFAULT NULL,
  `xxeecc` varchar(40) DEFAULT NULL,
  `supervisor` varchar(40) DEFAULT NULL,
  `entrenador` varchar(100) DEFAULT NULL,
  `microzona` varchar(40) DEFAULT NULL,
  `zona` varchar(40) DEFAULT NULL,
  `zon_region` varchar(40) DEFAULT NULL,
  `xllavemar2` varchar(40) DEFAULT NULL,
  `playas` varchar(40) DEFAULT NULL,
  `eecc` varchar(40) DEFAULT NULL,
  `mzona_catv` varchar(40) DEFAULT NULL,
  `mzona_dth` varchar(40) DEFAULT NULL,
  `jefa_nuevo` varchar(40) DEFAULT NULL,
  `jefa_tac` varchar(40) DEFAULT NULL,
  `bono` varchar(40) DEFAULT NULL,
  `mzona_tac` varchar(40) DEFAULT NULL,
  `mzona_8k` varchar(40) DEFAULT NULL,
  `terreno` varchar(40) DEFAULT NULL,
  KEY `NewIndex1` (`tipo`),
  KEY `NewIndex2` (`mdf`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'catalogos'
--
/*!50003 DROP PROCEDURE IF EXISTS `sp_amplifxpuerto` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`rfalla`@`%` PROCEDURE `sp_amplifxpuerto`()
BEGIN
	REPLACE  catalogos.amplifxpuerto
	SELECT xx.* FROM (
	SELECT IF(cmts='','SINDATO',cmts) AS cmts,IF(cmts='','SINDATO',f_v) AS f_v,nodo,troba,amplificador FROM multiconsulta.`nclientes`
	GROUP BY 1,2,3,4,5 
	HAVING(amplificador<>'')
	ORDER BY 3,4,5) xx
	WHERE cmts<>'SINDATO';
	REPLACE  `amplifxpuerto`
	SELECT xx.* FROM (
	SELECT IF(cmts='','SINDATO',cmts) AS cmts,IF(cmts='','SINDATO',f_v) AS f_v,nodo,troba,amplificador FROM multiconsulta.`nclientes`
	GROUP BY 1,2,3,4,5 
	HAVING(amplificador<>'')
	ORDER BY 3,4,5) xx LEFT JOIN `amplifxpuerto` b 
	ON xx.nodo=b.nodo AND xx.troba=b.troba AND xx.amplificador=b.amplificador
	WHERE xx.cmts='SINDATO' AND b.troba IS NULL;
	
	REPLACE catalogos.amplifxpuerto
	SELECT xx.* FROM (
	SELECT 'SINDATO' cmts,'SINDATO' AS f_v,nodo,PLANO AS troba,codlex AS amplificador FROM cms.`planta_clarita`
	GROUP BY 1,2,3,4,5 
	HAVING(codlex<>'')
	ORDER BY 3,4,5) xx LEFT JOIN catalogos.`amplifxpuerto` b 
	ON xx.nodo=b.nodo AND xx.troba=b.troba AND xx.amplificador=b.amplificador
	WHERE xx.cmts='SINDATO' AND b.troba IS NULL;
	SELECT * FROM catalogos.amplifxpuerto INTO OUTFILE '/temp/amplifxpuerto.csv' FIELDS TERMINATED BY ',' LINES TERMINATED BY '\r\n';
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_llamadas_mes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`rfalla`@`%` PROCEDURE `sp_llamadas_mes`()
BEGIN
	SELECT 'fecha','hora','resultado','Cant' 
	UNION
	SELECT
	  SUBSTR(`inf`.`fecha`,1,8) AS `fecha`,
	  CONCAT('[',SUBSTR(`inf`.`fecha`,10,2),IF(((SUBSTR(`inf`.`fecha`,13,2) >= '00') AND (SUBSTR(`inf`.`fecha`,13,2) <= '15')),']00-15',IF(((SUBSTR(`inf`.`fecha`,13,2) >= '16') AND (SUBSTR(`inf`.`fecha`,13,2) <= '30')),']16-30',IF(((SUBSTR(`inf`.`fecha`,13,2) >= '31') AND (SUBSTR(`inf`.`fecha`,13,2) <= '45')),']31-45',IF(((SUBSTR(`inf`.`fecha`,13,2) >= '46') AND (SUBSTR(`inf`.`fecha`,13,2) <= '60')),']45-59',''))))) AS `hora`,
	  IF(`inf`.`fechaticket` = 'Telefono no Alarmado',`inf`.`fechaticket`,
	  IF(`inf`.`agente` IN ('HFC MANUAL','MASIVA HFC','MASIVA HFC CONFIRMADA','MASIVA HFC MANUAL'),'ALERTA MASIVA HFC',
	  IF(`inf`.`agente` = 'FTTx MANUAL','ALERTA MASIVA FTTH',
	  IF((`inf`.`agente` IS NULL OR `inf`.`fechaticket` IS NULL) ,'Telefono no Alarmado','Telefono no Alarmado'
	  )))) AS `resultado`,
	  COUNT(0) AS `Cant`
	FROM `inf_hfc_dmpe` `inf`
	WHERE 
	DATEDIFF(NOW(),CONCAT(SUBSTR(fecha,1,4),'-',SUBSTR(fecha,5,2),'-',SUBSTR(fecha,7,2)))>=0 AND DATEDIFF(NOW(),CONCAT(SUBSTR(fecha,1,4),'-',SUBSTR(fecha,5,2),'-',SUBSTR(fecha,7,2)))<=30 AND 
	(SUBSTR(`inf`.`fecha`,10,2)IN('00','01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23'))
	GROUP BY 1,2,3
	INTO OUTFILE '/temp/llamadas_mes.csv' FIELDS TERMINATED BY ',' LINES TERMINATED BY '\r\n';
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `dmpe_view`
--

/*!50001 DROP TABLE IF EXISTS `dmpe_view`*/;
/*!50001 DROP VIEW IF EXISTS `dmpe_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`rfalla`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `dmpe_view` AS (select substr(`inf`.`fecha`,1,8) AS `fecha`,concat('[',substr(`inf`.`fecha`,10,2),if(((substr(`inf`.`fecha`,13,2) >= '00') and (substr(`inf`.`fecha`,13,2) <= '15')),']00-15',if(((substr(`inf`.`fecha`,13,2) >= '16') and (substr(`inf`.`fecha`,13,2) <= '30')),']16-30',if(((substr(`inf`.`fecha`,13,2) >= '31') and (substr(`inf`.`fecha`,13,2) <= '45')),']31-45',if(((substr(`inf`.`fecha`,13,2) >= '46') and (substr(`inf`.`fecha`,13,2) <= '60')),']45-59',''))))) AS `hora`,if((`inf`.`fechaticket` = 'Telefono no Alarmado'),`inf`.`fechaticket`,if((`inf`.`agente` in ('HFC MANUAL','MASIVA HFC','MASIVA HFC CONFIRMADA','MASIVA HFC MANUAL')),'ALERTA MASIVA HFC',if((`inf`.`agente` = 'FTTx MANUAL'),'ALERTA MASIVA FTTH',if((isnull(`inf`.`agente`) or isnull(`inf`.`fechaticket`)),'Telefono no Alarmado','Telefono no Alarmado')))) AS `resultado`,count(0) AS `Cant` from `inf_hfc_dmpe` `inf` where (((to_days(now()) - to_days(concat(substr(`inf`.`fecha`,1,4),'-',substr(`inf`.`fecha`,5,2),'-',substr(`inf`.`fecha`,7,2)))) = 0) and (substr(`inf`.`fecha`,10,2) in ('00','01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23')) and (timediff(now(),concat(substr(`inf`.`fecha`,1,4),'-',substr(`inf`.`fecha`,5,2),'-',substr(`inf`.`fecha`,7,2),' ',substr(`inf`.`fecha`,10,8))) >= '00:00:00')) group by 1,2,3) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `redesip_view`
--

/*!50001 DROP TABLE IF EXISTS `redesip_view`*/;
/*!50001 DROP VIEW IF EXISTS `redesip_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`rfalla`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `redesip_view` AS (select concat(`a`.`cmts`,'</br><font size=1 color = black>',if((`b`.`cmts` is not null),`b`.`cmts`,'</br><font size=1  color = black>Nuevo'),'</font>') AS `cmts`,`a`.`scopesgroup` AS `scopesgroup`,sum(`a`.`total`) AS `total`,sum(`a`.`used`) AS `used`,sum(`a`.`available`) AS `available`,((sum(`a`.`used`) / sum(`a`.`total`)) * 100) AS `porc` from (`catalogos`.`redesip_n` `a` left join `ccm1`.`cmts_ip` `b` on((`a`.`cmts` = `b`.`realname`))) where ((`a`.`scopesgroup` not in ('CPE-IP-FIJA','GRUPOS')) and (`a`.`cmts` not in ('SG_AREQ7_C100G','CMTS-CASA','CMTS-CISCO-MAQUETA'))) group by `a`.`cmts`,`a`.`scopesgroup` order by sum(`a`.`available`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `segmentos_view`
--

/*!50001 DROP TABLE IF EXISTS `segmentos_view`*/;
/*!50001 DROP VIEW IF EXISTS `segmentos_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`rfalla`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `segmentos_view` AS (select `premium_fases`.`nodo` AS `nodo`,`premium_fases`.`trobaf` AS `troba`,concat(`premium_fases`.`grupo`,' ',`premium_fases`.`grupo_microzona`) AS `segmento` from `premium_fases` where (`premium_fases`.`sw` = 1)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `trobas_digi_view`
--

/*!50001 DROP TABLE IF EXISTS `trobas_digi_view`*/;
/*!50001 DROP VIEW IF EXISTS `trobas_digi_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`rfalla`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `trobas_digi_view` AS (select `trobas_digitalizadas`.`nodo` AS `nodo`,`trobas_digitalizadas`.`troba` AS `troba`,`trobas_digitalizadas`.`fecha` AS `fecha` from `trobas_digitalizadas` where ((to_days(now()) - to_days(`trobas_digitalizadas`.`fechan`)) <= 30)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `zonales_catv_view`
--

/*!50001 DROP TABLE IF EXISTS `zonales_catv_view`*/;
/*!50001 DROP VIEW IF EXISTS `zonales_catv_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`rfalla`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `zonales_catv_view` AS (select `zonificacion`.`mdf` AS `nodo`,`zonificacion`.`jefatura` AS `jefatura`,`zonificacion`.`eecc` AS `eecc`,`zonificacion`.`entrenador` AS `entrenador` from `zonificacion` where ((`zonificacion`.`tipo` = 'NODO/DTH') or (`zonificacion`.`tipo` = 'NODO/CATV'))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-23 13:00:52
