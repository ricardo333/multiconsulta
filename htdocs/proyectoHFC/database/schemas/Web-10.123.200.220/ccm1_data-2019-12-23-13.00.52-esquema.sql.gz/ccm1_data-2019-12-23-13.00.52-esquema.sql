-- MySQL dump 10.16  Distrib 10.1.40-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: ccm1_data
-- ------------------------------------------------------
-- Server version	10.1.40-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cm_obsoletos`
--

DROP TABLE IF EXISTS `cm_obsoletos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cm_obsoletos` (
  `docsis` varchar(7) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `Empresa` varchar(3) CHARACTER SET latin1 DEFAULT NULL,
  `NroCliente` double DEFAULT NULL,
  `Nombre` varchar(200) CHARACTER SET latin1 DEFAULT NULL,
  `MACAddress` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `Fechadealta` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `Fechadeactivacion` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `Fabricante` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `Modelo` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `hwversion` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `Versioon` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `Tipodedispositivo` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `IPCablemodem` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `CMTS` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `temp` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `fecha_upload` datetime DEFAULT NULL,
  KEY `NroCliente` (`NroCliente`),
  KEY `MACAddress` (`MACAddress`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cm_obsoletos_tabla`
--

DROP TABLE IF EXISTS `cm_obsoletos_tabla`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cm_obsoletos_tabla` (
  `fabricante` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `modelo` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  KEY `fabricante` (`fabricante`),
  KEY `modelo` (`modelo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marca_modelo_docsis_total`
--

DROP TABLE IF EXISTS `marca_modelo_docsis_total`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marca_modelo_docsis_total` (
  `docsis` varchar(7) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `Empresa` varchar(3) DEFAULT NULL,
  `NroCliente` double DEFAULT NULL,
  `Nombre` varchar(200) DEFAULT NULL,
  `MACAddress` varchar(20) DEFAULT NULL,
  `Fechadealta` varchar(20) DEFAULT NULL,
  `Fechadeactivacion` varchar(20) DEFAULT NULL,
  `Fabricante` varchar(100) DEFAULT NULL,
  `Modelo` varchar(100) DEFAULT NULL,
  `hwversion` varchar(100) DEFAULT NULL,
  `Versioon` varchar(100) DEFAULT NULL,
  `Tipodedispositivo` varchar(100) DEFAULT NULL,
  `IPCablemodem` varchar(20) DEFAULT NULL,
  `CMTS` varchar(30) DEFAULT NULL,
  `temp` varchar(20) DEFAULT NULL,
  `fecha_upload` datetime DEFAULT NULL,
  UNIQUE KEY `idxmac` (`MACAddress`),
  KEY `idxdocsis` (`docsis`),
  KEY `idxcodcli` (`NroCliente`),
  KEY `CMTS` (`CMTS`),
  KEY `Fabricante` (`Fabricante`),
  KEY `Modelo` (`Modelo`),
  KEY `MACAddress` (`MACAddress`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marca_modelo_docsis_total_back`
--

DROP TABLE IF EXISTS `marca_modelo_docsis_total_back`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marca_modelo_docsis_total_back` (
  `docsis` varchar(7) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `Empresa` varchar(3) DEFAULT NULL,
  `NroCliente` double DEFAULT NULL,
  `Nombre` varchar(200) DEFAULT NULL,
  `MACAddress` varchar(20) DEFAULT NULL,
  `Fechadealta` varchar(20) DEFAULT NULL,
  `Fechadeactivacion` varchar(20) DEFAULT NULL,
  `Fabricante` varchar(100) DEFAULT NULL,
  `Modelo` varchar(100) DEFAULT NULL,
  `hwversion` varchar(100) DEFAULT NULL,
  `Versioon` varchar(100) DEFAULT NULL,
  `Tipodedispositivo` varchar(100) DEFAULT NULL,
  `IPCablemodem` varchar(20) DEFAULT NULL,
  `CMTS` varchar(30) DEFAULT NULL,
  `temp` varchar(20) DEFAULT NULL,
  `fecha_upload` datetime DEFAULT NULL,
  UNIQUE KEY `idxmac` (`MACAddress`),
  KEY `idxdocsis` (`docsis`),
  KEY `idxcodcli` (`NroCliente`),
  KEY `CMTS` (`CMTS`),
  KEY `Fabricante` (`Fabricante`),
  KEY `Modelo` (`Modelo`),
  KEY `MACAddress` (`MACAddress`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marca_modelo_docsis_total_final`
--

DROP TABLE IF EXISTS `marca_modelo_docsis_total_final`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marca_modelo_docsis_total_final` (
  `docsis` varchar(7) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `Empresa` varchar(3) DEFAULT NULL,
  `NroCliente` double DEFAULT NULL,
  `Nombre` varchar(200) DEFAULT NULL,
  `MACAddress` varchar(20) DEFAULT NULL,
  `Fechadealta` varchar(20) DEFAULT NULL,
  `Fechadeactivacion` varchar(20) DEFAULT NULL,
  `Fabricante` varchar(100) DEFAULT NULL,
  `Modelo` varchar(100) DEFAULT NULL,
  `hwversion` varchar(100) DEFAULT NULL,
  `Versioon` varchar(100) DEFAULT NULL,
  `Tipodedispositivo` varchar(100) DEFAULT NULL,
  `IPCablemodem` varchar(20) DEFAULT NULL,
  `CMTS` varchar(30) DEFAULT NULL,
  `temp` varchar(20) DEFAULT NULL,
  `fecha_upload` datetime DEFAULT NULL,
  UNIQUE KEY `idxmac` (`MACAddress`),
  KEY `idxdocsis` (`docsis`),
  KEY `idxcodcli` (`NroCliente`),
  KEY `CMTS` (`CMTS`),
  KEY `Fabricante` (`Fabricante`),
  KEY `Modelo` (`Modelo`),
  KEY `MACAddress` (`MACAddress`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `planta_hfc_total`
--

DROP TABLE IF EXISTS `planta_hfc_total`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `planta_hfc_total` (
  `telefono` varchar(25) DEFAULT NULL,
  `inscripcion` varchar(40) DEFAULT NULL,
  `codcliente_cms` varchar(25) DEFAULT NULL,
  `codservicio_cms` varchar(25) DEFAULT NULL,
  `tipo_promocion` varchar(50) DEFAULT NULL,
  `veloc_vigente` varchar(20) DEFAULT NULL,
  `veloc_real` varchar(20) DEFAULT NULL,
  `fecha_ini` varchar(50) DEFAULT NULL,
  `fecha_fin` varchar(50) DEFAULT NULL,
  `fecha_upload` datetime DEFAULT NULL,
  KEY `idxtelefono` (`telefono`),
  KEY `idxcodcliente` (`codcliente_cms`),
  KEY `idxcodservicio` (`codservicio_cms`),
  KEY `idxvelocvig` (`veloc_vigente`),
  KEY `idxvelocreal` (`veloc_real`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wsccm1_parametros_rf`
--

DROP TABLE IF EXISTS `wsccm1_parametros_rf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wsccm1_parametros_rf` (
  `usPwr_min` double DEFAULT NULL,
  `usPwr_max` double DEFAULT NULL,
  `dsPwr_min` double DEFAULT NULL,
  `dsPwr_max` double DEFAULT NULL,
  `usSnr_max` double DEFAULT NULL,
  `dsSnr_max` double DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wsccm1_pruebas_cablemodem`
--

DROP TABLE IF EXISTS `wsccm1_pruebas_cablemodem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wsccm1_pruebas_cablemodem` (
  `mac_address` varchar(50) DEFAULT NULL,
  `resultado1` varchar(100) DEFAULT NULL,
  `resultado2` varchar(25) DEFAULT NULL,
  `fecha_mov` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'ccm1_data'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-23 13:00:52
