-- MySQL dump 10.15  Distrib 10.0.34-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: arboldecisiones_backup
-- ------------------------------------------------------
-- Server version	10.0.34-MariaDB-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `decisiones`
--

DROP TABLE IF EXISTS `decisiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `decisiones` (
  `iddecision` int(11) NOT NULL AUTO_INCREMENT,
  `idclientecrm` int(11) DEFAULT NULL,
  `usuario` varchar(20) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  `solucion` int(11) DEFAULT NULL,
  `paso0` int(11) DEFAULT NULL,
  `paso1` int(11) DEFAULT NULL,
  `paso2` int(11) DEFAULT NULL,
  `paso3` int(11) DEFAULT NULL,
  `paso4` int(11) DEFAULT NULL,
  `paso5` int(11) DEFAULT NULL,
  `paso6` int(11) DEFAULT NULL,
  `paso7` int(11) DEFAULT NULL,
  `paso8` int(11) DEFAULT NULL,
  `paso9` int(11) DEFAULT NULL,
  `paso10` int(11) DEFAULT NULL,
  `paso11` int(11) DEFAULT NULL,
  `paso12` int(11) DEFAULT NULL,
  `paso13` int(11) DEFAULT NULL,
  `paso14` int(11) DEFAULT NULL,
  `paso15` int(11) DEFAULT NULL,
  `paso16` int(11) DEFAULT NULL,
  `paso17` int(11) unsigned DEFAULT NULL,
  `paso18` int(11) DEFAULT NULL,
  `paso19` int(11) DEFAULT NULL,
  `paso20` int(11) DEFAULT NULL,
  `paso21` int(11) DEFAULT NULL,
  `paso22` int(11) DEFAULT NULL,
  PRIMARY KEY (`iddecision`),
  KEY `idusuario` (`usuario`),
  KEY `fechahora` (`fechahora`),
  KEY `paso0` (`paso0`),
  KEY `paso1` (`paso1`),
  KEY `paso2` (`paso2`),
  KEY `paso3` (`paso3`),
  KEY `paso4` (`paso4`),
  KEY `iclientecrm` (`idclientecrm`),
  KEY `paso5` (`paso5`),
  KEY `paso6` (`paso6`),
  KEY `paso7` (`paso7`),
  KEY `paso8` (`paso8`),
  KEY `paso9` (`paso9`),
  KEY `paso10` (`paso10`),
  KEY `paso11` (`paso11`),
  KEY `paso12` (`paso12`),
  KEY `paso13` (`paso13`),
  KEY `paso14` (`paso14`),
  KEY `paso15` (`paso15`),
  KEY `paso16` (`paso16`),
  KEY `paso17` (`paso17`),
  KEY `paso18` (`paso18`),
  KEY `paso19` (`paso19`),
  KEY `paso20` (`paso20`),
  KEY `paso21` (`paso21`),
  KEY `paso22` (`paso22`)
) ENGINE=MyISAM AUTO_INCREMENT=455094 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `detalles_solucion_decisiones`
--

DROP TABLE IF EXISTS `detalles_solucion_decisiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalles_solucion_decisiones` (
  `idDecisionArbol` int(11) DEFAULT NULL,
  `ultimoPaso` varchar(50) DEFAULT NULL,
  `id_ultimo_paso` int(11) DEFAULT NULL,
  `det_ultimo_paso` varchar(100) DEFAULT NULL,
  UNIQUE KEY `idDecisionArbol` (`idDecisionArbol`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marcaRapida`
--

DROP TABLE IF EXISTS `marcaRapida`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marcaRapida` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mensajeArbol`
--

DROP TABLE IF EXISTS `mensajeArbol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mensajeArbol` (
  `idmensaje` int(11) NOT NULL AUTO_INCREMENT,
  `mensaje` varchar(35) DEFAULT NULL,
  `paso00` int(1) unsigned zerofill DEFAULT NULL,
  `paso01` int(1) unsigned zerofill DEFAULT NULL,
  `paso02` int(1) unsigned zerofill DEFAULT NULL,
  `paso03` int(1) unsigned zerofill DEFAULT NULL,
  `paso04` int(1) unsigned zerofill DEFAULT NULL,
  `paso05` int(1) unsigned zerofill DEFAULT NULL,
  `paso06` int(1) unsigned zerofill DEFAULT NULL,
  `paso07` int(1) unsigned zerofill DEFAULT NULL,
  `paso08` int(1) unsigned zerofill DEFAULT NULL,
  `paso09` int(1) unsigned zerofill DEFAULT NULL,
  `paso10` int(1) unsigned zerofill DEFAULT NULL,
  `paso11` int(1) unsigned zerofill DEFAULT NULL,
  `paso12` int(1) unsigned zerofill DEFAULT NULL,
  `paso13` int(1) unsigned zerofill DEFAULT NULL,
  `paso14` int(1) unsigned zerofill DEFAULT NULL,
  `paso15` int(1) unsigned zerofill DEFAULT NULL,
  `paso16` int(1) unsigned zerofill DEFAULT NULL,
  `paso17` int(1) unsigned zerofill DEFAULT NULL,
  `paso18` int(1) unsigned zerofill DEFAULT NULL,
  `paso19` int(1) unsigned zerofill DEFAULT NULL,
  `paso20` int(1) unsigned zerofill DEFAULT NULL,
  `paso21` int(1) unsigned zerofill DEFAULT NULL,
  `mensajeCompleto` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`idmensaje`),
  KEY `mensaje` (`mensaje`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso00`
--

DROP TABLE IF EXISTS `paso00`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso00` (
  `id` int(11) NOT NULL,
  `detalle` varchar(200) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso01`
--

DROP TABLE IF EXISTS `paso01`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso01` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(200) DEFAULT NULL,
  `paso0` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso0` (`paso0`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso02`
--

DROP TABLE IF EXISTS `paso02`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso02` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(200) DEFAULT NULL,
  `paso1` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso1` (`paso1`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso03`
--

DROP TABLE IF EXISTS `paso03`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso03` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(200) DEFAULT NULL,
  `paso2` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso2` (`paso2`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso04`
--

DROP TABLE IF EXISTS `paso04`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso04` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(1500) DEFAULT NULL,
  `paso3` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso3` (`paso3`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=110 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso05`
--

DROP TABLE IF EXISTS `paso05`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso05` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(200) DEFAULT NULL,
  `paso4` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso4` (`paso4`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=132 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso06`
--

DROP TABLE IF EXISTS `paso06`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso06` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(500) DEFAULT NULL,
  `paso5` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso5` (`paso5`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=149 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso07`
--

DROP TABLE IF EXISTS `paso07`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso07` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(500) DEFAULT NULL,
  `paso6` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso6` (`paso6`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=149 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso08`
--

DROP TABLE IF EXISTS `paso08`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso08` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(500) DEFAULT NULL,
  `paso7` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso7` (`paso7`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso09`
--

DROP TABLE IF EXISTS `paso09`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso09` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(200) DEFAULT NULL,
  `paso8` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso8` (`paso8`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=139 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso10`
--

DROP TABLE IF EXISTS `paso10`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso10` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(200) DEFAULT NULL,
  `paso9` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso9` (`paso9`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=135 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso11`
--

DROP TABLE IF EXISTS `paso11`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso11` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(200) DEFAULT NULL,
  `paso10` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso10` (`paso10`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso12`
--

DROP TABLE IF EXISTS `paso12`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso12` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(200) DEFAULT NULL,
  `paso11` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso11` (`paso11`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso13`
--

DROP TABLE IF EXISTS `paso13`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso13` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(1000) DEFAULT NULL,
  `paso12` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso12` (`paso12`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso14`
--

DROP TABLE IF EXISTS `paso14`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso14` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(200) DEFAULT NULL,
  `paso13` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso13` (`paso13`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso15`
--

DROP TABLE IF EXISTS `paso15`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso15` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(200) DEFAULT NULL,
  `paso14` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso14` (`paso14`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso16`
--

DROP TABLE IF EXISTS `paso16`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso16` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(200) DEFAULT NULL,
  `paso15` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso15` (`paso15`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso17`
--

DROP TABLE IF EXISTS `paso17`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso17` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(200) DEFAULT NULL,
  `paso16` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso16` (`paso16`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso18`
--

DROP TABLE IF EXISTS `paso18`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso18` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(200) DEFAULT NULL,
  `paso17` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso17` (`paso17`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso19`
--

DROP TABLE IF EXISTS `paso19`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso19` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(200) DEFAULT NULL,
  `paso18` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso18` (`paso18`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso20`
--

DROP TABLE IF EXISTS `paso20`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso20` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(200) DEFAULT NULL,
  `paso19` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso19` (`paso19`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso21`
--

DROP TABLE IF EXISTS `paso21`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso21` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(200) DEFAULT NULL,
  `paso20` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso19` (`paso20`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paso22`
--

DROP TABLE IF EXISTS `paso22`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paso22` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(200) DEFAULT NULL,
  `paso21` int(11) DEFAULT NULL,
  `img_total` varchar(100) DEFAULT NULL,
  `img_negocios` varchar(100) DEFAULT NULL,
  `img_masivo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paso19` (`paso21`),
  KEY `imagen` (`img_total`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pasosArbol`
--

DROP TABLE IF EXISTS `pasosArbol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pasosArbol` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  `detalle` varchar(500) DEFAULT NULL,
  `posicion` int(11) DEFAULT NULL,
  `pasoAnterior` varchar(50) DEFAULT NULL,
  `tablaSiguiente` varchar(50) DEFAULT NULL,
  `tablaAnterior` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reportearbol`
--

DROP TABLE IF EXISTS `reportearbol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reportearbol` (
  `iddecision` int(11) NOT NULL DEFAULT '0',
  `idclientecrm` int(11) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  `ldmarca_rapida` varchar(11) CHARACTER SET utf8 DEFAULT NULL,
  `idpaso` varchar(11) CHARACTER SET utf8 DEFAULT NULL,
  `tbpaso` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
  `marcarapida` varchar(150) CHARACTER SET utf8 NOT NULL,
  `ultimopaso` varchar(200) CHARACTER SET utf8 NOT NULL,
  `resultadoarbol` varchar(300) DEFAULT NULL,
  KEY `iddecision` (`iddecision`),
  KEY `idclientecrm` (`idclientecrm`),
  KEY `ldmarca_rapida` (`ldmarca_rapida`),
  KEY `idpaso` (`idpaso`),
  KEY `tbpaso` (`tbpaso`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbresumen`
--

DROP TABLE IF EXISTS `tbresumen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbresumen` (
  `detalle` varchar(300) DEFAULT NULL,
  `solucion` varchar(100) DEFAULT NULL,
  KEY `detalle` (`detalle`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'arboldecisiones_backup'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-23 13:21:20
