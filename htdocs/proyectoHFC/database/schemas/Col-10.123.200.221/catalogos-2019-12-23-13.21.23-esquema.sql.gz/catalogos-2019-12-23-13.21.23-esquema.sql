-- MySQL dump 10.15  Distrib 10.0.34-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: catalogos
-- ------------------------------------------------------
-- Server version	10.0.34-MariaDB-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `analgesicos`
--

DROP TABLE IF EXISTS `analgesicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `analgesicos` (
  `AbonadoCms` int(11) DEFAULT NULL,
  `ClienteCms` int(11) DEFAULT NULL,
  `Telefono` int(11) DEFAULT NULL,
  `AbonadoCmsGrupo` varchar(30) DEFAULT NULL,
  `mensaje` varchar(200) DEFAULT NULL,
  UNIQUE KEY `codcli` (`ClienteCms`),
  KEY `mensaje` (`mensaje`),
  KEY `AbonadoCms` (`AbonadoCms`),
  KEY `Telefono` (`Telefono`),
  KEY `AbonadoCmsGrupo` (`AbonadoCmsGrupo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `db_fuentes`
--

DROP TABLE IF EXISTS `db_fuentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_fuentes` (
  `nodo` varchar(2) CHARACTER SET latin1 DEFAULT NULL,
  `troba` varchar(4) CHARACTER SET latin1 DEFAULT NULL,
  `mac` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `mac3` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `mac4` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `zonal` varchar(10) DEFAULT NULL,
  `distrito` varchar(80) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `latitudx` varchar(20) DEFAULT NULL,
  `longitudy` varchar(20) DEFAULT NULL,
  `marcatroba` varchar(30) DEFAULT NULL,
  `respaldo` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `descricion` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `tienebateria` varchar(1) CHARACTER SET latin1 DEFAULT NULL,
  `clave` varchar(6) CHARACTER SET latin1 DEFAULT NULL,
  `segundafuente` varchar(1) DEFAULT NULL,
  `version` int(1) DEFAULT NULL,
  UNIQUE KEY `mac` (`mac`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `clave` (`clave`),
  KEY `zonal` (`zonal`),
  KEY `distrito` (`distrito`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dirfuentes`
--

DROP TABLE IF EXISTS `dirfuentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dirfuentes` (
  `item` int(11) DEFAULT NULL,
  `nodo` varchar(2) DEFAULT NULL,
  `troba` varchar(4) DEFAULT NULL,
  `macaddress` varchar(20) DEFAULT NULL,
  `distrito` varchar(100) DEFAULT NULL,
  `direccion` varchar(1000) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oui_fuentes`
--

DROP TABLE IF EXISTS `oui_fuentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oui_fuentes` (
  `oui_fuentes` varchar(6) DEFAULT NULL,
  `marca` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `InputVoltage` varchar(50) DEFAULT NULL,
  `OutputVoltage` varchar(50) DEFAULT NULL,
  `OutputCurrent` varchar(50) DEFAULT NULL,
  `TotalStringVoltage` varchar(50) DEFAULT NULL,
  `version` int(1) DEFAULT NULL,
  `temperature` varchar(50) DEFAULT NULL,
  KEY `oui_fuentes` (`oui_fuentes`),
  KEY `version` (`version`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `querys`
--

DROP TABLE IF EXISTS `querys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `querys` (
  `detalle` varchar(500) DEFAULT NULL,
  `query` longblob
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'catalogos'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-23 13:21:23
