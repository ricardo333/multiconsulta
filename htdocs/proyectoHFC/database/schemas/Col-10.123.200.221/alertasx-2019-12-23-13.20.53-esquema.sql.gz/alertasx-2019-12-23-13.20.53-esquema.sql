-- MySQL dump 10.15  Distrib 10.0.34-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: alertasx
-- ------------------------------------------------------
-- Server version	10.0.34-MariaDB-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary table structure for view `alertas_energia_real_view`
--

DROP TABLE IF EXISTS `alertas_energia_real_view`;
/*!50001 DROP VIEW IF EXISTS `alertas_energia_real_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `alertas_energia_real_view` (
  `macaddress` tinyint NOT NULL,
  `ipaddress` tinyint NOT NULL,
  `nodo` tinyint NOT NULL,
  `troba` tinyint NOT NULL,
  `distrito` tinyint NOT NULL,
  `direccion` tinyint NOT NULL,
  `latitudx` tinyint NOT NULL,
  `longitudy` tinyint NOT NULL,
  `cmts` tinyint NOT NULL,
  `interface` tinyint NOT NULL,
  `InputVoltagefinal` tinyint NOT NULL,
  `OutputVoltagefinal` tinyint NOT NULL,
  `OutputCurrentfinal` tinyint NOT NULL,
  `TotalStringVoltagefinal` tinyint NOT NULL,
  `EstadoInversor` tinyint NOT NULL,
  `resultadosnmp` tinyint NOT NULL,
  `fechahora` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `fuentes_snmp`
--

DROP TABLE IF EXISTS `fuentes_snmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fuentes_snmp` (
  `macaddress` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `ipaddress` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `nodo` varchar(2) CHARACTER SET latin1 DEFAULT NULL,
  `troba` varchar(4) CHARACTER SET latin1 DEFAULT NULL,
  `distrito` varchar(80) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `latitudx` varchar(20) DEFAULT NULL,
  `longitudy` varchar(20) DEFAULT NULL,
  `cmts` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `interface` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `InputVoltagefinal` float NOT NULL,
  `OutputVoltagefinal` float NOT NULL,
  `OutputCurrentfinal` float NOT NULL,
  `TotalStringVoltagefinal` float NOT NULL,
  `EstadoInversor` int(11) DEFAULT NULL,
  `resultadosnmp` varchar(20) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `temperature` float DEFAULT NULL,
  UNIQUE KEY `macaddress` (`macaddress`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fecha` (`fechahora`),
  KEY `version` (`version`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fuentes_snmp_a`
--

DROP TABLE IF EXISTS `fuentes_snmp_a`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fuentes_snmp_a` (
  `macaddress` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `ipaddress` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `nodo` varchar(2) CHARACTER SET latin1 DEFAULT NULL,
  `troba` varchar(4) CHARACTER SET latin1 DEFAULT NULL,
  `distrito` varchar(80) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `latitudx` varchar(20) DEFAULT NULL,
  `longitudy` varchar(20) DEFAULT NULL,
  `cmts` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `interface` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `InputVoltagefinal` float NOT NULL,
  `OutputVoltagefinal` float NOT NULL,
  `OutputCurrentfinal` float NOT NULL,
  `TotalStringVoltagefinal` float NOT NULL,
  `EstadoInversor` int(11) DEFAULT NULL,
  `resultadosnmp` varchar(20) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  UNIQUE KEY `macaddress` (`macaddress`),
  KEY `nodo` (`nodo`),
  KEY `troba` (`troba`),
  KEY `fecha` (`fechahora`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fuentes_snmp_hist`
--

DROP TABLE IF EXISTS `fuentes_snmp_hist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fuentes_snmp_hist` (
  `macadDress` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `InputVoltagefinal` float NOT NULL,
  `OutputVoltagefinal` float NOT NULL,
  `OutputCurrentfinal` float NOT NULL,
  `TotalStringVoltagefinal` float NOT NULL,
  `EstadoInversor` int(11) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  `temperature` float DEFAULT NULL,
  UNIQUE KEY `macadDress_2` (`macadDress`,`fechahora`),
  KEY `macadDress` (`macadDress`),
  KEY `fechahora` (`fechahora`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fuentes_snmp_hist_b`
--

DROP TABLE IF EXISTS `fuentes_snmp_hist_b`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fuentes_snmp_hist_b` (
  `macadDress` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `InputVoltagefinal` float NOT NULL,
  `OutputVoltagefinal` float NOT NULL,
  `OutputCurrentfinal` float NOT NULL,
  `TotalStringVoltagefinal` float NOT NULL,
  `EstadoInversor` int(11) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  UNIQUE KEY `macadDress_2` (`macadDress`,`fechahora`),
  KEY `macadDress` (`macadDress`),
  KEY `fechahora` (`fechahora`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fuentes_snmp_hist_c`
--

DROP TABLE IF EXISTS `fuentes_snmp_hist_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fuentes_snmp_hist_c` (
  `macadDress` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `InputVoltagefinal` float NOT NULL,
  `OutputVoltagefinal` float NOT NULL,
  `OutputCurrentfinal` float NOT NULL,
  `TotalStringVoltagefinal` float NOT NULL,
  `EstadoInversor` int(11) DEFAULT NULL,
  `fechahora` varchar(20) DEFAULT NULL,
  UNIQUE KEY `macadDress_2` (`macadDress`,`fechahora`),
  KEY `macadDress` (`macadDress`),
  KEY `fechahora` (`fechahora`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `fuentes_view`
--

DROP TABLE IF EXISTS `fuentes_view`;
/*!50001 DROP VIEW IF EXISTS `fuentes_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `fuentes_view` (
  `macaddress` tinyint NOT NULL,
  `ipaddress` tinyint NOT NULL,
  `nodo` tinyint NOT NULL,
  `troba` tinyint NOT NULL,
  `distrito` tinyint NOT NULL,
  `direccion` tinyint NOT NULL,
  `latitudx` tinyint NOT NULL,
  `longitudy` tinyint NOT NULL,
  `cmts` tinyint NOT NULL,
  `interface` tinyint NOT NULL,
  `InputVoltagefinal` tinyint NOT NULL,
  `InputVoltagefinalcolor` tinyint NOT NULL,
  `OutputVoltagefinal` tinyint NOT NULL,
  `OutputVoltagefinalcolor` tinyint NOT NULL,
  `OutputCurrentfinal` tinyint NOT NULL,
  `OutputCurrentfinalcolor` tinyint NOT NULL,
  `TotalStringVoltagefinal` tinyint NOT NULL,
  `TotalStringVoltagefinalcolor` tinyint NOT NULL,
  `EstadoInversor` tinyint NOT NULL,
  `ColorTemperatura` tinyint NOT NULL,
  `EstadoTemperatura` tinyint NOT NULL,
  `colorinversor` tinyint NOT NULL,
  `puntaje` tinyint NOT NULL,
  `fechahora` tinyint NOT NULL,
  `resultadosnmp` tinyint NOT NULL,
  `tienebateria` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `listafuentes_view`
--

DROP TABLE IF EXISTS `listafuentes_view`;
/*!50001 DROP VIEW IF EXISTS `listafuentes_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `listafuentes_view` (
  `macaddress` tinyint NOT NULL,
  `InputVoltage` tinyint NOT NULL,
  `OutputVoltage` tinyint NOT NULL,
  `OutputCurrent` tinyint NOT NULL,
  `TotalStringVoltage` tinyint NOT NULL,
  `temperature` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Dumping routines for database 'alertasx'
--
/*!50003 DROP PROCEDURE IF EXISTS `sp_actualiza_estados_fuentes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_actualiza_estados_fuentes`()
BEGIN
REPLACE alertasx.fuentes_snmp_a 
SELECT c.* FROM alertasx.fuentes_snmp c WHERE c.resultadosnmp='SNMPOK'  AND c.`InputVoltagefinal`>180;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `alertas_energia_real_view`
--

/*!50001 DROP TABLE IF EXISTS `alertas_energia_real_view`*/;
/*!50001 DROP VIEW IF EXISTS `alertas_energia_real_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `alertas_energia_real_view` AS (select `a`.`macaddress` AS `macaddress`,`a`.`ipaddress` AS `ipaddress`,`a`.`nodo` AS `nodo`,`a`.`troba` AS `troba`,`a`.`distrito` AS `distrito`,`a`.`direccion` AS `direccion`,`a`.`latitudx` AS `latitudx`,`a`.`longitudy` AS `longitudy`,`a`.`cmts` AS `cmts`,`a`.`interface` AS `interface`,`a`.`InputVoltagefinal` AS `InputVoltagefinal`,`a`.`OutputVoltagefinal` AS `OutputVoltagefinal`,`a`.`OutputCurrentfinal` AS `OutputCurrentfinal`,`a`.`TotalStringVoltagefinal` AS `TotalStringVoltagefinal`,`a`.`EstadoInversor` AS `EstadoInversor`,`a`.`resultadosnmp` AS `resultadosnmp`,`a`.`fechahora` AS `fechahora` from (`fuentes_snmp` `a` join `fuentes_snmp_a` `b` on((`a`.`macaddress` = `b`.`macaddress`))) where ((`a`.`resultadosnmp` = 'SNMPOK') and (`a`.`InputVoltagefinal` < 180))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `fuentes_view`
--

/*!50001 DROP TABLE IF EXISTS `fuentes_view`*/;
/*!50001 DROP VIEW IF EXISTS `fuentes_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `fuentes_view` AS (select `a`.`macaddress` AS `macaddress`,`a`.`ipaddress` AS `ipaddress`,`a`.`nodo` AS `nodo`,`a`.`troba` AS `troba`,`a`.`distrito` AS `distrito`,`a`.`direccion` AS `direccion`,`a`.`latitudx` AS `latitudx`,`a`.`longitudy` AS `longitudy`,`a`.`cmts` AS `cmts`,`a`.`interface` AS `interface`,`a`.`InputVoltagefinal` AS `InputVoltagefinal`,if((`a`.`InputVoltagefinal` > 250),'RED',if(((`a`.`InputVoltagefinal` > 230) and (`a`.`InputVoltagefinal` <= 250)),'ORANGE',if(((`a`.`InputVoltagefinal` >= 190) and (`a`.`InputVoltagefinal` <= 230)),'GREEN',if(((`a`.`InputVoltagefinal` >= 180) and (`a`.`InputVoltagefinal` <= 190)),'ORANGE',if((`a`.`InputVoltagefinal` < 180),'RED',''))))) AS `InputVoltagefinalcolor`,`a`.`OutputVoltagefinal` AS `OutputVoltagefinal`,if((`a`.`OutputVoltagefinal` > 95),'RED',if(((`a`.`OutputVoltagefinal` > 90) and (`a`.`OutputVoltagefinal` <= 95)),'ORANGE',if(((`a`.`OutputVoltagefinal` >= 60) and (`a`.`OutputVoltagefinal` <= 90)),'GREEN',if(((`a`.`OutputVoltagefinal` >= 40) and (`a`.`OutputVoltagefinal` <= 60)),'ORANGE',if((`a`.`OutputVoltagefinal` < 40),'RED',''))))) AS `OutputVoltagefinalcolor`,`a`.`OutputCurrentfinal` AS `OutputCurrentfinal`,if((`a`.`OutputCurrentfinal` > 17),'RED',if(((`a`.`OutputCurrentfinal` > 15) and (`a`.`OutputCurrentfinal` <= 17)),'ORANGE',if(((`a`.`OutputCurrentfinal` >= 4) and (`a`.`OutputCurrentfinal` <= 15)),'GREEN',if(((`a`.`OutputCurrentfinal` > 0) and (`a`.`OutputCurrentfinal` <= 4)),'ORANGE',if((`a`.`OutputCurrentfinal` <= 0),'RED',''))))) AS `OutputCurrentfinalcolor`,if(((`a`.`TotalStringVoltagefinal` = 0) and (`b`.`tienebateria` = 'N')),'SnBat',`a`.`TotalStringVoltagefinal`) AS `TotalStringVoltagefinal`,if(((`a`.`TotalStringVoltagefinal` > 45) and (`a`.`InputVoltagefinal` = 0)),'RED',if(((`a`.`TotalStringVoltagefinal` > 44) and (`a`.`TotalStringVoltagefinal` <= 45) and (`a`.`InputVoltagefinal` < 180)),'ORANGE',if(((`a`.`TotalStringVoltagefinal` >= 33) and (`a`.`TotalStringVoltagefinal` <= 44) and (`a`.`InputVoltagefinal` > 190)),'GREEN',if(((`a`.`TotalStringVoltagefinal` > 0) and (`a`.`TotalStringVoltagefinal` <= 33) and (`a`.`InputVoltagefinal` < 190)),'ORANGE',if(((`a`.`TotalStringVoltagefinal` <= 0) and (`a`.`InputVoltagefinal` < 180) and isnull(`b`.`tienebateria`)),'RED',''))))) AS `TotalStringVoltagefinalcolor`,`a`.`EstadoInversor` AS `EstadoInversor`,if(((`a`.`temperature` >= -(80)) and (`a`.`temperature` <= 80)),'GREEN',if(((`a`.`temperature` >= 81) and (`a`.`temperature` <= 120)),'ORANGE',if((`a`.`temperature` >= 121),'RED',''))) AS `ColorTemperatura`,`a`.`temperature` AS `EstadoTemperatura`,if((`a`.`EstadoInversor` = 1),'GREEN',if((`a`.`EstadoInversor` = 2),'ORANGE',if((`a`.`EstadoInversor` = 0),'RED',if((`a`.`EstadoInversor` > 2),'ORANGE','')))) AS `colorinversor`,((if((`a`.`resultadosnmp` = 'SNMPOK'),((((((if((`a`.`InputVoltagefinal` > 250),'9',if(((`a`.`InputVoltagefinal` > 230) and (`a`.`InputVoltagefinal` <= 250)),'5',if(((`a`.`InputVoltagefinal` >= 190) and (`a`.`InputVoltagefinal` <= 230) and (`b`.`tienebateria` = 'N')),'0',if(((`a`.`InputVoltagefinal` >= 180) and (`a`.`InputVoltagefinal` <= 190)),'5',if((`a`.`InputVoltagefinal` < 180),'9',''))))) + if((`a`.`OutputVoltagefinal` > 95),'9',if(((`a`.`OutputVoltagefinal` > 90) and (`a`.`OutputVoltagefinal` <= 95)),'5',if(((`a`.`OutputVoltagefinal` >= 60) and (`a`.`OutputVoltagefinal` <= 90) and (`b`.`tienebateria` = 'N')),'0',if(((`a`.`OutputVoltagefinal` >= 40) and (`a`.`OutputVoltagefinal` <= 60)),'5',if((`a`.`OutputVoltagefinal` < 40),'9','')))))) + if((`a`.`OutputCurrentfinal` > 17),'9',if(((`a`.`OutputCurrentfinal` > 15) and (`a`.`OutputCurrentfinal` <= 17)),'5',if(((`a`.`OutputCurrentfinal` >= 4) and (`a`.`OutputCurrentfinal` <= 15) and (`b`.`tienebateria` = 'N')),'0',if(((`a`.`OutputCurrentfinal` > 0) and (`a`.`OutputCurrentfinal` <= 4)),'5',if((`a`.`OutputCurrentfinal` <= 0),'9','')))))) + if((`a`.`TotalStringVoltagefinal` > 45),'18',if(((`a`.`TotalStringVoltagefinal` > 44) and (`a`.`TotalStringVoltagefinal` <= 45)),'9',if(((`a`.`TotalStringVoltagefinal` >= 33) and (`a`.`TotalStringVoltagefinal` <= 44) and (`b`.`tienebateria` = 'N')),'0',if(((`a`.`TotalStringVoltagefinal` > 0) and (`a`.`TotalStringVoltagefinal` <= 33)),'9',if((`a`.`TotalStringVoltagefinal` <= 0),'18','')))))) + if(((`a`.`InputVoltagefinal` > 0) and (`a`.`OutputVoltagefinal` > 0) and (`a`.`OutputCurrentfinal` > 0) and (`a`.`TotalStringVoltagefinal` <> 0)),100,50)) + if((`b`.`tienebateria` = 'N'),0,100)) + if(((`a`.`TotalStringVoltagefinal` = 0) and (`a`.`resultadosnmp` = 'SNMPOK')),0,100)),0) + if((`a`.`EstadoInversor` = 1),0,if((`a`.`EstadoInversor` = 2),8,if((`a`.`EstadoInversor` = 0),9,if((`a`.`EstadoInversor` > 2),8,0))))) + if(((`a`.`temperature` >= -(30)) and (`a`.`temperature` <= 80)),'9',if(((`a`.`temperature` >= 81) and (`a`.`temperature` <= 120)),'5',if((`a`.`temperature` >= 121),'0','0')))) AS `puntaje`,`a`.`fechahora` AS `fechahora`,`a`.`resultadosnmp` AS `resultadosnmp`,`b`.`tienebateria` AS `tienebateria` from (`alertasx`.`fuentes_snmp` `a` left join `catalogos`.`db_fuentes` `b` on((replace(`a`.`macaddress`,'.','') = `b`.`mac`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `listafuentes_view`
--

/*!50001 DROP TABLE IF EXISTS `listafuentes_view`*/;
/*!50001 DROP VIEW IF EXISTS `listafuentes_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `listafuentes_view` AS (select `a`.`macaddress` AS `macaddress`,concat('snmpget -v2c -c MODEM8K_PILOTO ',`a`.`ipaddress`,' ',`b`.`InputVoltage`,' -r 1') AS `InputVoltage`,concat('snmpget -v2c -c MODEM8K_PILOTO ',`a`.`ipaddress`,' ',`b`.`OutputVoltage`,' -r 1') AS `OutputVoltage`,concat('snmpget -v2c -c MODEM8K_PILOTO ',`a`.`ipaddress`,' ',`b`.`OutputCurrent`,' -r 1') AS `OutputCurrent`,concat('snmpget -v2c -c MODEM8K_PILOTO ',`a`.`ipaddress`,' ',`b`.`TotalStringVoltage`,' -r 1') AS `TotalStringVoltage`,concat('snmpget -v2c -c MODEM8K_PILOTO ',`a`.`ipaddress`,' ',`b`.`temperature`,' -r 1') AS `temperature` from (`alertasx`.`fuentes_snmp` `a` left join `catalogos`.`oui_fuentes` `b` on(((substr(replace(`a`.`macaddress`,'.',''),1,6) = `b`.`oui_fuentes`) and (`a`.`version` = `b`.`version`)))) where (`a`.`ipaddress` not in ('-','0.0.0.0'))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-23 13:20:53
