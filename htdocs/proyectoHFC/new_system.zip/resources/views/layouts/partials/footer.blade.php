<footer class="main-footer">
    <strong>Copyright &copy; 2019 <a href="http://www.movistar1.com:9574/cmts/">Centro de Control HFC Movistar</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 0.1
    </div>
</footer>