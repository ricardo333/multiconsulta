<div class="modal fade" id="editPermisosModal" tabindex="-1" role="dialog" aria-labelledby="addPermisosModalTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-header px-2 py-1">
              <h5 class="modal-title" id="exampleModalLongTitle">Editar nuevos permisos</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body modal-height-responsive">
              <div class="row">
                <div class="col-12 errors" id="rpta_update_checked_permisos">
      
                </div>
                <div class="col-12" id="editModulosAndPermisos">
                  
                </div> 
              </div>
            </div> 
          </div>
        </div>
      </div>