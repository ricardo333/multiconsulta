<div class="modal fade" id="searchModal" tabindex="-1" role="dialog" aria-labelledby="searchModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header px-2 py-1">
          <h5 class="modal-title" id="exampleModalLongTitle">Resultados Múltiples</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body modal-height-responsive">
          <div class="row">
             <section id="multiple_result">

             </section>
          </div>
        </div> 
      </div>
    </div>
  </div>