<div class="modal fade" id="successModal" tabindex="-1" role="dialog" aria-labelledby="successModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header  p-1">
        <h5 class="modal-title" id="successModalLabel">Información</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="body-success-modal">
        ....
      </div>
      <div class="modal-footer  p-1">
        <button type="button" class="btn btn-danger w-100" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>