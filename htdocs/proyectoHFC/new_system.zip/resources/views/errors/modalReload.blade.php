<div class="modal fade" id="reloadModal" tabindex="-1" role="dialog" aria-labelledby="reloadModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header  p-1">
        <h5 class="modal-title" id="reloadModalLabel">!Error - Recargar Web!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="body-reload-modal">
        ....
      </div>
      <div class="modal-footer text-center  p-1">
        <button type="button" class="btn btn-danger  w-100" data-dismiss="modal">Aceptar</button>
      </div>
    </div>
  </div>
</div>