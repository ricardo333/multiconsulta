import errors from  "@/globalResources/errors.js"
import peticiones from './peticiones.js'

$(function(){

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

     //Busqueda Multiconsulta
     $("#form_multiconsulta #search_m").click(function(){
        
        //alert("aqui buscando");
        //active_desactive_form_search()
        buscar();
       
    })

    
    $("body").on("click",'#tablaresvarios tbody tr', function(event){
 
        event.preventDefault();  
     
     // active_desactive_form_search()
        var $td= $(this).closest('tr').children('td');  

        var macaddress= $td.eq(0).text(); 	
        console.log("el mac addres es: "+macaddress);
        $("#text_m").val(macaddress);
        $("#type_m").val(2);
        $("#searchModal").modal('hide')//oculta modal
          
        burcarPorMacAddress(2,macaddress)
         
    })
})

function buscar()
{
    let type_data = $("#form_multiconsulta #type_m").val()
    let text =  $("#form_multiconsulta #text_m").val()

    peticiones.searchCountMulticonsulta(type_data,text,function(res){
      console.log("aqui luego del callbak")
        console.log("la data return count multiconsulta es: ",res)
       
        //Errores
          if(res.error == "failed"){
             console.log("Error: ",res.errorThrown,res.jqXHR,res.textStatus) 
            $("#rpta_multiconsulta").html(`${res.jqXHR.responseText}`); 

            if(res.jqXHR.responseJSON){
              if(res.jqXHR.responseJSON.mensaje){
                  let erroresMensaje = res.jqXHR.responseJSON.mensaje  //captura objeto
                  let mensaje = errors.mensajeErrorJson(erroresMensaje)
                  $("#rpta_multiconsulta").html(mensaje)
                  
              } 
            }
            if(res.jqXHR.status){
                let mensaje = errors.codigos(res.jqXHR.status)
                $("#body-errors-modal").html(mensaje)
                $('#errorsModal').modal('show')
                
            }
            
            return false;
          }
           if(res.error == true){
            let error_rpta = ``
            data.message.forEach(el => { 
              error_rpta += `${el} <br/>`
            })
            $("#rpta_multiconsulta").html(`${error_rpta}`) 
            return false;
          }
            
        //Nulo
          let data = res.response
          if(data == null  || data.length == 0){
            $("#rpta_multiconsulta").html(`0 Clientes Encontrados`);
              return false;
          } 
    
        //DATA CORRECTA

        //validando cantidad de resultado
        let cantidadResultado = data.length
           
        if (cantidadResultado > 1) {
            console.log("cuentas con muchos resultados,saldra popup"); 
            //Armando el resultado
            peticiones.armandoMultiplesResultados(data)
         
        }else{
          console.log("llego aqui..........")
          // peticiones.imprimirMulticonsultaResult(data)
        }
 
          
      })
}

function burcarPorMacAddress(type_data,macaddress)
{ 
  peticiones.searchMulticonsultaByMacAddress(type_data,macaddress,function(res){
    console.log("aqui luego del callbak")
      console.log("la data return del macaddress: ",res)
     
      //Errores
        if(res.error == "failed"){
           console.log("Error: ",res.errorThrown,res.jqXHR,res.textStatus) 
          $("#rpta_multiconsulta").html(`${res.jqXHR.responseText}`); 

          if(res.jqXHR.responseJSON){
            if(res.jqXHR.responseJSON.mensaje){
                let erroresMensaje = res.jqXHR.responseJSON.mensaje  //captura objeto
                let mensaje = errors.mensajeErrorJson(erroresMensaje)
                $("#rpta_multiconsulta").html(mensaje)
                return false
            } 
          }
          if(res.jqXHR.status){
              let mensaje = errors.codigos(res.jqXHR.status)
              $("#body-errors-modal").html(mensaje)
              $('#errorsModal').modal('show')
              return false
          }
          
          return false;
        }
         if(res.error == true){
          let error_rpta = ``
          data.message.forEach(el => { 
            error_rpta += `${el} <br/>`
          })
          $("#rpta_multiconsulta").html(`${error_rpta}`) 
          return false;
        }
          
      //Nulo
        let data = res.response
        if(data == null  || data.length == 0){
          $("#rpta_multiconsulta").html(`0 Clientes Encontrados`);
            return false;
        } 
  
      //DATA CORRECTA
        peticiones.imprimirMulticonsultaResult(data)
        
    })

}