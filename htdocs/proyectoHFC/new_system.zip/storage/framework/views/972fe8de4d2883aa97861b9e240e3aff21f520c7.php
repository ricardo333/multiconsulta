<?php $__env->startSection('titulo_pagina_sistema', 'Dashboard'); ?>

<?php $__env->startSection('estilos'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts-header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-left-submenus'); ?>
    ##parent-placeholder-59556a1ffdff7f24b9f3c7de1ba1fed4ccb9619b## 
    <li class="nav-item d-none d-sm-inline-block">
        <a href="javascript:void(0)" class="nav-link">Home</a>
    </li>
    <li class="nav-item d-none d-sm-inline-block">
        <a href="javascript:void(0)" class="nav-link">Contact</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-container'); ?>
    
    <input type="text" id="filter_modulos" name="filter_modulos" class="form-control form-control-sm shadow-sm">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ruta-navegacion-container'); ?>
    ##parent-placeholder-6a091938c8d96c7e8c7b5c996884c2661881d145##
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside-right'); ?>
    
     
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    ##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##
    <?php if(isset($anuncio)): ?>
        <?php echo $__env->make("administrador.globals.modals.anuncioPassword", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <div class="row" id="listModulos">
        
    </div>
 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts-footer'); ?>
    <script src="<?php echo e(asset('js/sistema/administrador/index.js')); ?>"></script>
    <?php if(isset($anuncio)): ?>
        <script>
            $(function(){
                $("#anuncioPassword").modal("show")
            })
        </script>
    <?php endif; ?>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\new_system\resources\views/administrador/index.blade.php ENDPATH**/ ?>