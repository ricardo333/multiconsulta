
<!DOCTYPE html>
<html  lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">

   <!-- CSRF Token -->
   <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
   <title><?php echo e(config('app.name', 'Sistema')); ?> | <?php echo $__env->yieldContent('titulo_pagina_sistema'); ?> | <?php echo e(Config::get('session.lifetime')); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href=" <?php echo e(mix('css/app.css')); ?>" rel="stylesheet">
  <!-- Font Awesome -->  
  <link rel="stylesheet" href="<?php echo e(asset('css/icofont.min.css')); ?>"> 

  <?php echo $__env->yieldContent('estilos'); ?>
  <?php echo $__env->yieldContent('scripts-header'); ?>

</head>
    <body class="hold-transition sidebar-mini" >
        <div class="wrapper">

            <?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <?php echo $__env->make('layouts.partials.aside-left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                    <div class="col-sm-6">
                        <?php echo $__env->yieldContent('title-container'); ?>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <?php $__env->startSection('ruta-navegacion-container'); ?> 
                                <li class="breadcrumb-item"><a href="<?php echo e(route('administrador')); ?>">Dashboard</a></li>
                            <?php echo $__env->yieldSection(); ?>
                        
                        </ol>
                    </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
                </div>
                <!-- /.content-header -->

                <!-- Main content -->
                <section class="content" id="app">
                <div class="container-fluid"> 
                    <?php $__env->startSection('content'); ?>
                        <!-- Modales -->
                        <?php echo $__env->make("errors.modalErrors", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make("errors.modalReload", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make("success.successModal", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                      <!-- Fin modales-->
                    <?php echo $__env->yieldSection(); ?>
                </div>
                </section>
                <!-- /.content -->
            </div>
            <!-- /.content-wrapper -->
            <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Control Sidebar -->
            <aside class="control-sidebar control-sidebar-light">
                <?php echo $__env->yieldContent('aside-right'); ?>
            </aside>
            <!-- /.control-sidebar -->
        
        
        </div>
        <!-- ./wrapper -->
    
        <script src="<?php echo e(mix('js/app.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts-footer'); ?>

    </body>
</html>
<?php /**PATH C:\laragon\www\new_system\resources\views/layouts/master.blade.php ENDPATH**/ ?>