<?php $__env->startSection('titulo_pagina_sistema', 'Multiconsulta'); ?>
 
<?php $__env->startSection('estilos'); ?>
    <link rel="stylesheet" href="<?php echo e(url('/css/modulos/multiconsulta.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts-header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-left-submenus'); ?>
    ##parent-placeholder-59556a1ffdff7f24b9f3c7de1ba1fed4ccb9619b##
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-container'); ?>
     <h4 class="m-0 text-dark text-uppercase">Multiconsulta</h4> 
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ruta-navegacion-container'); ?>
    ##parent-placeholder-6a091938c8d96c7e8c7b5c996884c2661881d145##
     <li class="breadcrumb-item active">Multiconsulta</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside-right'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    ##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##

    <?php echo $__env->make('administrador.modulos.multiconsulta.partials.searchModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    <div class="row">
        <section class="col-12 row d-flex justify-content-center" id="multiconsulta_search">
            <div class="col-10 content-form-multi">
              <article id="form_multiconsulta">
                <div class="form-group">
                   <div class="input-group">
                       <div class="input-group-btn">
                           <select name="type_m" id="type_m" class="form-control form-control-sm shadow-sm">
                             
                             <option value="1">Cod Cliente CMS</option>
                             <option value="2">Mac Address</option>
                             <option value="3">Telefono TFA/CEL</option>
                             <option value="4">Telefono HFC</option>
                           </select>    
                       </div>
                     <input type="text" id="text_m" name="text_m" class="form-control form-control-sm shadow-sm">
                     <span class="input-group-btn">
                       <a href="javascript: void(0)" id="search_m" class="btn btn-sm btn-light shadow-sm">Buscar</a>
                     </span>
                   </div>
                </div>
              </article>
            </div>
       </section>
       <section class="col-12 row d-flex justify-content-center align-items-center flex-wrap flex-column" id="rpta_multiconsulta">
           
       </section>
    </div>

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts-footer'); ?>  
    <script src="<?php echo e(url('/js/sistema/modulos/multiconsulta/index.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\new_system\resources\views/administrador/modulos/multiconsulta/index.blade.php ENDPATH**/ ?>