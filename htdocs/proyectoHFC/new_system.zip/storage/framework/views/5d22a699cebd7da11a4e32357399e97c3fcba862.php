<?php $usDetalle = $usuario->getData()->response->data; ?> 

<?php $__env->startSection('titulo_pagina_sistema', 'Perfil'); ?>

<?php $__env->startSection('estilos'); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts-header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-left-submenus'); ?>
    ##parent-placeholder-59556a1ffdff7f24b9f3c7de1ba1fed4ccb9619b##
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-container'); ?>

     <h4 class="m-0 text-dark text-uppercase">Perfil <?php echo e($usDetalle->usuario); ?></h4> 
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ruta-navegacion-container'); ?>
    ##parent-placeholder-6a091938c8d96c7e8c7b5c996884c2661881d145##
    <li class="breadcrumb-item active">Perfil</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside-right'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    ##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##
   
    <div class="row">
        <div class="col-12">
                <div class="card">
                    <div class="card-header px-2 py-1">
                        <a href="<?php echo e(route('administrador')); ?>" class="btn btn-sm btn-outline-success mx-1 shadow-sm"><i class="fa fa-arrow-left"></i> Atras</a>
                    </div> 
                    <div class="card-body">
                        
                        <ul class="nav nav-tabs" id="perfil" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="detalle-perfil" data-toggle="tab" href="#detalleP" role="tab" aria-controls="detalleP" aria-selected="true">Detalle</a>
                            </li>
                            <?php if( ($usDetalle->identificador == Auth()->user()->id ) || Auth()->user()->tienePermisoEspecial()): ?>
                                <li class="nav-item">
                                    <a class="nav-link" id="edit-perfil" data-toggle="tab" href="#editP" role="tab" aria-controls="editP" aria-selected="false">Actualizar Datos</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="password-perfil" data-toggle="tab" href="#passwordP" role="tab" aria-controls="passwordP" aria-selected="false">Cambiar Contraseña</a>
                                </li>
                            <?php endif; ?>
                           
                            
                        </ul>
                        <div class="tab-content" id="perfilContent">
                            <div class="tab-pane fade show active" id="detalleP" role="tabpanel" aria-labelledby="detalle-perfil">
                                <div class="card-body">
                                    <section class="form row my-2 mx-0">
                                            
                
                                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                                <label for="nombreDetalle" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Nombre: </label>
                                                <div class="col-sm-7 col-md-8 form-control form-control-sm"><?php echo e($usDetalle->nombre); ?></div>
                                            </div>
                                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                                    <label for="apellidosDetalle" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Apellidos: </label>
                                                    <div class="col-sm-7 col-md-8 form-control form-control-sm"><?php echo e($usDetalle->apellidos); ?></div>
                                            </div>
                                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                                    <label for="documentoDetalle" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">DNI: </label>
                                                    <div class="col-sm-7 col-md-8 form-control form-control-sm"><?php echo e($usDetalle->documento); ?></div>
                                            </div>
                                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                                    <label for="celularDetalle" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Celular: </label>
                                                    <div class="col-sm-7 col-md-8 form-control form-control-sm"><?php echo e($usDetalle->celular); ?></div>
                                            </div>
                                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                                    <label for="correoDetalle" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Correo: </label>
                                                    <div class="col-sm-7 col-md-8 form-control form-control-sm"><?php echo e($usDetalle->correo); ?></div>
                                            </div>
                 
                                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                                    <label for="empresaDetalle" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Empresa: </label>
                                                    <div class="col-sm-7 col-md-8 form-control form-control-sm"><?php echo e($usDetalle->empresa); ?></div>
                                            </div>
                                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                                    <label for="rolDetalle" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Rol: </label>
                                                    <div class="col-sm-7 col-md-8 form-control form-control-sm"><?php echo e($usDetalle->rol); ?></div>
                                            </div> 
                
                                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                                    <label for="usuarioDetalle" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Usuario: </label>
                                                    <div class="col-sm-7 col-md-8 form-control form-control-sm"><?php echo e($usDetalle->usuario); ?></div>
                                            </div>

                                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                                    <label for="accesoUltimoDetalle" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Último acceso: </label>
                                                    <div class="col-sm-7 col-md-8 form-control form-control-sm"><?php echo e($ultimoAcceso); ?></div>
                                            </div>
                                              
                                    </section>
                                </div>
                            </div>
                            <?php if( ($usDetalle->identificador == Auth()->user()->id ) || Auth()->user()->tienePermisoEspecial()): ?>
                                <div class="tab-pane fade" id="editP" role="tabpanel" aria-labelledby="edit-perfil">
                                    <div class="card-body">
                                        <div id="form_update_load"></div>
                                        <section class="form row my-2 mx-0" id="form_update_detail"> 
                                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                                    <label for="nombreUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Nombre: </label>
                                                    <div class="col-sm-7 col-md-8 form-control form-control-sm text-black-50"><?php echo e($usDetalle->nombre); ?></div>
                                                    <input type="hidden" name="idUpdate" id="idUpdate" value="<?php echo e($usDetalle->identificador); ?>" class="col-sm-7 col-md-8 form-control form-control-sm shadow-sm">
                                            </div>
                                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                                    <label for="apellidosUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Apellidos: </label>
                                                    <div class="col-sm-7 col-md-8 form-control form-control-sm text-black-50"><?php echo e($usDetalle->apellidos); ?></div>
                                            </div>
                                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                                    <label for="documentoUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">DNI: </label>
                                                    <input type="text" name="documentoUpdate" id="documentoUpdate" value="<?php echo e($usDetalle->documento); ?>" class="col-sm-7  col-md-8 form-control form-control-sm shadow-sm validateText">
                                            </div>
                                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                                    <label for="celularUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Celular: </label>
                                                    <input type="text" name="celularUpdate" id="celularUpdate" value="<?php echo e($usDetalle->celular); ?>" class="col-sm-7  col-md-8 form-control form-control-sm shadow-sm validateText">
                                            </div>
                                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                                    <label for="correoUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Correo: </label>
                                                    <input type="text" name="correoUpdate" id="correoUpdate" value="<?php echo e($usDetalle->correo); ?>" class="col-sm-7  col-md-8 form-control form-control-sm shadow-sm validateText">
                                            </div>
                     
                                            <div class="form-group row justify-content-center mx-0 px-2 col-12 errors_message" id="errors_update">
                                                
                                            </div>
                                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center">
                                                <a href="javascript:void(0)" class="btn btn-sm btn-outline-primary shadow-sm" id="actualizarPerfil">Actualizar</a>
                                            </div>
                                            
                                        </section>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="passwordP" role="tabpanel" aria-labelledby="password-perfil">
                                   <div class="card-body">
                                       <div id="form_updatePassword_load"></div>
                                       <section class="row justify-content-center" id="form_updatePassword_detail">
                                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-8 col-lg-8 ">
                                                <label for="usuarioUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Usuario: </label>
                                                <div class="col-sm-7 col-md-8 font-weight-bold form-control form-control-sm text-black-50"><?php echo e($usDetalle->usuario); ?></div>
                                            </div>
                                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-8 col-lg-8 ">
                                                <label for="claveUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Nueva contraseña: </label>    
                                                <div class="input-group col-sm-7  col-md-8 p-0">  
                                                    <input type="password" name="claveUpdate" id="claveUpdate" class="form-control form-control-sm shadow-sm validateText">
                                                    <span class="input-group-btn">
                                                        <a href="javascript: void(0)" id="verPasswordUser" class="btn btn-outline-success btn-sm shadow-sm w-100" ><i class="fa fa-eye" aria-hidden="true"></i></a>
                                                    </span>
                                                </div>  
                                            </div>
                                            <div class="form-group row justify-content-center mx-0 px-2 col-12 errors_message" id="errors_update_password">
                                            </div>
        
                                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center">
                                                <a href="javascript:void(0)" class="btn btn-sm btn-outline-success shadow-sm" id="actualizarPassword">Actualizar Contraseña</a>
                                            </div>
                                            <div class="col-md-12 small-box">
                                                <span class="d-block small font-weight-bold text-primary">
                                                    Recuerde tener en cuenta el siguiente formato:  
                                                </span>
                                                    <ul class="small text-secondary" id="display_politica_password">
                                                        <li class="items">longitud mínima de 8 caracteres.</li>
                                                        <li class="items">Contar con almenos una letra mayuscula y minuscula.</li>
                                                        <li class="items">Contar con almenos un numero.</li>
                                                        <li class="items">Contar con un caracter especial. Ejemplo: #?!@$%^&amp;*-</li>
                                                    </ul>
                                                
                                            </div>
                                       </section> 
                                   </div>
                                </div>
                            <?php endif; ?>
                            
                        </div>
                        
                    </div>
                </div>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts-footer'); ?>  

    <?php if(($usDetalle->identificador == Auth()->user()->id ) || Auth()->user()->tienePermisoEspecial()): ?>
        <script src="<?php echo e(asset('js/sistema/perfil/perfil.min.js')); ?>"></script>
    <?php endif; ?>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\new_system\resources\views/administrador/perfil/usuario/detalle.blade.php ENDPATH**/ ?>