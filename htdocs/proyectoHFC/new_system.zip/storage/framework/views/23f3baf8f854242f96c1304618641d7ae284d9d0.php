<?php $__env->startSection('titulo_pagina_sistema', 'Roles - Creación'); ?>

<?php $__env->startSection('estilos'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts-header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-left-submenus'); ?>
    ##parent-placeholder-59556a1ffdff7f24b9f3c7de1ba1fed4ccb9619b##
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-container'); ?>
     <h4 class="m-0 text-dark text-uppercase">Creación de Roles</h4> 
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ruta-navegacion-container'); ?>
    ##parent-placeholder-6a091938c8d96c7e8c7b5c996884c2661881d145##
     <li class="breadcrumb-item active"><a href="<?php echo e(route('modulo.rol.index')); ?>"> Roles </a> </li>
     <li class="breadcrumb-item active">Creación</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside-right'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    ##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##
    
    <div class="row">
        <div class="col-12">
                <div class="card">
                    <div class="card-header px-2 py-1">
                        <a href="<?php echo e(route('modulo.rol.index')); ?>" class="btn btn-sm btn-outline-success shadow-sm mx-1"><i class="fa fa-arrow-left"></i> Atras</a>
                    </div> 

                    <div class="card-body px-2 py-1"> 
                            <section id="form_store_load"></section>
                            <section class="form row my-2 mx-0" id="form_store_detail">
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="nombreStore" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Nombre: </label>
                                    <input type="text" name="nombreStore" id="nombreStore" class="col-sm-7 col-md-8 form-control form-control-sm shadow-sm text-uppercase validateText">
                              </div>
                            <?php if(Auth::user()->tienePermisoEspecial()): ?>
                                <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="especialStore" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Acceso Total: </label>
                                    <select name="especialStore" id="especialStore" class="col-sm-7  col-md-8 form-control form-control-sm shadow-sm validateSelect">
                                        <option value="NO" selected>NO</option>
                                        <option value="SI">SI</option>
                                    </select>
                                </div>
                                <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="referenciaStore" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Rol Padre: </label>
                                    <select name="referenciaStore" id="referenciaStore" class="col-sm-7  col-md-8 form-control form-control-sm shadow-sm validateSelect">
                                            <option value="">SIN REFERENCIA</option>
                                        <?php $__empty_1 = true; $__currentLoopData = $rolesDisponibles->getData()->response->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <option value="<?php echo e($rol->identificador); ?>"><?php echo e($rol->rol); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            
                                        <?php endif; ?>
                                        
                                    </select>
                                </div>
                            <?php endif; ?>

                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-12 col-lg-12">
                                    <label for="referenciaStore" class="col-form-label col-form-label-sm mb-0 px-0">Permisos del nuevo Rol: </label>
                                    <div class="col-12 p-0 errors" id="rpta_store_checked_permisos">

                                    </div>
                                    <div class="col-12 p-0" id="storeModulosAndPermisosList">
                                        
                                    </div> 
                            </div> 
                               
 
                              <div class="form-group row justify-content-center mx-0 px-2 col-12 errors_message" id="errors_store">
                                    
                              </div>

                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center">
                                   <a href="javascript:void(0)" class="btn btn-sm btn-outline-primary shadow-sm" id="crearRol">Crear Rol</a>
                              </div>
                              
                            </section>
                    </div>
                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts-footer'); ?>  
    <?php
        $lista_modulos = $modulos->getData();
        $lista_permisos_rol = $permisosRol->getData(); 
    ?>
    <script>
        var MODULOS = <?php echo json_encode($lista_modulos); ?>;
        var PERMISOS_ROL = <?php echo json_encode($lista_permisos_rol); ?>; 
        const MODULOS_AUTH = MODULOS
        const PERMISOS_ROL_AUTH = PERMISOS_ROL
    </script>

    <script src="<?php echo e(asset('js/sistema/modulos/roles/store.min.js')); ?>"></script>
    
    <?php if(Auth::user()->tienePermisoEspecial()): ?>
        <script src="<?php echo e(asset('js/sistema/modulos/roles/store-admin.min.js')); ?>"></script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\new_system\resources\views/administrador/modulos/rol/create.blade.php ENDPATH**/ ?>