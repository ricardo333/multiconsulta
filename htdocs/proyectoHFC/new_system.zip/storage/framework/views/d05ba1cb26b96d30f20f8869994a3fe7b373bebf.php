<?php $__env->startSection('titulo_pagina_sistema', 'Usuarios - Creación'); ?>

<?php $__env->startSection('estilos'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts-header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-left-submenus'); ?>
    ##parent-placeholder-59556a1ffdff7f24b9f3c7de1ba1fed4ccb9619b##
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-container'); ?>
     <h4 class="m-0 text-dark text-uppercase">Creación de Usuario</h4> 
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ruta-navegacion-container'); ?>
    ##parent-placeholder-6a091938c8d96c7e8c7b5c996884c2661881d145##
     <li class="breadcrumb-item active"><a href="<?php echo e(route('modulo.usuario.index')); ?>"> Usuarios </a> </li>
     <li class="breadcrumb-item active">Creación</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside-right'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    ##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##
    <?php echo $__env->make("administrador.modulos.user.partials.addPermisosModal", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
    <div class="row">
        <div class="col-12">
                <div class="card">
                    <div class="card-header px-2 py-1">
                        <a href="<?php echo e(route('modulo.usuario.index')); ?>" class="btn btn-sm btn-outline-success shadow-sm mx-1"><i class="fa fa-arrow-left"></i> Atras</a>
                    </div> 

                    <div class="card-body px-2 py-1"> 
                            <section id="form_store_load"></section>
                          <section class="form row my-2 mx-0" id="form_store_detail">
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="nombreStore" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Nombre: </label>
                                    <input type="text" name="nombreStore" id="nombreStore" class="col-sm-7 col-md-8 form-control form-control-sm shadow-sm validateText">
                              </div>
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="apellidosStore" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Apellidos: </label>
                                    <input type="text" name="apellidosStore" id="apellidosStore" class="col-sm-7  col-md-8 form-control form-control-sm shadow-sm validateText">
                              </div>
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="documentoStore" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">DNI: </label>
                                    <input type="text" name="documentoStore" id="documentoStore" class="col-sm-7  col-md-8 form-control form-control-sm shadow-sm validateText">
                              </div>
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="celularStore" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Celular: </label>
                                    <input type="text" name="celularStore" id="celularStore" class="col-sm-7  col-md-8 form-control form-control-sm shadow-sm validateText">
                              </div>
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="correoStore" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Correo: </label>
                                    <input type="text" name="correoStore" id="correoStore" class="col-sm-7  col-md-8 form-control form-control-sm shadow-sm validateText">
                              </div>
  
                               
                               <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="empresaStore" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Empresa: </label>
                                    <?php
                                       $lista_empresa = $empresas->getData();
                                       $data_empresa = $lista_empresa->response->data;
                                    ?>
                                    <select name="empresaStore" id="empresaStore" class="col-sm-7  col-md-8 form-control form-control-sm shadow-sm validateSelect">
                                            <option value="seleccionar">Seleccionar</option>
                                        <?php $__currentLoopData = $data_empresa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($empresa->identificador); ?>"><?php echo e($empresa->empresa); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                              </div>
                               <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="rolStore" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Rol: </label>
                                    <?php
                                        $lista_roles = $roles->getData();
                                        $data_rol = $lista_roles->response->data;
                                    ?>
                                    <select name="rolStore" id="rolStore" class="col-sm-6  col-md-8 form-control form-control-sm shadow-sm validateSelect">
                                        <option value="seleccionar">Seleccionar</option>
                                        <?php $__currentLoopData = $data_rol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($rol->identificador); ?>"><?php echo e($rol->rol); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>  
                              </div> 

                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6">
                                    <div class="input-group">  
                                            <label for="permisosUsuarioStore" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Permisos: </label>
                                        <span class="input-group-btn col-sm-6  col-md-8 p-0">
                                            <a href="javascript: void(0)" id="activarModalPermisos" class="btn btn-outline-success btn-sm shadow-sm w-100" >Agregar nuevos permisos <i class="fa fa-plus"></i></a>
                                        </span>
                                    </div> 
                              </div> 
   
                               
                              <div class="form-group row justify-content-center mx-0 px-2 col-12 errors_message" id="errors_store">
                                    
                              </div>

                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center">
                                   <a href="javascript:void(0)" class="btn btn-sm btn-outline-primary shadow-sm" id="crearUsuario">Crear Usuario</a>
                              </div>
                              
                            </section>
                    </div>
                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts-footer'); ?> 
    <?php
        $lista_modulos = $modulos->getData();
        $lista_permisos_rol = $permisosRol->getData();
        $lista_permisos_especiales = $permisosEspeciales->getData();
    ?>
    <script>
        const MODULOS = <?php echo json_encode($lista_modulos); ?>;
        const PERMISOS_ROL = <?php echo json_encode($lista_permisos_rol); ?>;
        const PERMISOS_ESPECIALES = <?php echo json_encode($lista_permisos_especiales); ?>;
    </script>
    <script src="<?php echo e(asset('js/sistema/modulos/users/store.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\new_system\resources\views/administrador/modulos/user/create.blade.php ENDPATH**/ ?>