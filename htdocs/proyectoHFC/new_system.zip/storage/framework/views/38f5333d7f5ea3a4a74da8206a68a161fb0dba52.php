<?php $__env->startSection('titulo_pagina_sistema', 'Usuarios - Detalle'); ?>

<?php $__env->startSection('estilos'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts-header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-left-submenus'); ?>
    ##parent-placeholder-59556a1ffdff7f24b9f3c7de1ba1fed4ccb9619b##
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-container'); ?>
     <h4 class="m-0 text-dark text-uppercase">Detalle de Usuario</h4> 
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ruta-navegacion-container'); ?>
    ##parent-placeholder-6a091938c8d96c7e8c7b5c996884c2661881d145##
     <li class="breadcrumb-item active"><a href="<?php echo e(route('modulo.usuario.index')); ?>"> Usuarios </a> </li>
     <li class="breadcrumb-item active">Detalle</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside-right'); ?>
    
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
    ##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##
    
  
    <div class="row">
        <div class="col-12">
                <div class="card">
                    <div class="card-header px-2 py-1">
                        <a href="<?php echo e(route('modulo.usuario.index')); ?>" class="btn btn-sm btn-outline-success mx-1"><i class="fa fa-arrow-left"></i> Atras</a>
                    </div> 
                    <div class="card-body px-2 py-1"> 
                        <section class="form row my-2 mx-0">
                               <?php $usDetalle = $usuario->getData(); ?> 
 
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="nombreUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Nombre: </label>
                                    <?php echo e($usDetalle->response->data->nombre); ?>

                              </div>
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="apellidosUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Apellidos: </label>
                                    <?php echo e($usDetalle->response->data->apellidos); ?>

                              </div>
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="documentoUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">DNI: </label>
                                    <?php echo e($usDetalle->response->data->documento); ?>

                              </div>
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="celularUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Celular: </label>
                                    <?php echo e($usDetalle->response->data->celular); ?>

                              </div>
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="correoUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Correo: </label>
                                    <?php echo e($usDetalle->response->data->correo); ?>

                              </div>

                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="estadoUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Estado: </label>
                                    <?php echo e($usDetalle->response->data->estado == "A" ? "Activo" : "Inactivo"); ?>

                              </div>
                               
                               <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="empresaUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Empresa: </label>
                                     <?php echo e($usDetalle->response->data->empresa); ?>

                              </div>
                               <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="rolUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Rol: </label>
                                    <?php echo e($usDetalle->response->data->rol); ?> 
                              </div> 

                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="usuarioUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Usuario: </label>
                                    <?php echo e($usDetalle->response->data->usuario); ?>

                              </div>
                              <div class="form-group row mx-0 px-2 col-12">
                                    <label for="permisosUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Permisos: </label>
                                    <section class="col-12 card">
                                         <div class="card-body">
                                                <?php $permisosGenerales = $permisos->getData()->response->data;?> 
                                                <?php $__empty_1 = true; $__currentLoopData = $permisosGenerales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <span class="items_permisos_details"><?php echo e($permiso->descripcion); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                      
                                                <?php endif; ?>
                                         </div>
                                    </section>   
                                    
                              </div>
                                
                              <?php if(Auth::user()->HasPermiso('submodulo.usuario.edit')): ?>
                                    <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center">
                                          <a href="<?php echo e(route('submodulo.usuario.edit', $usDetalle->response->data->identificador)); ?>" class="btn btn-outline-success btn-sm shadow-sm p-1 accionUsuarioEdit" >Editar<i class="fa fa-pencil icon-accion"></i></a>
                                    </div>
                                <?php endif; ?>
                              
                              
                        </section>
                    </div>
                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts-footer'); ?> 
        <script src="<?php echo e(asset('js/sistema/modulos/users/show.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\new_system\resources\views/administrador/modulos/user/detalle.blade.php ENDPATH**/ ?>