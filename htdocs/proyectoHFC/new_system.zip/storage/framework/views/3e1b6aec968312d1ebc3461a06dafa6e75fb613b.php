<?php $__env->startSection('titulo_pagina_sistema', 'Usuarios - Edición'); ?>

<?php $__env->startSection('estilos'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts-header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-left-submenus'); ?>
    ##parent-placeholder-59556a1ffdff7f24b9f3c7de1ba1fed4ccb9619b##
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-container'); ?>
     <h4 class="m-0 text-dark text-uppercase">Edición de Usuario</h4> 
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ruta-navegacion-container'); ?>
    ##parent-placeholder-6a091938c8d96c7e8c7b5c996884c2661881d145##
     <li class="breadcrumb-item active"><a href="<?php echo e(route('modulo.usuario.index')); ?>"> Usuarios </a> </li>
     <li class="breadcrumb-item active">Edición</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside-right'); ?>
    
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
    ##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##
    <?php echo $__env->make("administrador.modulos.user.partials.editPermisosModal", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
    <div class="row">
        <div class="col-12">
                <div class="card">
                    <div class="card-header px-2 py-1">
                        <a href="<?php echo e(route('modulo.usuario.index')); ?>" class="btn btn-sm btn-outline-success shadow-sm mx-1"><i class="fa fa-arrow-left"></i> Atras</a>
                    </div> 
                    <div class="card-body px-2 py-1"> 
                        <div id="form_update_load"></div>
                        <section class="form row my-2 mx-0" id="form_update_detail">
                               <?php $usDetalle = $usuario->getData(); ?> 
 
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="nombreUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Nombre: </label>
                                    <input type="text" name="nombreUpdate" id="nombreUpdate" value="<?php echo e($usDetalle->response->data->nombre); ?>" class="col-sm-7 col-md-8 form-control form-control-sm shadow-sm validateText">
                                    <input type="hidden" name="idUpdate" id="idUpdate" value="<?php echo e($usDetalle->response->data->identificador); ?>" class="col-sm-7 col-md-8 form-control form-control-sm shadow-sm">
                              </div>
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="apellidosUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Apellidos: </label>
                                    <input type="text" name="apellidosUpdate" id="apellidosUpdate" value="<?php echo e($usDetalle->response->data->apellidos); ?>" class="col-sm-7  col-md-8 form-control form-control-sm shadow-sm validateText">
                              </div>
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="documentoUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">DNI: </label>
                                    <input type="text" name="documentoUpdate" id="documentoUpdate" value="<?php echo e($usDetalle->response->data->documento); ?>" class="col-sm-7  col-md-8 form-control form-control-sm shadow-sm validateText">
                              </div>
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="celularUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Celular: </label>
                                    <input type="text" name="celularUpdate" id="celularUpdate" value="<?php echo e($usDetalle->response->data->celular); ?>" class="col-sm-7  col-md-8 form-control form-control-sm shadow-sm validateText">
                              </div>
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="correoUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Correo: </label>
                                    <input type="text" name="correoUpdate" id="correoUpdate" value="<?php echo e($usDetalle->response->data->correo); ?>" class="col-sm-7  col-md-8 form-control form-control-sm shadow-sm validateText">
                              </div>

                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="estadoUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Estado: </label>
                                    <select name="estadoUpdate" id="estadoUpdate" class="col-sm-7  col-md-8 form-control form-control-sm shadow-sm">
                                        <option value="A" <?php echo e(($usDetalle->response->data->estado) == "A" ? 'selected' : ''); ?>>Activo</option>
                                        <option value="I" <?php echo e(($usDetalle->response->data->estado) == "I" ? 'selected' : ''); ?>>Inactivo</option>
                                    </select> 
                              </div>
                               
                               <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="empresaUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Empresa: </label>
                                    <?php
                                       $lista_empresa = $empresas->getData();
                                       $data_empresa = $lista_empresa->response->data;
                                    ?>
                                    <select name="empresaUpdate" id="empresaUpdate" class="col-sm-7  col-md-8 form-control form-control-sm shadow-sm validateSelect">
                                            <option value="seleccionar">Seleccionar</option>
                                        <?php $__currentLoopData = $data_empresa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($empresa->identificador); ?>" 
                                                <?php echo e(($empresa->identificador == $usDetalle->response->data->idenfiticadorEmpresa) ? 'selected' : ''); ?> >
                                                <?php echo e($empresa->empresa); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                              </div>
                               <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="rolUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Rol: </label>
                                    <?php
                                        $lista_roles = $roles->getData();
                                        $data_rol = $lista_roles->response->data;
                                    ?>
                                    <select name="rolUpdate" id="rolUpdate" class="col-sm-6  col-md-8 form-control form-control-sm shadow-sm validateSelect">
                                        <option value="seleccionar">Seleccionar</option>
                                        <?php $__currentLoopData = $data_rol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($rol->identificador); ?>" 
                                                    <?php echo e(($rol->identificador == $usDetalle->response->data->identificadorRol) ? 'selected' : ''); ?>>
                                                    <?php echo e($rol->rol); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>  
                              </div> 

                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="usuarioUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Usuario: </label>
                                    <div class="col-sm-7 col-md-8 font-weight-bold p-0"><?php echo e($usDetalle->response->data->usuario); ?></div>
                              </div>
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="claveUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Contraseña: </label>    
                                    <div class="input-group col-sm-7  col-md-8 p-0">  
                                        <input type="password" name="claveUpdate" id="claveUpdate" class="form-control form-control-sm shadow-sm validateText">
                                        <span class="input-group-btn">
                                            <a href="javascript: void(0)" id="verPasswordUser" class="btn btn-outline-success btn-sm shadow-sm w-100" ><i class="fa fa-eye" aria-hidden="true"></i></a>
                                        </span>
                                    </div> 
                                   
                                    
                              </div>
                              
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6">
                                    <div class="input-group">  
                                            <label for="permisosUsuarioUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Permisos: </label>
                                        <span class="input-group-btn col-sm-6  col-md-8 p-0">
                                            <a href="javascript: void(0)" id="verPermisosUsuario" class="btn btn-outline-success btn-sm shadow-sm w-100" >Agregar nuevos permisos <i class="fa fa-plus"></i></a>
                                        </span>
                                    </div> 
                              </div> 
    
                            <div class="form-group row justify-content-center mx-0 px-2 col-12 errors_message" id="errors_Update">
                                
                            </div>
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center">
                                   <a href="javascript:void(0)" class="btn btn-sm btn-outline-primary shadow-sm" id="actualizarUsuario">Actualizar Usuario</a>
                              </div>
                              
                        </section>
                    </div>
                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts-footer'); ?>
    <?php
        $lista_modulos = $modulos->getData();
        $lista_permisos_rol = $permisosRol->getData();
        $lista_permisos_especiales = $permisosEspeciales->getData();
        $lista_permisos_checked_rol = $permisosCheckedRol->getData();
        $lista_permisos_checked_user = $permisosCheckedUser->getData();
    ?>
    <script>
        const MODULOS = <?php echo json_encode($lista_modulos); ?>;
        const PERMISOS_ROL = <?php echo json_encode($lista_permisos_rol); ?>;
        const PERMISOS_ESPECIALES = <?php echo json_encode($lista_permisos_especiales); ?>;
        const PERMISOS_CHECKED_ROL = <?php echo json_encode($lista_permisos_checked_rol); ?>;
        const PERMISOS_CHECKED_USER = <?php echo json_encode($lista_permisos_checked_user); ?>;
        
    </script>
    <?php if(Auth::user()->HasPermiso('submodulo.usuario.edit')): ?>
        <script src="<?php echo e(asset('js/sistema/modulos/users/edit.min.js')); ?>"></script>
    <?php endif; ?>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\new_system\resources\views/administrador/modulos/user/edit.blade.php ENDPATH**/ ?>