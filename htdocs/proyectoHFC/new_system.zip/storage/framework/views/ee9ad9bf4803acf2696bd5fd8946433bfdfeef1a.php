<?php $__env->startSection('titulo_pagina_sistema', 'Empresa'); ?>

<?php $__env->startSection('estilos'); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts-header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-left-submenus'); ?>
    ##parent-placeholder-59556a1ffdff7f24b9f3c7de1ba1fed4ccb9619b##
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-container'); ?>
     <h4 class="m-0 text-dark text-uppercase">Empresas</h4> 
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ruta-navegacion-container'); ?>
    ##parent-placeholder-6a091938c8d96c7e8c7b5c996884c2661881d145##
     <li class="breadcrumb-item active">Empresas</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside-right'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    ##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##
   
    <div class="row">
        <div class="col-12">
                <div class="card">
                    <div class="card-header px-2 py-1">
                        <a href="<?php echo e(route('administrador')); ?>" class="btn btn-sm btn-outline-success mx-1 shadow-sm"><i class="fa fa-arrow-left"></i> Atras</a>
                        <?php if(Auth::user()->HasPermiso('submodulo.empresa.store')): ?>
                            <a href="<?php echo e(route('submodulo.empresa.store')); ?>" class="btn btn-sm btn-outline-primary shadow-sm mx-1" id="activeModalRoleStore">Crear <i class="fa fa-plus-square" aria-hidden="true"></i> </a>
                        <?php endif; ?>
                        
                    </div> 
                    <div class="card-body">
                        <section class="content_table_list">
                            <table id="listEmpresasPrint" class="table table-hover table-bordered w-100 tableFixHead">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Nombre</th>
                                        <?php if(  Auth::user()->HasPermiso('submodulo.empresa.show') || 
                                              Auth::user()->HasPermiso('submodulo.empresa.edit')  ||
                                              Auth::user()->HasPermiso('submodulo.empresa.delete')
                                            ): ?>
                                          <th>Acciones</th>
                                        <?php endif; ?>
                                        
                                    </tr>
                                </thead>
                            </table>
                        </section>
                    </div>
                </div>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts-footer'); ?>  
    <script src="<?php echo e(asset('js/sistema/modulos/empresas/index.min.js')); ?>"></script>
    <?php if(Auth::user()->HasPermiso('submodulo.empresa.delete')): ?>
     <script src="<?php echo e(asset('js/sistema/modulos/empresas/delete.min.js')); ?>"></script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\new_system\resources\views/administrador/modulos/empresa/index.blade.php ENDPATH**/ ?>