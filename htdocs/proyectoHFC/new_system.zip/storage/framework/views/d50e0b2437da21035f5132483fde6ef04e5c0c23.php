<?php $__env->startSection('estilos'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts-header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-left-submenus'); ?>
    <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
    </li>
    <li class="nav-item d-none d-sm-inline-block">
        <a href="javascript:void(0)" class="nav-link">Home</a>
    </li>
    <li class="nav-item d-none d-sm-inline-block">
        <a href="javascript:void(0)" class="nav-link">Contact</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-container'); ?>
    <h3 class="m-0 text-dark">Dashboard</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ruta-navegacion-container'); ?>
    ##parent-placeholder-6a091938c8d96c7e8c7b5c996884c2661881d145##
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside-right'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
                <div class="card">
                    <div class="card-header">Dashboard</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        Bienvenido al Sistema!!
                    </div>
                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts-footer'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\new_system\resources\views/home.blade.php ENDPATH**/ ?>