
<!DOCTYPE html>
<html  lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">

   <!-- CSRF Token -->
   <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

   <title><?php echo e(config('app.name', '403')); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
</head>
    <body class="hold-transition sidebar-mini" >
          <h1>Permisos - <?php echo e($mensaje); ?></h1>
    </body>
</html>
<?php /**PATH C:\laragon\www\new_system\resources\views/errors/403.blade.php ENDPATH**/ ?>