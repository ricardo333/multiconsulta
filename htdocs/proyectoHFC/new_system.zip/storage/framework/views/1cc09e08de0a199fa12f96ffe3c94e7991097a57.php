<?php $__env->startSection('titulo_pagina_sistema', 'Seguridad'); ?>

<?php $__env->startSection('estilos'); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts-header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-left-submenus'); ?>
    ##parent-placeholder-59556a1ffdff7f24b9f3c7de1ba1fed4ccb9619b##
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-container'); ?>
     <h4 class="m-0 text-dark text-uppercase">Seguridad</h4> 
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ruta-navegacion-container'); ?>
    ##parent-placeholder-6a091938c8d96c7e8c7b5c996884c2661881d145##
     <li class="breadcrumb-item active">Seguridad</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside-right'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    ##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##
   
    <div class="row">
        <div class="col-12">
                <div class="card">
                    <div class="card-header px-2 py-1">
                        <a href="<?php echo e(route('administrador')); ?>" class="btn btn-sm btn-outline-success mx-1 shadow-sm"><i class="fa fa-arrow-left"></i> Atras</a>
                         
                    </div> 
                    <div class="card-body px-2 py-1">
                            <div id="form_update_load"></div>
                       <section  class="form row my-2 mx-0 justify-content-center" id="form_update_detail">
                           <?php $__currentLoopData = $seguridad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-10 col-lg-8 ">
                                    <label for="parametersSeguridadUpdate<?php echo e($seg->id); ?>" class="col-sm-6 col-md-6 col-lg-8 col-form-label col-form-label-sm mb-0 px-0"><?php echo e($seg->description); ?>: </label>
                                    <div class="input-group col-sm-6 col-md-6 col-lg-4 p-0">  
                                            <input type="number" id="parametersSeguridadUpdate<?php echo e($seg->id); ?>" value="<?php echo e($seg->period); ?>" class="form-control form-control-sm shadow-sm  text-uppercase validateText">
                                        <div class="input-group-prepend">
                                            <small class="form-control form-control-sm text-black-50 text-uppercase"><?php echo e($seg->time); ?></small>
                                            <a href="javascript:void(0)" class="btn btn-sm  btn-outline-success shadow-sm updateSeguridadBtn" data-id="<?php echo e($seg->id); ?>" data-texto="<?php echo e($seg->description); ?>"><i class="fa fa-refresh" aria-hidden="true"></i></a>
                                        </div>
                                    </div>  
                                </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                            <div class="form-group row justify-content-center mx-0 px-2 col-12 errors_message" id="errors_update">
                                
                            </div>
                             
                       </section>
                    </div>
                </div>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts-footer'); ?>  
    <script src="<?php echo e(asset('js/sistema/modulos/seguridad/index.min.js')); ?>"></script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\new_system\resources\views/administrador/modulos/seguridad/index.blade.php ENDPATH**/ ?>