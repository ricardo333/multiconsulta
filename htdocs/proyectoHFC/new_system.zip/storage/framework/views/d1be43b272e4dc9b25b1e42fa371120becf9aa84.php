<?php $__env->startSection('titulo_pagina_sistema', 'Empresa - Detalle'); ?>

<?php $__env->startSection('estilos'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts-header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-left-submenus'); ?>
    ##parent-placeholder-59556a1ffdff7f24b9f3c7de1ba1fed4ccb9619b##
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-container'); ?>
     <h4 class="m-0 text-dark text-uppercase">Detalle de Empresa</h4> 
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ruta-navegacion-container'); ?>
    ##parent-placeholder-6a091938c8d96c7e8c7b5c996884c2661881d145##
     <li class="breadcrumb-item active"><a href="<?php echo e(route('modulo.empresa.index')); ?>"> Empresa </a> </li>
     <li class="breadcrumb-item active">Detalle</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside-right'); ?>
    
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
    ##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##
    
  
    <div class="row">
        <div class="col-12">
                <div class="card">
                    <div class="card-header px-2 py-1">
                        <a href="<?php echo e(route('modulo.empresa.index')); ?>" class="btn btn-sm btn-outline-success mx-1"><i class="fa fa-arrow-left"></i> Atras</a>
                    </div> 
                    <div class="card-body px-2 py-1"> 
                          <form class="form row my-2 mx-0">
                               <?php $empresaDetalle = $empresa->getData(); ?> 
 
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <label for="nombreDetalle" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Nombre: </label>
                                    <div class="form-control form-control-sm col-12 col-sm-12 col-md-6 col-lg-6" id="nombreDetalle">
                                          <?php echo e($empresaDetalle->response->data->empresa); ?>

                                    </div>
                              </div>
                               
                               
                                
                              <?php if(Auth::user()->HasPermiso('submodulo.empresa.edit')): ?>
                                    <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center">
                                          <a href="<?php echo e(route('submodulo.empresa.edit', $empresaDetalle->response->data->identificador)); ?>" class="btn btn-outline-success btn-sm shadow-sm p-1 accionEmpresaEdit" >Editar<i class="fa fa-pencil icon-accion"></i></a>
                                    </div>
                                <?php endif; ?>
                              
                              
                          </form>
                    </div>
                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts-footer'); ?> 
        <script src="<?php echo e(asset('js/sistema/modulos/empresas/show.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\new_system\resources\views/administrador/modulos/empresa/detalle.blade.php ENDPATH**/ ?>