<?php $__env->startSection('titulo_pagina_sistema', 'Empresas - Edición'); ?>

<?php $__env->startSection('estilos'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts-header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-left-submenus'); ?>
    ##parent-placeholder-59556a1ffdff7f24b9f3c7de1ba1fed4ccb9619b##
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-container'); ?>
     <h4 class="m-0 text-dark text-uppercase">Edición de Empresas</h4> 
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ruta-navegacion-container'); ?>
    ##parent-placeholder-6a091938c8d96c7e8c7b5c996884c2661881d145##
     <li class="breadcrumb-item active"><a href="<?php echo e(route('modulo.empresa.index')); ?>"> Empresas </a> </li>
     <li class="breadcrumb-item active">Edición</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside-right'); ?>
    
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
    ##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##
     
    <div class="row">
        <div class="col-12">
                <div class="card">
                    <div class="card-header px-2 py-1">
                        <a href="<?php echo e(route('modulo.empresa.index')); ?>" class="btn btn-sm btn-outline-success shadow-sm mx-1"><i class="fa fa-arrow-left"></i> Atras</a>
                    </div> 
                    <div class="card-body px-2 py-1"> 
                        <div id="form_update_load"></div>
                        <section class="form row my-2 mx-0" id="form_update_detail">
                            <?php $empresaEdit = $empresa->getData(); ?> 
 
                            <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-6 col-lg-6 ">
                                <label for="nombreUpdate" class="col-sm-5 col-md-4 col-form-label col-form-label-sm mb-0 px-0">Nombre: </label>
                                <input type="text" name="nombreUpdate" id="nombreUpdate" value="<?php echo e($empresaEdit->response->data->empresa); ?>" class="col-sm-7 col-md-8 form-control form-control-sm shadow-sm  text-uppercase validateText">
                                <input type="hidden" name="idUpdate" id="idUpdate" value="<?php echo e($empresaEdit->response->data->identificador); ?>" class="col-sm-7 col-md-8 form-control form-control-sm shadow-sm">
                            </div>
                             
                            <div class="form-group row justify-content-center mx-0 px-2 col-12 errors_message" id="errors_update">
                                
                            </div>
                              <div class="form-group row mx-0 px-2 col-12 col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center">
                                   <a href="javascript:void(0)" class="btn btn-sm btn-outline-primary shadow-sm" id="actualizarEmpresa">Actualizar Empresa</a>
                              </div>
                              
                        </section>
                    </div>
                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts-footer'); ?>
     
    <script src="<?php echo e(asset('js/sistema/modulos/empresas/edit.min.js')); ?>"></script>
     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\new_system\resources\views/administrador/modulos/empresa/edit.blade.php ENDPATH**/ ?>