<div class="modal fade" id="addPermisosModal" tabindex="-1" role="dialog" aria-labelledby="addPermisosModalTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header px-2 py-1">
        <h5 class="modal-title" id="exampleModalLongTitle">Agregar nuevos permisos</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body modal-height-responsive">
        <div class="row">
          <div class="col-12 errors" id="rpta_store_checked_permisos">

          </div>
          <div class="col-12" id="storeModulosAndPermisosList">
            
          </div> 
        </div>
      </div> 
    </div>
  </div>
</div><?php /**PATH C:\laragon\www\new_system\resources\views/administrador/modulos/user/partials/addPermisosModal.blade.php ENDPATH**/ ?>