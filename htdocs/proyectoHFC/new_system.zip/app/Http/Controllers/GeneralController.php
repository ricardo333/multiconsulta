<?php 

namespace App\Http\Controllers;

use App\Traits\SystemResponser;
use App\Http\Controllers\Controller;

class GeneralController extends Controller {
     use SystemResponser;
}