<?php

namespace App\Http\Controllers\Modulos\Llamada;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class LlamadaController extends Controller
{
    //
}
