<?php

namespace App\Http\Controllers\Modulos\Arbol;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ArbolController extends Controller
{
    //
}
